/********************************************************************************
** Form generated from reading UI file 'd_ev.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_D_EV_H
#define UI_D_EV_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>
#include "piechartwidget.h"

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QTabWidget *tabWidget;
    QWidget *Evenement;
    QTabWidget *GestionEvent;
    QWidget *AjouterEvent;
    QLabel *label;
    QLineEdit *lineEdit_id;
    QLineEdit *lineEdit_nom;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QFrame *line_5;
    QFrame *line_10;
    QPushButton *pb_ajouter;
    QFrame *line_11;
    QLabel *label_2;
    QFrame *line_12;
    QFrame *line_24;
    QFrame *line_25;
    QFrame *line_26;
    QFrame *line_27;
    QFrame *line_28;
    QFrame *line_29;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_33;
    QLabel *label_34;
    QLabel *label_36;
    QDateEdit *dateEv;
    QComboBox *comboBox1;
    QLabel *label_72;
    QLabel *label_37;
    QLabel *label_50;
    QWidget *AfficherEvent;
    QTableView *tabevent;
    QLabel *label_19;
    QLabel *label_24;
    QLabel *label_29;
    QLabel *label_43;
    QLineEdit *rech_ev;
    QLabel *label_65;
    QPushButton *pb_rech_ev;
    QPushButton *tri_date;
    QLabel *label_73;
    QLabel *label_48;
    QLabel *label_51;
    QWidget *Modifierevent;
    QLabel *label_31;
    QLabel *label_55;
    QLabel *label_38;
    QFrame *line_32;
    QFrame *line_33;
    QFrame *line_34;
    QFrame *line_35;
    QLabel *label_39;
    QLabel *label_44;
    QLineEdit *recherche_ev;
    QPushButton *pb_recherche_ev;
    QTableView *tabevent_modif;
    QFrame *line_36;
    QLabel *label_45;
    QLineEdit *nom_ev_modif;
    QLabel *label_46;
    QLabel *label_47;
    QFrame *line_37;
    QLabel *label_56;
    QFrame *line_38;
    QFrame *line_39;
    QPushButton *pb_modifier_ev;
    QDateEdit *date_ev_modif;
    QComboBox *comboBox2;
    QLabel *label_74;
    QLabel *label_77;
    QWidget *SupprimerEvent;
    QLabel *label_3;
    QFrame *line_6;
    QFrame *line_7;
    QFrame *line_8;
    QFrame *line_9;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QPushButton *pb_supprimer;
    QLabel *label_25;
    QLabel *label_30;
    QLabel *label_54;
    QComboBox *comboBoxsupp1;
    QLabel *label_75;
    QLabel *label_78;
    QLabel *label_86;
    QWidget *Fete;
    QTabWidget *GestionFete;
    QWidget *AjouterFete;
    QLabel *label_4;
    QLineEdit *lineEdit_idf;
    QLineEdit *lineEdit_desc;
    QLineEdit *lineEdit_prix;
    QLabel *label_8;
    QLabel *label_10;
    QFrame *line_13;
    QFrame *line_15;
    QFrame *line_16;
    QFrame *line_17;
    QPushButton *pb_ajouter_2;
    QFrame *line_18;
    QLabel *label_11;
    QFrame *line_23;
    QLabel *label_9;
    QFrame *line_14;
    QFrame *line_30;
    QFrame *line_31;
    QLineEdit *lineEdit_nomf;
    QLabel *label_13;
    QLabel *label_26;
    QLabel *label_35;
    QLabel *label_71;
    QLabel *label_79;
    QLabel *label_49;
    QWidget *AfficherFete;
    QTableView *tabfete;
    QLabel *label_20;
    QLabel *label_27;
    QLabel *label_32;
    QLabel *label_52;
    QLineEdit *rech_fete;
    QLabel *label_66;
    QPushButton *pb_rech_fete;
    QPushButton *tri_prix;
    QLabel *label_69;
    QLabel *label_80;
    QLabel *label_84;
    QWidget *tab;
    QLabel *label_58;
    QFrame *line_40;
    QFrame *line_41;
    QLabel *label_59;
    QLabel *label_61;
    QLabel *label_60;
    QLineEdit *recherche_fete;
    QPushButton *pb_recherche_fete;
    QFrame *line_43;
    QFrame *line_42;
    QFrame *line_44;
    QFrame *line_46;
    QFrame *line_47;
    QFrame *line_45;
    QLabel *label_62;
    QTableView *tabfete_modif;
    QLabel *label_63;
    QLabel *label_64;
    QLineEdit *lineEdit_nom_fete_modif;
    QLineEdit *lineEdit_prix_fete_modif;
    QLineEdit *lineEdit_desc_fete_modif;
    QPushButton *pb_modifier_fete;
    QLabel *label_57;
    QLabel *label_81;
    QWidget *SupprimerFete;
    QLabel *label_12;
    QFrame *line_19;
    QFrame *line_20;
    QFrame *line_21;
    QFrame *line_22;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QPushButton *pb_supprimer_2;
    QLabel *label_28;
    QLabel *label_53;
    QComboBox *comboBoxsupp2;
    QLabel *label_68;
    QLabel *label_82;
    QLabel *label_85;
    QWidget *tab_2;
    PieChartWidget *widget;
    QLineEdit *a_2;
    QLineEdit *a;
    QLabel *label_70;
    QLabel *label_42;
    QLabel *label_41;
    QFrame *line_48;
    QFrame *line_49;
    QFrame *line_50;
    QFrame *line_51;
    QFrame *line_52;
    QFrame *line_53;
    QLabel *label_40;
    QLabel *label_67;
    QLabel *label_76;
    QLabel *label_83;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(714, 453);
        tabWidget = new QTabWidget(Dialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 10, 701, 431));
        tabWidget->setStyleSheet(QStringLiteral("color:rgb(255, 85, 0);"));
        Evenement = new QWidget();
        Evenement->setObjectName(QStringLiteral("Evenement"));
        GestionEvent = new QTabWidget(Evenement);
        GestionEvent->setObjectName(QStringLiteral("GestionEvent"));
        GestionEvent->setGeometry(QRect(0, 0, 701, 421));
        GestionEvent->setStyleSheet(QLatin1String("color:green;\n"
"font-style : \"MV Boli\";\n"
"\n"
""));
        AjouterEvent = new QWidget();
        AjouterEvent->setObjectName(QStringLiteral("AjouterEvent"));
        label = new QLabel(AjouterEvent);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(210, 140, 111, 31));
        QFont font;
        font.setFamily(QStringLiteral("MV Boli"));
        font.setPointSize(14);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        label->setFont(font);
        label->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  14pt \"MV Boli\";\n"
"background-color: white;"));
        lineEdit_id = new QLineEdit(AjouterEvent);
        lineEdit_id->setObjectName(QStringLiteral("lineEdit_id"));
        lineEdit_id->setGeometry(QRect(340, 140, 131, 31));
        lineEdit_id->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        lineEdit_nom = new QLineEdit(AjouterEvent);
        lineEdit_nom->setObjectName(QStringLiteral("lineEdit_nom"));
        lineEdit_nom->setGeometry(QRect(340, 200, 131, 31));
        lineEdit_nom->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        label_5 = new QLabel(AjouterEvent);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(240, 200, 81, 31));
        label_5->setFont(font);
        label_5->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  14pt \"MV Boli\";\n"
"background-color:white;\n"
""));
        label_6 = new QLabel(AjouterEvent);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(240, 260, 91, 31));
        label_6->setFont(font);
        label_6->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        label_7 = new QLabel(AjouterEvent);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(230, 320, 91, 31));
        label_7->setFont(font);
        label_7->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        line_5 = new QFrame(AjouterEvent);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setGeometry(QRect(150, 120, 381, 20));
        line_5->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_5->setFrameShadow(QFrame::Plain);
        line_5->setFrameShape(QFrame::HLine);
        line_10 = new QFrame(AjouterEvent);
        line_10->setObjectName(QStringLiteral("line_10"));
        line_10->setGeometry(QRect(520, 130, 20, 231));
        line_10->setFrameShadow(QFrame::Plain);
        line_10->setFrameShape(QFrame::VLine);
        pb_ajouter = new QPushButton(AjouterEvent);
        pb_ajouter->setObjectName(QStringLiteral("pb_ajouter"));
        pb_ajouter->setGeometry(QRect(560, 320, 111, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("MV Boli"));
        font1.setBold(true);
        font1.setItalic(false);
        font1.setWeight(75);
        pb_ajouter->setFont(font1);
        pb_ajouter->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\"\n"
""));
        line_11 = new QFrame(AjouterEvent);
        line_11->setObjectName(QStringLiteral("line_11"));
        line_11->setGeometry(QRect(140, 130, 20, 231));
        line_11->setFrameShadow(QFrame::Plain);
        line_11->setFrameShape(QFrame::VLine);
        label_2 = new QLabel(AjouterEvent);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(180, 60, 341, 41));
        QFont font2;
        font2.setFamily(QStringLiteral("MV Boli"));
        font2.setPointSize(22);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setWeight(75);
        label_2->setFont(font2);
        label_2->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 22pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        line_12 = new QFrame(AjouterEvent);
        line_12->setObjectName(QStringLiteral("line_12"));
        line_12->setGeometry(QRect(150, 350, 381, 20));
        line_12->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_12->setFrameShadow(QFrame::Plain);
        line_12->setFrameShape(QFrame::HLine);
        line_24 = new QFrame(AjouterEvent);
        line_24->setObjectName(QStringLiteral("line_24"));
        line_24->setGeometry(QRect(150, 170, 381, 20));
        line_24->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_24->setFrameShadow(QFrame::Plain);
        line_24->setFrameShape(QFrame::HLine);
        line_25 = new QFrame(AjouterEvent);
        line_25->setObjectName(QStringLiteral("line_25"));
        line_25->setGeometry(QRect(150, 180, 381, 20));
        line_25->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_25->setFrameShadow(QFrame::Plain);
        line_25->setFrameShape(QFrame::HLine);
        line_26 = new QFrame(AjouterEvent);
        line_26->setObjectName(QStringLiteral("line_26"));
        line_26->setGeometry(QRect(150, 230, 381, 20));
        line_26->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_26->setFrameShadow(QFrame::Plain);
        line_26->setFrameShape(QFrame::HLine);
        line_27 = new QFrame(AjouterEvent);
        line_27->setObjectName(QStringLiteral("line_27"));
        line_27->setGeometry(QRect(150, 240, 381, 20));
        line_27->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_27->setFrameShadow(QFrame::Plain);
        line_27->setFrameShape(QFrame::HLine);
        line_28 = new QFrame(AjouterEvent);
        line_28->setObjectName(QStringLiteral("line_28"));
        line_28->setGeometry(QRect(150, 300, 381, 20));
        line_28->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_28->setFrameShadow(QFrame::Plain);
        line_28->setFrameShape(QFrame::HLine);
        line_29 = new QFrame(AjouterEvent);
        line_29->setObjectName(QStringLiteral("line_29"));
        line_29->setGeometry(QRect(150, 290, 381, 20));
        line_29->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_29->setFrameShadow(QFrame::Plain);
        line_29->setFrameShape(QFrame::HLine);
        label_14 = new QLabel(AjouterEvent);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(270, 0, 151, 111));
        label_14->setPixmap(QPixmap(QString::fromUtf8(":/e67d03c3 (1) (1) (1) (1).png")));
        label_15 = new QLabel(AjouterEvent);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(-10, 340, 51, 41));
        label_15->setPixmap(QPixmap(QString::fromUtf8(":/logo (1) (1) (1).png")));
        label_33 = new QLabel(AjouterEvent);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(200, 90, 321, 31));
        QFont font3;
        font3.setFamily(QStringLiteral("MV Boli"));
        font3.setPointSize(12);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        label_33->setFont(font3);
        label_33->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        label_34 = new QLabel(AjouterEvent);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(80, 210, 47, 13));
        label_36 = new QLabel(AjouterEvent);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(0, 0, 691, 381));
        label_36->setPixmap(QPixmap(QString::fromUtf8("../images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        dateEv = new QDateEdit(AjouterEvent);
        dateEv->setObjectName(QStringLiteral("dateEv"));
        dateEv->setGeometry(QRect(340, 260, 131, 31));
        dateEv->setStyleSheet(QLatin1String("border-color: rgb(255, 85, 0);\n"
"selection-color: rgb(85, 255, 127);"));
        dateEv->setDateTime(QDateTime(QDate(2020, 9, 18), QTime(0, 0, 0)));
        dateEv->setMaximumDateTime(QDateTime(QDate(2050, 12, 31), QTime(23, 59, 59)));
        dateEv->setMinimumDateTime(QDateTime(QDate(2020, 4, 18), QTime(0, 0, 0)));
        comboBox1 = new QComboBox(AjouterEvent);
        comboBox1->setObjectName(QStringLiteral("comboBox1"));
        comboBox1->setGeometry(QRect(340, 320, 131, 31));
        label_72 = new QLabel(AjouterEvent);
        label_72->setObjectName(QStringLiteral("label_72"));
        label_72->setGeometry(QRect(-10, 0, 701, 381));
        label_72->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_37 = new QLabel(AjouterEvent);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(270, 10, 171, 101));
        label_37->setPixmap(QPixmap(QString::fromUtf8("../images/e67d03c3 (1) (1) (1) (1).png")));
        label_50 = new QLabel(AjouterEvent);
        label_50->setObjectName(QStringLiteral("label_50"));
        label_50->setGeometry(QRect(0, 330, 61, 51));
        label_50->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        GestionEvent->addTab(AjouterEvent, QString());
        label_72->raise();
        label_36->raise();
        label->raise();
        lineEdit_id->raise();
        lineEdit_nom->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();
        line_5->raise();
        line_10->raise();
        pb_ajouter->raise();
        line_11->raise();
        line_12->raise();
        line_24->raise();
        line_25->raise();
        line_26->raise();
        line_27->raise();
        line_28->raise();
        line_29->raise();
        label_15->raise();
        label_33->raise();
        label_34->raise();
        label_2->raise();
        label_14->raise();
        dateEv->raise();
        comboBox1->raise();
        label_37->raise();
        label_50->raise();
        AfficherEvent = new QWidget();
        AfficherEvent->setObjectName(QStringLiteral("AfficherEvent"));
        tabevent = new QTableView(AfficherEvent);
        tabevent->setObjectName(QStringLiteral("tabevent"));
        tabevent->setGeometry(QRect(10, 120, 661, 211));
        label_19 = new QLabel(AfficherEvent);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(180, 20, 331, 41));
        label_19->setFont(font2);
        label_19->setStyleSheet(QLatin1String("color:#ff5500;\n"
"font: bold 22pt \"MV Boli\" ;\n"
"background-color:white;\n"
" \n"
"\n"
""));
        label_24 = new QLabel(AfficherEvent);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(-10, 340, 51, 41));
        label_24->setPixmap(QPixmap(QString::fromUtf8(":/logo (1) (1) (1).png")));
        label_29 = new QLabel(AfficherEvent);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(480, 250, 221, 121));
        label_29->setPixmap(QPixmap(QString::fromUtf8(":/kindergarten-png-transparent-images-pictures-photos-png-arts-kindergarten-png-images-602_312.png")));
        label_43 = new QLabel(AfficherEvent);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(0, -130, 691, 511));
        label_43->setPixmap(QPixmap(QString::fromUtf8(":/Desktop/Wallpaper-MuffinMani_Confetti_1.jpg")));
        rech_ev = new QLineEdit(AfficherEvent);
        rech_ev->setObjectName(QStringLiteral("rech_ev"));
        rech_ev->setGeometry(QRect(230, 80, 121, 31));
        rech_ev->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        label_65 = new QLabel(AfficherEvent);
        label_65->setObjectName(QStringLiteral("label_65"));
        label_65->setGeometry(QRect(200, 80, 21, 31));
        QFont font4;
        font4.setFamily(QStringLiteral("MV Boli"));
        font4.setPointSize(14);
        font4.setBold(true);
        font4.setItalic(false);
        font4.setWeight(75);
        label_65->setFont(font4);
        label_65->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        pb_rech_ev = new QPushButton(AfficherEvent);
        pb_rech_ev->setObjectName(QStringLiteral("pb_rech_ev"));
        pb_rech_ev->setGeometry(QRect(360, 80, 111, 31));
        pb_rech_ev->setFont(font1);
        pb_rech_ev->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        tri_date = new QPushButton(AfficherEvent);
        tri_date->setObjectName(QStringLiteral("tri_date"));
        tri_date->setGeometry(QRect(200, 340, 221, 31));
        tri_date->setFont(font1);
        tri_date->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        label_73 = new QLabel(AfficherEvent);
        label_73->setObjectName(QStringLiteral("label_73"));
        label_73->setGeometry(QRect(0, 0, 701, 381));
        label_73->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_48 = new QLabel(AfficherEvent);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setGeometry(QRect(480, 270, 191, 111));
        label_48->setPixmap(QPixmap(QString::fromUtf8("../images/kindergarten-png-transparent-images-pictures-photos-png-arts-kindergarten-png-images-602_312.png")));
        label_51 = new QLabel(AfficherEvent);
        label_51->setObjectName(QStringLiteral("label_51"));
        label_51->setGeometry(QRect(0, 330, 61, 51));
        label_51->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        GestionEvent->addTab(AfficherEvent, QString());
        label_73->raise();
        label_43->raise();
        tabevent->raise();
        label_19->raise();
        label_24->raise();
        label_29->raise();
        rech_ev->raise();
        label_65->raise();
        pb_rech_ev->raise();
        tri_date->raise();
        label_48->raise();
        label_51->raise();
        Modifierevent = new QWidget();
        Modifierevent->setObjectName(QStringLiteral("Modifierevent"));
        label_31 = new QLabel(Modifierevent);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(180, 20, 331, 31));
        QFont font5;
        font5.setFamily(QStringLiteral("MV Boli"));
        font5.setPointSize(20);
        font5.setBold(true);
        font5.setItalic(false);
        font5.setWeight(75);
        label_31->setFont(font5);
        label_31->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 20pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        label_55 = new QLabel(Modifierevent);
        label_55->setObjectName(QStringLiteral("label_55"));
        label_55->setGeometry(QRect(0, 0, 691, 761));
        label_55->setPixmap(QPixmap(QString::fromUtf8(":/Desktop/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_38 = new QLabel(Modifierevent);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(20, 110, 121, 31));
        QFont font6;
        font6.setFamily(QStringLiteral("MV Boli"));
        font6.setPointSize(10);
        font6.setBold(false);
        font6.setItalic(false);
        font6.setWeight(50);
        label_38->setFont(font6);
        label_38->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  10pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        line_32 = new QFrame(Modifierevent);
        line_32->setObjectName(QStringLiteral("line_32"));
        line_32->setGeometry(QRect(10, 60, 231, 21));
        line_32->setFrameShadow(QFrame::Plain);
        line_32->setFrameShape(QFrame::HLine);
        line_33 = new QFrame(Modifierevent);
        line_33->setObjectName(QStringLiteral("line_33"));
        line_33->setGeometry(QRect(10, 100, 231, 141));
        line_33->setFrameShadow(QFrame::Plain);
        line_33->setFrameShape(QFrame::HLine);
        line_34 = new QFrame(Modifierevent);
        line_34->setObjectName(QStringLiteral("line_34"));
        line_34->setGeometry(QRect(0, 70, 20, 101));
        line_34->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_34->setFrameShadow(QFrame::Plain);
        line_34->setFrameShape(QFrame::VLine);
        line_35 = new QFrame(Modifierevent);
        line_35->setObjectName(QStringLiteral("line_35"));
        line_35->setGeometry(QRect(230, 70, 20, 101));
        line_35->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_35->setFrameShadow(QFrame::Plain);
        line_35->setFrameShape(QFrame::VLine);
        label_39 = new QLabel(Modifierevent);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(20, 130, 81, 31));
        label_39->setFont(font6);
        label_39->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  10pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_44 = new QLabel(Modifierevent);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(20, 90, 101, 31));
        label_44->setFont(font3);
        label_44->setStyleSheet(QLatin1String("color: green;\n"
"font:  12pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        recherche_ev = new QLineEdit(Modifierevent);
        recherche_ev->setObjectName(QStringLiteral("recherche_ev"));
        recherche_ev->setGeometry(QRect(120, 90, 111, 31));
        recherche_ev->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        pb_recherche_ev = new QPushButton(Modifierevent);
        pb_recherche_ev->setObjectName(QStringLiteral("pb_recherche_ev"));
        pb_recherche_ev->setGeometry(QRect(120, 130, 111, 31));
        pb_recherche_ev->setFont(font1);
        pb_recherche_ev->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        tabevent_modif = new QTableView(Modifierevent);
        tabevent_modif->setObjectName(QStringLiteral("tabevent_modif"));
        tabevent_modif->setGeometry(QRect(250, 70, 431, 101));
        line_36 = new QFrame(Modifierevent);
        line_36->setObjectName(QStringLiteral("line_36"));
        line_36->setGeometry(QRect(30, 190, 601, 21));
        line_36->setFrameShadow(QFrame::Plain);
        line_36->setFrameShape(QFrame::HLine);
        label_45 = new QLabel(Modifierevent);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(50, 210, 161, 31));
        QFont font7;
        font7.setFamily(QStringLiteral("MV Boli"));
        font7.setPointSize(16);
        font7.setBold(false);
        font7.setItalic(false);
        font7.setWeight(50);
        label_45->setFont(font7);
        label_45->setStyleSheet(QLatin1String("color: green;\n"
"font:  16pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        nom_ev_modif = new QLineEdit(Modifierevent);
        nom_ev_modif->setObjectName(QStringLiteral("nom_ev_modif"));
        nom_ev_modif->setGeometry(QRect(250, 210, 141, 31));
        nom_ev_modif->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        label_46 = new QLabel(Modifierevent);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setGeometry(QRect(50, 260, 151, 31));
        label_46->setFont(font7);
        label_46->setStyleSheet(QLatin1String("color: green;\n"
"font:  16pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_47 = new QLabel(Modifierevent);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setGeometry(QRect(50, 310, 181, 31));
        label_47->setFont(font7);
        label_47->setStyleSheet(QLatin1String("color: green;\n"
"font:  16pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        line_37 = new QFrame(Modifierevent);
        line_37->setObjectName(QStringLiteral("line_37"));
        line_37->setGeometry(QRect(20, 200, 20, 161));
        line_37->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_37->setFrameShadow(QFrame::Plain);
        line_37->setFrameShape(QFrame::VLine);
        label_56 = new QLabel(Modifierevent);
        label_56->setObjectName(QStringLiteral("label_56"));
        label_56->setGeometry(QRect(60, 330, 81, 31));
        label_56->setFont(font3);
        label_56->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        line_38 = new QFrame(Modifierevent);
        line_38->setObjectName(QStringLiteral("line_38"));
        line_38->setGeometry(QRect(620, 200, 20, 161));
        line_38->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_38->setFrameShadow(QFrame::Plain);
        line_38->setFrameShape(QFrame::VLine);
        line_39 = new QFrame(Modifierevent);
        line_39->setObjectName(QStringLiteral("line_39"));
        line_39->setGeometry(QRect(30, 350, 601, 21));
        line_39->setFrameShadow(QFrame::Plain);
        line_39->setFrameShape(QFrame::HLine);
        pb_modifier_ev = new QPushButton(Modifierevent);
        pb_modifier_ev->setObjectName(QStringLiteral("pb_modifier_ev"));
        pb_modifier_ev->setGeometry(QRect(460, 250, 111, 51));
        pb_modifier_ev->setFont(font1);
        pb_modifier_ev->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        date_ev_modif = new QDateEdit(Modifierevent);
        date_ev_modif->setObjectName(QStringLiteral("date_ev_modif"));
        date_ev_modif->setGeometry(QRect(250, 260, 141, 31));
        date_ev_modif->setStyleSheet(QLatin1String("border-color: rgb(255, 85, 0);\n"
"selection-color: rgb(85, 255, 127);"));
        comboBox2 = new QComboBox(Modifierevent);
        comboBox2->setObjectName(QStringLiteral("comboBox2"));
        comboBox2->setGeometry(QRect(250, 310, 141, 31));
        label_74 = new QLabel(Modifierevent);
        label_74->setObjectName(QStringLiteral("label_74"));
        label_74->setGeometry(QRect(-10, 0, 701, 381));
        label_74->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_77 = new QLabel(Modifierevent);
        label_77->setObjectName(QStringLiteral("label_77"));
        label_77->setGeometry(QRect(640, 330, 61, 51));
        label_77->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        GestionEvent->addTab(Modifierevent, QString());
        label_74->raise();
        label_55->raise();
        label_31->raise();
        line_33->raise();
        line_35->raise();
        label_39->raise();
        label_38->raise();
        tabevent_modif->raise();
        line_32->raise();
        line_34->raise();
        line_36->raise();
        label_45->raise();
        nom_ev_modif->raise();
        label_46->raise();
        line_37->raise();
        label_56->raise();
        label_47->raise();
        line_38->raise();
        line_39->raise();
        pb_modifier_ev->raise();
        label_44->raise();
        recherche_ev->raise();
        pb_recherche_ev->raise();
        date_ev_modif->raise();
        comboBox2->raise();
        label_77->raise();
        SupprimerEvent = new QWidget();
        SupprimerEvent->setObjectName(QStringLiteral("SupprimerEvent"));
        label_3 = new QLabel(SupprimerEvent);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(190, 170, 131, 31));
        label_3->setFont(font7);
        label_3->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  16pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        line_6 = new QFrame(SupprimerEvent);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setGeometry(QRect(120, 140, 20, 111));
        line_6->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_6->setFrameShadow(QFrame::Plain);
        line_6->setFrameShape(QFrame::VLine);
        line_7 = new QFrame(SupprimerEvent);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setGeometry(QRect(510, 140, 20, 111));
        line_7->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_7->setFrameShadow(QFrame::Plain);
        line_7->setFrameShape(QFrame::VLine);
        line_8 = new QFrame(SupprimerEvent);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setGeometry(QRect(130, 130, 391, 21));
        line_8->setFrameShadow(QFrame::Plain);
        line_8->setFrameShape(QFrame::HLine);
        line_9 = new QFrame(SupprimerEvent);
        line_9->setObjectName(QStringLiteral("line_9"));
        line_9->setGeometry(QRect(130, 240, 391, 21));
        line_9->setFrameShadow(QFrame::Plain);
        line_9->setFrameShape(QFrame::HLine);
        label_16 = new QLabel(SupprimerEvent);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(160, 40, 351, 41));
        label_16->setFont(font5);
        label_16->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 20pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_17 = new QLabel(SupprimerEvent);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(240, 70, 241, 41));
        label_17->setFont(font3);
        label_17->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_18 = new QLabel(SupprimerEvent);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(230, 100, 201, 31));
        label_18->setFont(font3);
        label_18->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        pb_supprimer = new QPushButton(SupprimerEvent);
        pb_supprimer->setObjectName(QStringLiteral("pb_supprimer"));
        pb_supprimer->setGeometry(QRect(270, 310, 111, 31));
        pb_supprimer->setFont(font1);
        pb_supprimer->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        label_25 = new QLabel(SupprimerEvent);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(-10, 340, 51, 41));
        label_25->setPixmap(QPixmap(QString::fromUtf8(":/logo (1) (1) (1).png")));
        label_30 = new QLabel(SupprimerEvent);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(490, 230, 231, 151));
        label_30->setPixmap(QPixmap(QString::fromUtf8(":/kindergarten-kids-png-1 (1).png")));
        label_54 = new QLabel(SupprimerEvent);
        label_54->setObjectName(QStringLiteral("label_54"));
        label_54->setGeometry(QRect(0, -320, 691, 761));
        label_54->setPixmap(QPixmap(QString::fromUtf8(":/Desktop/Wallpaper-MuffinMani_Confetti_1.jpg")));
        comboBoxsupp1 = new QComboBox(SupprimerEvent);
        comboBoxsupp1->setObjectName(QStringLiteral("comboBoxsupp1"));
        comboBoxsupp1->setGeometry(QRect(330, 170, 141, 31));
        label_75 = new QLabel(SupprimerEvent);
        label_75->setObjectName(QStringLiteral("label_75"));
        label_75->setGeometry(QRect(0, 0, 701, 381));
        label_75->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_78 = new QLabel(SupprimerEvent);
        label_78->setObjectName(QStringLiteral("label_78"));
        label_78->setGeometry(QRect(0, 330, 61, 51));
        label_78->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        label_86 = new QLabel(SupprimerEvent);
        label_86->setObjectName(QStringLiteral("label_86"));
        label_86->setGeometry(QRect(230, 180, 241, 91));
        label_86->setPixmap(QPixmap(QString::fromUtf8("../images/singer-clipart-kid-choir-2-1920x450 (1).png")));
        GestionEvent->addTab(SupprimerEvent, QString());
        label_75->raise();
        label_54->raise();
        label_3->raise();
        line_6->raise();
        line_7->raise();
        line_8->raise();
        line_9->raise();
        label_18->raise();
        pb_supprimer->raise();
        label_30->raise();
        label_25->raise();
        label_17->raise();
        label_16->raise();
        comboBoxsupp1->raise();
        label_78->raise();
        label_86->raise();
        tabWidget->addTab(Evenement, QString());
        Fete = new QWidget();
        Fete->setObjectName(QStringLiteral("Fete"));
        GestionFete = new QTabWidget(Fete);
        GestionFete->setObjectName(QStringLiteral("GestionFete"));
        GestionFete->setGeometry(QRect(0, 0, 701, 411));
        GestionFete->setStyleSheet(QLatin1String("color:green;\n"
"font-style : Monotype Corsiva;\n"
"\n"
""));
        AjouterFete = new QWidget();
        AjouterFete->setObjectName(QStringLiteral("AjouterFete"));
        label_4 = new QLabel(AjouterFete);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(60, 100, 131, 31));
        QFont font8;
        font8.setFamily(QStringLiteral("MV Boli"));
        font8.setPointSize(13);
        font8.setBold(false);
        font8.setItalic(false);
        font8.setWeight(50);
        label_4->setFont(font8);
        label_4->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  13pt \"MV Boli\";\n"
"\n"
""));
        lineEdit_idf = new QLineEdit(AjouterFete);
        lineEdit_idf->setObjectName(QStringLiteral("lineEdit_idf"));
        lineEdit_idf->setGeometry(QRect(150, 130, 131, 31));
        lineEdit_idf->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        lineEdit_desc = new QLineEdit(AjouterFete);
        lineEdit_desc->setObjectName(QStringLiteral("lineEdit_desc"));
        lineEdit_desc->setGeometry(QRect(320, 140, 281, 141));
        lineEdit_desc->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        lineEdit_prix = new QLineEdit(AjouterFete);
        lineEdit_prix->setObjectName(QStringLiteral("lineEdit_prix"));
        lineEdit_prix->setGeometry(QRect(150, 300, 131, 31));
        lineEdit_prix->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        label_8 = new QLabel(AjouterFete);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(60, 270, 141, 31));
        label_8->setFont(font8);
        label_8->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  13pt \"MV Boli\";\n"
"\n"
""));
        label_10 = new QLabel(AjouterFete);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(300, 100, 171, 31));
        label_10->setFont(font3);
        label_10->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"\n"
""));
        line_13 = new QFrame(AjouterFete);
        line_13->setObjectName(QStringLiteral("line_13"));
        line_13->setGeometry(QRect(50, 170, 241, 16));
        line_13->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_13->setFrameShadow(QFrame::Plain);
        line_13->setFrameShape(QFrame::HLine);
        line_15 = new QFrame(AjouterFete);
        line_15->setObjectName(QStringLiteral("line_15"));
        line_15->setGeometry(QRect(50, 340, 581, 20));
        line_15->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_15->setFrameShadow(QFrame::Plain);
        line_15->setFrameShape(QFrame::HLine);
        line_16 = new QFrame(AjouterFete);
        line_16->setObjectName(QStringLiteral("line_16"));
        line_16->setGeometry(QRect(50, 90, 581, 20));
        line_16->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_16->setFrameShadow(QFrame::Plain);
        line_16->setFrameShape(QFrame::HLine);
        line_17 = new QFrame(AjouterFete);
        line_17->setObjectName(QStringLiteral("line_17"));
        line_17->setGeometry(QRect(620, 100, 20, 251));
        line_17->setFrameShadow(QFrame::Plain);
        line_17->setFrameShape(QFrame::VLine);
        pb_ajouter_2 = new QPushButton(AjouterFete);
        pb_ajouter_2->setObjectName(QStringLiteral("pb_ajouter_2"));
        pb_ajouter_2->setGeometry(QRect(420, 300, 91, 31));
        pb_ajouter_2->setFont(font1);
        pb_ajouter_2->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold  large \"MV Boli\"\n"
""));
        line_18 = new QFrame(AjouterFete);
        line_18->setObjectName(QStringLiteral("line_18"));
        line_18->setGeometry(QRect(40, 100, 20, 251));
        line_18->setFrameShadow(QFrame::Plain);
        line_18->setFrameShape(QFrame::VLine);
        label_11 = new QLabel(AjouterFete);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(210, 20, 291, 41));
        label_11->setFont(font5);
        label_11->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 20pt \"MV Boli\";\n"
"background: white\n"
""));
        line_23 = new QFrame(AjouterFete);
        line_23->setObjectName(QStringLiteral("line_23"));
        line_23->setGeometry(QRect(280, 100, 20, 251));
        line_23->setFrameShadow(QFrame::Plain);
        line_23->setFrameShape(QFrame::VLine);
        label_9 = new QLabel(AjouterFete);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(60, 290, 141, 31));
        QFont font9;
        font9.setFamily(QStringLiteral("MV Boli"));
        font9.setPointSize(10);
        font9.setBold(true);
        font9.setItalic(true);
        font9.setWeight(75);
        label_9->setFont(font9);
        label_9->setStyleSheet(QLatin1String("color: green;\n"
"font: bold italic 10pt \"MV Boli\";\n"
"\n"
""));
        line_14 = new QFrame(AjouterFete);
        line_14->setObjectName(QStringLiteral("line_14"));
        line_14->setGeometry(QRect(50, 180, 241, 16));
        line_14->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_14->setFrameShadow(QFrame::Plain);
        line_14->setFrameShape(QFrame::HLine);
        line_30 = new QFrame(AjouterFete);
        line_30->setObjectName(QStringLiteral("line_30"));
        line_30->setGeometry(QRect(50, 250, 241, 16));
        line_30->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_30->setFrameShadow(QFrame::Plain);
        line_30->setFrameShape(QFrame::HLine);
        line_31 = new QFrame(AjouterFete);
        line_31->setObjectName(QStringLiteral("line_31"));
        line_31->setGeometry(QRect(50, 260, 241, 16));
        line_31->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_31->setFrameShadow(QFrame::Plain);
        line_31->setFrameShape(QFrame::HLine);
        lineEdit_nomf = new QLineEdit(AjouterFete);
        lineEdit_nomf->setObjectName(QStringLiteral("lineEdit_nomf"));
        lineEdit_nomf->setGeometry(QRect(150, 210, 131, 31));
        lineEdit_nomf->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        label_13 = new QLabel(AjouterFete);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(60, 190, 131, 31));
        label_13->setFont(font8);
        label_13->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  13pt \"MV Boli\";\n"
"\n"
""));
        label_26 = new QLabel(AjouterFete);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(-10, 340, 51, 41));
        label_26->setPixmap(QPixmap(QString::fromUtf8(":/logo (1) (1) (1).png")));
        label_35 = new QLabel(AjouterFete);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(170, 60, 341, 31));
        label_35->setFont(font);
        label_35->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  14pt \"MV Boli\";\n"
"background: white\n"
"\n"
""));
        label_71 = new QLabel(AjouterFete);
        label_71->setObjectName(QStringLiteral("label_71"));
        label_71->setGeometry(QRect(0, 0, 701, 381));
        label_71->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_79 = new QLabel(AjouterFete);
        label_79->setObjectName(QStringLiteral("label_79"));
        label_79->setGeometry(QRect(640, 330, 51, 51));
        label_79->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        label_49 = new QLabel(AjouterFete);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setGeometry(QRect(390, -10, 301, 241));
        label_49->setPixmap(QPixmap(QString::fromUtf8("../images/PolishedJointCopperbutterfly-size_restricted.gif")));
        GestionFete->addTab(AjouterFete, QString());
        label_71->raise();
        label_4->raise();
        lineEdit_idf->raise();
        lineEdit_desc->raise();
        lineEdit_prix->raise();
        label_8->raise();
        label_10->raise();
        line_13->raise();
        line_15->raise();
        line_16->raise();
        line_17->raise();
        pb_ajouter_2->raise();
        line_18->raise();
        label_11->raise();
        line_23->raise();
        label_9->raise();
        line_14->raise();
        line_30->raise();
        line_31->raise();
        lineEdit_nomf->raise();
        label_13->raise();
        label_26->raise();
        label_35->raise();
        label_79->raise();
        label_49->raise();
        AfficherFete = new QWidget();
        AfficherFete->setObjectName(QStringLiteral("AfficherFete"));
        tabfete = new QTableView(AfficherFete);
        tabfete->setObjectName(QStringLiteral("tabfete"));
        tabfete->setGeometry(QRect(10, 90, 651, 201));
        tabfete->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        tabfete->setFrameShadow(QFrame::Plain);
        label_20 = new QLabel(AfficherFete);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(210, 0, 291, 41));
        QFont font10;
        font10.setFamily(QStringLiteral("MV Boli"));
        font10.setPointSize(26);
        font10.setBold(false);
        font10.setItalic(false);
        font10.setWeight(50);
        label_20->setFont(font10);
        label_20->setStyleSheet(QLatin1String("color:#ff5500;\n"
"font:  26pt \"MV Boli\" ;\n"
"background: white\n"
"\n"
""));
        label_27 = new QLabel(AfficherFete);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(-10, 340, 51, 41));
        label_27->setPixmap(QPixmap(QString::fromUtf8(":/logo (1) (1) (1).png")));
        label_32 = new QLabel(AfficherFete);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(470, 300, 241, 111));
        label_32->setPixmap(QPixmap(QString::fromUtf8(":/singer-clipart-kid-choir-2-1920x450 (1).png")));
        label_52 = new QLabel(AfficherFete);
        label_52->setObjectName(QStringLiteral("label_52"));
        label_52->setGeometry(QRect(0, 0, 691, 391));
        label_52->setPixmap(QPixmap(QString::fromUtf8(":/Desktop/Wallpaper-MuffinMani_Confetti_1.jpg")));
        rech_fete = new QLineEdit(AfficherFete);
        rech_fete->setObjectName(QStringLiteral("rech_fete"));
        rech_fete->setGeometry(QRect(230, 50, 121, 31));
        rech_fete->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        label_66 = new QLabel(AfficherFete);
        label_66->setObjectName(QStringLiteral("label_66"));
        label_66->setGeometry(QRect(190, 50, 41, 31));
        label_66->setFont(font4);
        label_66->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        pb_rech_fete = new QPushButton(AfficherFete);
        pb_rech_fete->setObjectName(QStringLiteral("pb_rech_fete"));
        pb_rech_fete->setGeometry(QRect(370, 50, 111, 31));
        pb_rech_fete->setFont(font1);
        pb_rech_fete->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        tri_prix = new QPushButton(AfficherFete);
        tri_prix->setObjectName(QStringLiteral("tri_prix"));
        tri_prix->setGeometry(QRect(10, 300, 131, 31));
        tri_prix->setFont(font1);
        tri_prix->setStyleSheet(QLatin1String("color:green;\n"
"selection-color: rgb(255, 255, 127);\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        label_69 = new QLabel(AfficherFete);
        label_69->setObjectName(QStringLiteral("label_69"));
        label_69->setGeometry(QRect(0, 0, 701, 381));
        label_69->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_80 = new QLabel(AfficherFete);
        label_80->setObjectName(QStringLiteral("label_80"));
        label_80->setGeometry(QRect(0, 330, 61, 51));
        label_80->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        label_84 = new QLabel(AfficherFete);
        label_84->setObjectName(QStringLiteral("label_84"));
        label_84->setGeometry(QRect(280, 300, 411, 121));
        label_84->setPixmap(QPixmap(QString::fromUtf8("../images/photo-enfants.jpg")));
        GestionFete->addTab(AfficherFete, QString());
        label_69->raise();
        label_52->raise();
        tabfete->raise();
        label_20->raise();
        label_27->raise();
        label_32->raise();
        rech_fete->raise();
        label_66->raise();
        pb_rech_fete->raise();
        tri_prix->raise();
        label_80->raise();
        label_84->raise();
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        label_58 = new QLabel(tab);
        label_58->setObjectName(QStringLiteral("label_58"));
        label_58->setGeometry(QRect(200, 20, 261, 31));
        label_58->setFont(font5);
        label_58->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 20pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        line_40 = new QFrame(tab);
        line_40->setObjectName(QStringLiteral("line_40"));
        line_40->setGeometry(QRect(10, 60, 231, 21));
        line_40->setFrameShadow(QFrame::Plain);
        line_40->setFrameShape(QFrame::HLine);
        line_41 = new QFrame(tab);
        line_41->setObjectName(QStringLiteral("line_41"));
        line_41->setGeometry(QRect(10, 160, 231, 21));
        line_41->setFrameShadow(QFrame::Plain);
        line_41->setFrameShape(QFrame::HLine);
        label_59 = new QLabel(tab);
        label_59->setObjectName(QStringLiteral("label_59"));
        label_59->setGeometry(QRect(20, 80, 101, 31));
        label_59->setFont(font3);
        label_59->setStyleSheet(QLatin1String("color: green;\n"
"font:  12pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_61 = new QLabel(tab);
        label_61->setObjectName(QStringLiteral("label_61"));
        label_61->setGeometry(QRect(20, 100, 81, 31));
        label_61->setFont(font6);
        label_61->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  10pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_60 = new QLabel(tab);
        label_60->setObjectName(QStringLiteral("label_60"));
        label_60->setGeometry(QRect(20, 120, 81, 31));
        label_60->setFont(font6);
        label_60->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  10pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        recherche_fete = new QLineEdit(tab);
        recherche_fete->setObjectName(QStringLiteral("recherche_fete"));
        recherche_fete->setGeometry(QRect(110, 90, 111, 31));
        recherche_fete->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        pb_recherche_fete = new QPushButton(tab);
        pb_recherche_fete->setObjectName(QStringLiteral("pb_recherche_fete"));
        pb_recherche_fete->setGeometry(QRect(110, 130, 111, 31));
        pb_recherche_fete->setFont(font1);
        pb_recherche_fete->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        line_43 = new QFrame(tab);
        line_43->setObjectName(QStringLiteral("line_43"));
        line_43->setGeometry(QRect(230, 70, 20, 101));
        line_43->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_43->setFrameShadow(QFrame::Plain);
        line_43->setFrameShape(QFrame::VLine);
        line_42 = new QFrame(tab);
        line_42->setObjectName(QStringLiteral("line_42"));
        line_42->setGeometry(QRect(0, 70, 20, 101));
        line_42->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_42->setFrameShadow(QFrame::Plain);
        line_42->setFrameShape(QFrame::VLine);
        line_44 = new QFrame(tab);
        line_44->setObjectName(QStringLiteral("line_44"));
        line_44->setGeometry(QRect(40, 190, 601, 21));
        line_44->setFrameShadow(QFrame::Plain);
        line_44->setFrameShape(QFrame::HLine);
        line_46 = new QFrame(tab);
        line_46->setObjectName(QStringLiteral("line_46"));
        line_46->setGeometry(QRect(630, 200, 20, 161));
        line_46->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_46->setFrameShadow(QFrame::Plain);
        line_46->setFrameShape(QFrame::VLine);
        line_47 = new QFrame(tab);
        line_47->setObjectName(QStringLiteral("line_47"));
        line_47->setGeometry(QRect(40, 350, 601, 21));
        line_47->setFrameShadow(QFrame::Plain);
        line_47->setFrameShape(QFrame::HLine);
        line_45 = new QFrame(tab);
        line_45->setObjectName(QStringLiteral("line_45"));
        line_45->setGeometry(QRect(30, 200, 20, 161));
        line_45->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_45->setFrameShadow(QFrame::Plain);
        line_45->setFrameShape(QFrame::VLine);
        label_62 = new QLabel(tab);
        label_62->setObjectName(QStringLiteral("label_62"));
        label_62->setGeometry(QRect(60, 210, 131, 31));
        label_62->setFont(font);
        label_62->setStyleSheet(QLatin1String("color: green;\n"
"font:  14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        tabfete_modif = new QTableView(tab);
        tabfete_modif->setObjectName(QStringLiteral("tabfete_modif"));
        tabfete_modif->setGeometry(QRect(250, 70, 421, 101));
        label_63 = new QLabel(tab);
        label_63->setObjectName(QStringLiteral("label_63"));
        label_63->setGeometry(QRect(60, 280, 131, 31));
        label_63->setFont(font);
        label_63->setStyleSheet(QLatin1String("color: green;\n"
"font:  14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        label_64 = new QLabel(tab);
        label_64->setObjectName(QStringLiteral("label_64"));
        label_64->setGeometry(QRect(240, 210, 201, 31));
        label_64->setFont(font);
        label_64->setStyleSheet(QLatin1String("color: green;\n"
"font:  14pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
"\n"
""));
        lineEdit_nom_fete_modif = new QLineEdit(tab);
        lineEdit_nom_fete_modif->setObjectName(QStringLiteral("lineEdit_nom_fete_modif"));
        lineEdit_nom_fete_modif->setGeometry(QRect(60, 240, 131, 31));
        lineEdit_nom_fete_modif->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        lineEdit_prix_fete_modif = new QLineEdit(tab);
        lineEdit_prix_fete_modif->setObjectName(QStringLiteral("lineEdit_prix_fete_modif"));
        lineEdit_prix_fete_modif->setGeometry(QRect(60, 310, 131, 31));
        lineEdit_prix_fete_modif->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        lineEdit_desc_fete_modif = new QLineEdit(tab);
        lineEdit_desc_fete_modif->setObjectName(QStringLiteral("lineEdit_desc_fete_modif"));
        lineEdit_desc_fete_modif->setGeometry(QRect(240, 240, 191, 101));
        lineEdit_desc_fete_modif->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        pb_modifier_fete = new QPushButton(tab);
        pb_modifier_fete->setObjectName(QStringLiteral("pb_modifier_fete"));
        pb_modifier_fete->setGeometry(QRect(480, 260, 111, 51));
        pb_modifier_fete->setFont(font1);
        pb_modifier_fete->setStyleSheet(QLatin1String("color:green;\n"
"font-size:16px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold large \"MV Boli\"\n"
""));
        label_57 = new QLabel(tab);
        label_57->setObjectName(QStringLiteral("label_57"));
        label_57->setGeometry(QRect(0, 0, 701, 381));
        label_57->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_81 = new QLabel(tab);
        label_81->setObjectName(QStringLiteral("label_81"));
        label_81->setGeometry(QRect(640, 330, 61, 51));
        label_81->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        GestionFete->addTab(tab, QString());
        label_57->raise();
        label_58->raise();
        line_41->raise();
        label_60->raise();
        label_61->raise();
        label_59->raise();
        recherche_fete->raise();
        line_40->raise();
        pb_recherche_fete->raise();
        line_43->raise();
        line_42->raise();
        line_44->raise();
        line_46->raise();
        line_47->raise();
        line_45->raise();
        label_62->raise();
        tabfete_modif->raise();
        label_63->raise();
        label_64->raise();
        lineEdit_nom_fete_modif->raise();
        lineEdit_prix_fete_modif->raise();
        lineEdit_desc_fete_modif->raise();
        pb_modifier_fete->raise();
        label_81->raise();
        SupprimerFete = new QWidget();
        SupprimerFete->setObjectName(QStringLiteral("SupprimerFete"));
        label_12 = new QLabel(SupprimerFete);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(170, 170, 131, 31));
        QFont font11;
        font11.setFamily(QStringLiteral("MV Boli"));
        font11.setPointSize(18);
        font11.setBold(false);
        font11.setItalic(false);
        font11.setWeight(50);
        label_12->setFont(font11);
        label_12->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  18pt \"MV Boli\";\n"
"\n"
""));
        line_19 = new QFrame(SupprimerFete);
        line_19->setObjectName(QStringLiteral("line_19"));
        line_19->setGeometry(QRect(120, 140, 20, 111));
        line_19->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_19->setFrameShadow(QFrame::Plain);
        line_19->setFrameShape(QFrame::VLine);
        line_20 = new QFrame(SupprimerFete);
        line_20->setObjectName(QStringLiteral("line_20"));
        line_20->setGeometry(QRect(510, 140, 20, 111));
        line_20->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
""));
        line_20->setFrameShadow(QFrame::Plain);
        line_20->setFrameShape(QFrame::VLine);
        line_21 = new QFrame(SupprimerFete);
        line_21->setObjectName(QStringLiteral("line_21"));
        line_21->setGeometry(QRect(130, 130, 391, 21));
        line_21->setFrameShadow(QFrame::Plain);
        line_21->setFrameShape(QFrame::HLine);
        line_22 = new QFrame(SupprimerFete);
        line_22->setObjectName(QStringLiteral("line_22"));
        line_22->setGeometry(QRect(130, 240, 391, 21));
        line_22->setFrameShadow(QFrame::Plain);
        line_22->setFrameShape(QFrame::HLine);
        label_21 = new QLabel(SupprimerFete);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(160, 40, 351, 41));
        QFont font12;
        font12.setFamily(QStringLiteral("MV Boli"));
        font12.setPointSize(24);
        font12.setBold(true);
        font12.setItalic(false);
        font12.setWeight(75);
        label_21->setFont(font12);
        label_21->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 24pt \"MV Boli\";\n"
"background: white\n"
"\n"
""));
        label_22 = new QLabel(SupprimerFete);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(240, 80, 211, 31));
        label_22->setFont(font3);
        label_22->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"background: white;\n"
""));
        label_23 = new QLabel(SupprimerFete);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(250, 100, 191, 31));
        label_23->setFont(font3);
        label_23->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"font:  12pt \"MV Boli\";\n"
"\n"
""));
        pb_supprimer_2 = new QPushButton(SupprimerFete);
        pb_supprimer_2->setObjectName(QStringLiteral("pb_supprimer_2"));
        pb_supprimer_2->setGeometry(QRect(280, 270, 101, 31));
        pb_supprimer_2->setFont(font1);
        pb_supprimer_2->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font:bold  large \"MV Boli\"\n"
""));
        label_28 = new QLabel(SupprimerFete);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(-10, 340, 51, 41));
        label_28->setPixmap(QPixmap(QString::fromUtf8(":/logo (1) (1) (1).png")));
        label_53 = new QLabel(SupprimerFete);
        label_53->setObjectName(QStringLiteral("label_53"));
        label_53->setGeometry(QRect(0, -320, 691, 761));
        label_53->setPixmap(QPixmap(QString::fromUtf8(":/Desktop/Wallpaper-MuffinMani_Confetti_1.jpg")));
        comboBoxsupp2 = new QComboBox(SupprimerFete);
        comboBoxsupp2->setObjectName(QStringLiteral("comboBoxsupp2"));
        comboBoxsupp2->setGeometry(QRect(330, 180, 141, 31));
        label_68 = new QLabel(SupprimerFete);
        label_68->setObjectName(QStringLiteral("label_68"));
        label_68->setGeometry(QRect(0, 0, 701, 391));
        label_68->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_82 = new QLabel(SupprimerFete);
        label_82->setObjectName(QStringLiteral("label_82"));
        label_82->setGeometry(QRect(0, 330, 61, 51));
        label_82->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        label_85 = new QLabel(SupprimerFete);
        label_85->setObjectName(QStringLiteral("label_85"));
        label_85->setGeometry(QRect(490, 240, 271, 161));
        label_85->setPixmap(QPixmap(QString::fromUtf8("../images/kindergarten-kids-png-1 (1).png")));
        GestionFete->addTab(SupprimerFete, QString());
        label_68->raise();
        label_53->raise();
        label_12->raise();
        line_19->raise();
        line_20->raise();
        line_21->raise();
        line_22->raise();
        label_21->raise();
        label_22->raise();
        label_23->raise();
        pb_supprimer_2->raise();
        label_28->raise();
        comboBoxsupp2->raise();
        label_82->raise();
        label_85->raise();
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        widget = new PieChartWidget(tab_2);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(40, 70, 300, 300));
        widget->setMinimumSize(QSize(300, 300));
        widget->setMaximumSize(QSize(300, 300));
        a_2 = new QLineEdit(tab_2);
        a_2->setObjectName(QStringLiteral("a_2"));
        a_2->setGeometry(QRect(430, 190, 31, 31));
        a_2->setStyleSheet(QLatin1String(" border-style: inset;\n"
"background-color:green;\n"
"  border-color: green;\n"
"  border-width: 7px;\n"
"\n"
"color: green;\n"
""));
        a = new QLineEdit(tab_2);
        a->setObjectName(QStringLiteral("a"));
        a->setGeometry(QRect(430, 240, 31, 31));
        a->setStyleSheet(QLatin1String(" border-style: inset;\n"
"background-color: rgb(255, 255, 0);\n"
"  border-color: yellow;\n"
"  border-width: 7px;\n"
"\n"
"color: yellow\n"
""));
        label_70 = new QLabel(tab_2);
        label_70->setObjectName(QStringLiteral("label_70"));
        label_70->setGeometry(QRect(410, 130, 211, 31));
        label_70->setFont(font5);
        label_70->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 20pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        label_42 = new QLabel(tab_2);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setGeometry(QRect(500, 190, 111, 31));
        label_42->setFont(font3);
        label_42->setStyleSheet(QLatin1String("color: black;\n"
"font:  12pt \"MV Boli\";\n"
"background: white;\n"
"\n"
""));
        label_41 = new QLabel(tab_2);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(500, 240, 111, 31));
        label_41->setFont(font3);
        label_41->setStyleSheet(QLatin1String("color: black;\n"
"font:  12pt \"MV Boli\";\n"
"\n"
""));
        line_48 = new QFrame(tab_2);
        line_48->setObjectName(QStringLiteral("line_48"));
        line_48->setGeometry(QRect(410, 170, 211, 20));
        line_48->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_48->setFrameShadow(QFrame::Plain);
        line_48->setFrameShape(QFrame::HLine);
        line_49 = new QFrame(tab_2);
        line_49->setObjectName(QStringLiteral("line_49"));
        line_49->setGeometry(QRect(410, 220, 211, 20));
        line_49->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_49->setFrameShadow(QFrame::Plain);
        line_49->setFrameShape(QFrame::HLine);
        line_50 = new QFrame(tab_2);
        line_50->setObjectName(QStringLiteral("line_50"));
        line_50->setGeometry(QRect(410, 270, 211, 20));
        line_50->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_50->setFrameShadow(QFrame::Plain);
        line_50->setFrameShape(QFrame::HLine);
        line_51 = new QFrame(tab_2);
        line_51->setObjectName(QStringLiteral("line_51"));
        line_51->setGeometry(QRect(400, 180, 20, 101));
        line_51->setFrameShadow(QFrame::Plain);
        line_51->setFrameShape(QFrame::VLine);
        line_52 = new QFrame(tab_2);
        line_52->setObjectName(QStringLiteral("line_52"));
        line_52->setGeometry(QRect(470, 180, 20, 101));
        line_52->setFrameShadow(QFrame::Plain);
        line_52->setFrameShape(QFrame::VLine);
        line_53 = new QFrame(tab_2);
        line_53->setObjectName(QStringLiteral("line_53"));
        line_53->setGeometry(QRect(610, 180, 20, 101));
        line_53->setFrameShadow(QFrame::Plain);
        line_53->setFrameShape(QFrame::VLine);
        label_40 = new QLabel(tab_2);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(440, 70, 161, 111));
        label_40->setPixmap(QPixmap(QString::fromUtf8("../../../../../Downloads/e67d03c3 (1) (1) (1) (1).png")));
        label_67 = new QLabel(tab_2);
        label_67->setObjectName(QStringLiteral("label_67"));
        label_67->setGeometry(QRect(0, 0, 691, 381));
        label_67->setPixmap(QPixmap(QString::fromUtf8("../../../../../Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_76 = new QLabel(tab_2);
        label_76->setObjectName(QStringLiteral("label_76"));
        label_76->setGeometry(QRect(260, 10, 171, 41));
        label_76->setFont(font5);
        label_76->setStyleSheet(QLatin1String("color: green;\n"
"font: bold 20pt \"MV Boli\";\n"
"background-color:white;\n"
"\n"
""));
        label_83 = new QLabel(tab_2);
        label_83->setObjectName(QStringLiteral("label_83"));
        label_83->setGeometry(QRect(640, 330, 61, 51));
        label_83->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        GestionFete->addTab(tab_2, QString());
        label_67->raise();
        widget->raise();
        a_2->raise();
        a->raise();
        label_70->raise();
        label_42->raise();
        label_41->raise();
        line_48->raise();
        line_49->raise();
        line_50->raise();
        line_51->raise();
        line_52->raise();
        line_53->raise();
        label_40->raise();
        label_76->raise();
        label_83->raise();
        tabWidget->addTab(Fete, QString());

        retranslateUi(Dialog);

        tabWidget->setCurrentIndex(1);
        GestionEvent->setCurrentIndex(0);
        GestionFete->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", nullptr));
        label->setText(QApplication::translate("Dialog", "Identifiant", nullptr));
        label_5->setText(QApplication::translate("Dialog", "Nom", nullptr));
        label_6->setText(QApplication::translate("Dialog", "Date", nullptr));
        label_7->setText(QApplication::translate("Dialog", "ID fete", nullptr));
        pb_ajouter->setText(QApplication::translate("Dialog", "Ajouter", nullptr));
        label_2->setText(QApplication::translate("Dialog", "Ajouter un \303\251v\303\251nement:", nullptr));
        label_14->setText(QString());
        label_15->setText(QString());
        label_33->setText(QApplication::translate("Dialog", "Veuillez remplir le formulaire d'ajout", nullptr));
        label_34->setText(QString());
        label_36->setText(QString());
        label_72->setText(QString());
        label_37->setText(QString());
        label_50->setText(QString());
        GestionEvent->setTabText(GestionEvent->indexOf(AjouterEvent), QApplication::translate("Dialog", "Ajouter Event", nullptr));
        label_19->setText(QApplication::translate("Dialog", "Liste des \303\251v\303\251nements:", nullptr));
        label_24->setText(QString());
        label_29->setText(QString());
        label_43->setText(QString());
        label_65->setText(QApplication::translate("Dialog", "id", nullptr));
        pb_rech_ev->setText(QApplication::translate("Dialog", "Rechercher", nullptr));
        tri_date->setText(QApplication::translate("Dialog", "Tri par fete affect\303\251e", nullptr));
        label_73->setText(QString());
        label_48->setText(QString());
        label_51->setText(QString());
        GestionEvent->setTabText(GestionEvent->indexOf(AfficherEvent), QApplication::translate("Dialog", "Afficher Event", nullptr));
        label_31->setText(QApplication::translate("Dialog", "Modifier un \303\251v\303\251nement:", nullptr));
        label_55->setText(QString());
        label_38->setText(QApplication::translate("Dialog", "de l'\303\251v\303\251nement ", nullptr));
        label_39->setText(QApplication::translate("Dialog", "\303\240 modifier", nullptr));
        label_44->setText(QApplication::translate("Dialog", "Identifiant", nullptr));
        pb_recherche_ev->setText(QApplication::translate("Dialog", "Effectuer", nullptr));
        label_45->setText(QApplication::translate("Dialog", "Nouveau Nom:", nullptr));
        label_46->setText(QApplication::translate("Dialog", "Nouvelle Date:", nullptr));
        label_47->setText(QApplication::translate("Dialog", "Nouvelle Fete :", nullptr));
        label_56->setText(QApplication::translate("Dialog", "(id)", nullptr));
        pb_modifier_ev->setText(QApplication::translate("Dialog", "Modifier", nullptr));
        label_74->setText(QString());
        label_77->setText(QString());
        GestionEvent->setTabText(GestionEvent->indexOf(Modifierevent), QApplication::translate("Dialog", "Modifier Event", nullptr));
        label_3->setText(QApplication::translate("Dialog", "Identifiant", nullptr));
        label_16->setText(QApplication::translate("Dialog", "Supprimer un \303\251v\303\251nement:", nullptr));
        label_17->setText(QApplication::translate("Dialog", "Entrer l'identifiant de", nullptr));
        label_18->setText(QApplication::translate("Dialog", "l'\303\251v\303\251nement \303\240 supprimer:", nullptr));
        pb_supprimer->setText(QApplication::translate("Dialog", "Supprimer", nullptr));
        label_25->setText(QString());
        label_30->setText(QString());
        label_54->setText(QString());
        label_75->setText(QString());
        label_78->setText(QString());
        label_86->setText(QString());
        GestionEvent->setTabText(GestionEvent->indexOf(SupprimerEvent), QApplication::translate("Dialog", "Supprimer Event", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Evenement), QApplication::translate("Dialog", "Gestion des \303\251v\303\251nements.", nullptr));
        label_4->setText(QApplication::translate("Dialog", "Identifiant", nullptr));
        label_8->setText(QApplication::translate("Dialog", "Prix ", nullptr));
        label_10->setText(QApplication::translate("Dialog", "Description", nullptr));
        pb_ajouter_2->setText(QApplication::translate("Dialog", "Ajouter", nullptr));
        label_11->setText(QApplication::translate("Dialog", "Ajouter une F\303\252te", nullptr));
        label_9->setText(QApplication::translate("Dialog", "(Estim\303\251)", nullptr));
        label_13->setText(QApplication::translate("Dialog", "Nom", nullptr));
        label_26->setText(QString());
        label_35->setText(QApplication::translate("Dialog", "Veuillez remplir le formulaire d'ajout", nullptr));
        label_71->setText(QString());
        label_79->setText(QString());
        label_49->setText(QString());
        GestionFete->setTabText(GestionFete->indexOf(AjouterFete), QApplication::translate("Dialog", "Ajouter F\303\252te", nullptr));
        label_20->setText(QApplication::translate("Dialog", "Liste des F\303\252tes:", nullptr));
        label_27->setText(QString());
        label_32->setText(QString());
        label_52->setText(QString());
        label_66->setText(QApplication::translate("Dialog", "id", nullptr));
        pb_rech_fete->setText(QApplication::translate("Dialog", "Rechercher", nullptr));
        tri_prix->setText(QApplication::translate("Dialog", "Trier par prix", nullptr));
        label_69->setText(QString());
        label_80->setText(QString());
        label_84->setText(QString());
        GestionFete->setTabText(GestionFete->indexOf(AfficherFete), QApplication::translate("Dialog", "Afficher F\303\252te", nullptr));
        label_58->setText(QApplication::translate("Dialog", "Modifier une Fete", nullptr));
        label_59->setText(QApplication::translate("Dialog", "Identifiant", nullptr));
        label_61->setText(QApplication::translate("Dialog", "de la fete", nullptr));
        label_60->setText(QApplication::translate("Dialog", "\303\240 modifier", nullptr));
        pb_recherche_fete->setText(QApplication::translate("Dialog", "Effectuer", nullptr));
        label_62->setText(QApplication::translate("Dialog", "Nouveau Nom", nullptr));
        label_63->setText(QApplication::translate("Dialog", "Nouveau Prix", nullptr));
        label_64->setText(QApplication::translate("Dialog", "Nouvelle Description", nullptr));
        pb_modifier_fete->setText(QApplication::translate("Dialog", "Modifier", nullptr));
        label_57->setText(QString());
        label_81->setText(QString());
        GestionFete->setTabText(GestionFete->indexOf(tab), QApplication::translate("Dialog", "Modifier Fete", nullptr));
        label_12->setText(QApplication::translate("Dialog", "Identifiant", nullptr));
        label_21->setText(QApplication::translate("Dialog", "Supprimer une F\303\252te:", nullptr));
        label_22->setText(QApplication::translate("Dialog", "Entrer l'identifiant de", nullptr));
        label_23->setText(QApplication::translate("Dialog", "la f\303\252te \303\240 supprimer:", nullptr));
        pb_supprimer_2->setText(QApplication::translate("Dialog", "Supprimer", nullptr));
        label_28->setText(QString());
        label_53->setText(QString());
        label_68->setText(QString());
        label_82->setText(QString());
        label_85->setText(QString());
        GestionFete->setTabText(GestionFete->indexOf(SupprimerFete), QApplication::translate("Dialog", "Supprimer F\303\252te", nullptr));
        label_70->setText(QApplication::translate("Dialog", "Fete qui coute:", nullptr));
        label_42->setText(QApplication::translate("Dialog", "- que 200 dt", nullptr));
        label_41->setText(QApplication::translate("Dialog", "+ que 200 dt", nullptr));
        label_40->setText(QString());
        label_67->setText(QString());
        label_76->setText(QApplication::translate("Dialog", "Statistiques", nullptr));
        label_83->setText(QString());
        GestionFete->setTabText(GestionFete->indexOf(tab_2), QApplication::translate("Dialog", "Statistiques", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Fete), QApplication::translate("Dialog", "Gestion des f\303\252tes.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_D_EV_H
