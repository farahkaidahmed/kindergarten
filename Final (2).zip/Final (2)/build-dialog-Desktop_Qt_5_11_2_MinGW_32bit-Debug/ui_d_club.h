/********************************************************************************
** Form generated from reading UI file 'd_club.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_D_CLUB_H
#define UI_D_CLUB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>
#include "piechart.h"

QT_BEGIN_NAMESPACE

class Ui_Dialog1
{
public:
    QTabWidget *tabWidget_2;
    QWidget *tab_4;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLineEdit *lineEdit_nom;
    QLineEdit *lineEdit_id;
    QLineEdit *lineEdit_prix;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pb_ajouter;
    QLabel *label_11;
    QComboBox *comboBox;
    QLabel *label_50;
    QLabel *label_36;
    QLabel *label_25;
    QLabel *label_34;
    QWidget *tab_2;
    QTableView *tabclub;
    QLabel *label_5;
    QPushButton *pb_supprimer;
    QLabel *label_12;
    QComboBox *comboBox_3;
    QLabel *label_23;
    QLabel *label_24;
    QComboBox *comboBox_4;
    QTableView *tabclub_2;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QComboBox *comboBox_5;
    QLabel *label_51;
    QLabel *label_48;
    QLabel *label_39;
    QLabel *label_26;
    QWidget *tab_9;
    QLabel *label_15;
    QLabel *label_9;
    QLineEdit *lineEdit_id_modif;
    QPushButton *pb_modifier;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLineEdit *lineEdit_nom_modif;
    QLineEdit *lineEdit_prix_modif;
    QComboBox *comboBox_2;
    QLabel *label_49;
    QLabel *label_52;
    QLabel *label_40;
    QLabel *label_29;
    QLabel *label_37;
    QWidget *tab_3;
    pieChart *widget;
    QLabel *label_53;
    QLabel *label_41;
    QLineEdit *a_2;
    QLineEdit *a;
    QLabel *label_42;
    QLabel *label_43;
    QLabel *label_30;
    QLabel *label_79;
    QWidget *tab_5;
    QTabWidget *tabWidget_3;
    QWidget *tab_6;
    QLineEdit *lineEdit_num_s;
    QLineEdit *lineEdit_nom_s;
    QLineEdit *lineEdit_max_s;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QPushButton *pb_ajouter_s;
    QLabel *label_14;
    QLabel *label_38;
    QLabel *label_31;
    QLabel *label_35;
    QWidget *tab_7;
    QTableView *tabsalle;
    QLabel *label_13;
    QPushButton *pb_supprimer_s;
    QLabel *label_10;
    QComboBox *comboBox_6;
    QLabel *label_27;
    QLabel *label_28;
    QTableView *tabsalle_2;
    QComboBox *comboBox_7;
    QPushButton *pb_chercher_s;
    QPushButton *pb_trier_s;
    QComboBox *comboBox_8;
    QLabel *label_55;
    QLabel *label_45;
    QLabel *label_32;
    QWidget *tab_10;
    QLabel *label_16;
    QLabel *label_17;
    QLineEdit *lineEdit_num_modif_s;
    QPushButton *pb_modifier_s;
    QLabel *label_21;
    QLabel *label_22;
    QLineEdit *lineEdit_nom_modif_s;
    QLineEdit *lineEdit_max_modif_s;
    QLabel *label_56;
    QLabel *label_46;
    QLabel *label_33;
    QLabel *label_44;
    QLabel *label_54;
    QLabel *label_80;

    void setupUi(QDialog *Dialog1)
    {
        if (Dialog1->objectName().isEmpty())
            Dialog1->setObjectName(QStringLiteral("Dialog1"));
        Dialog1->resize(481, 432);
        tabWidget_2 = new QTabWidget(Dialog1);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setGeometry(QRect(0, 0, 601, 431));
        tabWidget_2->setStyleSheet(QStringLiteral("background-image: url(:/kinder.jpg);"));
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        tabWidget = new QTabWidget(tab_4);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 481, 431));
        tabWidget->setStyleSheet(QStringLiteral(""));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        lineEdit_nom = new QLineEdit(tab);
        lineEdit_nom->setObjectName(QStringLiteral("lineEdit_nom"));
        lineEdit_nom->setGeometry(QRect(150, 109, 113, 31));
        lineEdit_nom->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        lineEdit_id = new QLineEdit(tab);
        lineEdit_id->setObjectName(QStringLiteral("lineEdit_id"));
        lineEdit_id->setGeometry(QRect(150, 160, 113, 31));
        lineEdit_id->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        lineEdit_prix = new QLineEdit(tab);
        lineEdit_prix->setObjectName(QStringLiteral("lineEdit_prix"));
        lineEdit_prix->setGeometry(QRect(150, 210, 113, 31));
        lineEdit_prix->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 110, 101, 21));
        label->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 160, 101, 21));
        label_2->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 210, 101, 21));
        label_3->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_4 = new QLabel(tab);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 260, 101, 21));
        label_4->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        pb_ajouter = new QPushButton(tab);
        pb_ajouter->setObjectName(QStringLiteral("pb_ajouter"));
        pb_ajouter->setGeometry(QRect(270, 310, 81, 31));
        pb_ajouter->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        label_11 = new QLabel(tab);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(0, 40, 461, 61));
        label_11->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        comboBox = new QComboBox(tab);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(150, 260, 111, 31));
        label_50 = new QLabel(tab);
        label_50->setObjectName(QStringLiteral("label_50"));
        label_50->setGeometry(QRect(0, 340, 61, 51));
        label_50->setPixmap(QPixmap(QString::fromUtf8("../Final/images/logo (1) (1) (1).png")));
        label_36 = new QLabel(tab);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(-10, 0, 491, 391));
        label_36->setPixmap(QPixmap(QString::fromUtf8("../Final/images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_25 = new QLabel(tab);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(0, 0, 601, 411));
        label_34 = new QLabel(tab);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(160, 0, 201, 71));
        tabWidget->addTab(tab, QString());
        label_25->raise();
        label_36->raise();
        lineEdit_nom->raise();
        lineEdit_id->raise();
        lineEdit_prix->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        pb_ajouter->raise();
        label_11->raise();
        comboBox->raise();
        label_50->raise();
        label_34->raise();
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabclub = new QTableView(tab_2);
        tabclub->setObjectName(QStringLiteral("tabclub"));
        tabclub->setGeometry(QRect(10, 30, 461, 161));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 220, 111, 21));
        label_5->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        pb_supprimer = new QPushButton(tab_2);
        pb_supprimer->setObjectName(QStringLiteral("pb_supprimer"));
        pb_supprimer->setGeometry(QRect(130, 250, 91, 31));
        pb_supprimer->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        label_12 = new QLabel(tab_2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(0, 190, 171, 41));
        label_12->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        comboBox_3 = new QComboBox(tab_2);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(8, 250, 121, 31));
        label_23 = new QLabel(tab_2);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(240, 190, 171, 41));
        label_23->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_24 = new QLabel(tab_2);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(260, 220, 111, 21));
        label_24->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        comboBox_4 = new QComboBox(tab_2);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(260, 250, 121, 31));
        tabclub_2 = new QTableView(tab_2);
        tabclub_2->setObjectName(QStringLiteral("tabclub_2"));
        tabclub_2->setGeometry(QRect(10, 280, 461, 51));
        pushButton_2 = new QPushButton(tab_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(350, 0, 121, 31));
        pushButton_2->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(380, 250, 91, 31));
        pushButton->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        comboBox_5 = new QComboBox(tab_2);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setGeometry(QRect(250, 0, 101, 31));
        label_51 = new QLabel(tab_2);
        label_51->setObjectName(QStringLiteral("label_51"));
        label_51->setGeometry(QRect(0, 340, 61, 51));
        label_51->setPixmap(QPixmap(QString::fromUtf8("../Final/images/logo (1) (1) (1).png")));
        label_48 = new QLabel(tab_2);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setGeometry(QRect(250, 330, 201, 71));
        label_48->setPixmap(QPixmap(QString::fromUtf8("../Final/images/kindergarten-png-transparent-images-pictures-photos-png-arts-kindergarten-png-images-602_312.png")));
        label_39 = new QLabel(tab_2);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(-10, 0, 491, 401));
        label_39->setPixmap(QPixmap(QString::fromUtf8("../Final/images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_26 = new QLabel(tab_2);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(-10, 0, 601, 411));
        tabWidget->addTab(tab_2, QString());
        label_26->raise();
        label_39->raise();
        tabclub->raise();
        label_5->raise();
        pb_supprimer->raise();
        label_12->raise();
        comboBox_3->raise();
        label_23->raise();
        label_24->raise();
        comboBox_4->raise();
        tabclub_2->raise();
        pushButton_2->raise();
        pushButton->raise();
        comboBox_5->raise();
        label_51->raise();
        label_48->raise();
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        label_15 = new QLabel(tab_9);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(0, 10, 461, 61));
        label_15->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_9 = new QLabel(tab_9);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(40, 100, 111, 21));
        label_9->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        lineEdit_id_modif = new QLineEdit(tab_9);
        lineEdit_id_modif->setObjectName(QStringLiteral("lineEdit_id_modif"));
        lineEdit_id_modif->setGeometry(QRect(200, 100, 113, 31));
        lineEdit_id_modif->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        pb_modifier = new QPushButton(tab_9);
        pb_modifier->setObjectName(QStringLiteral("pb_modifier"));
        pb_modifier->setGeometry(QRect(330, 310, 91, 31));
        pb_modifier->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        label_18 = new QLabel(tab_9);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(40, 150, 121, 21));
        label_18->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_19 = new QLabel(tab_9);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(40, 200, 121, 21));
        label_19->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_20 = new QLabel(tab_9);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(40, 250, 171, 21));
        label_20->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        lineEdit_nom_modif = new QLineEdit(tab_9);
        lineEdit_nom_modif->setObjectName(QStringLiteral("lineEdit_nom_modif"));
        lineEdit_nom_modif->setGeometry(QRect(200, 150, 113, 31));
        lineEdit_nom_modif->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        lineEdit_prix_modif = new QLineEdit(tab_9);
        lineEdit_prix_modif->setObjectName(QStringLiteral("lineEdit_prix_modif"));
        lineEdit_prix_modif->setGeometry(QRect(200, 200, 113, 31));
        lineEdit_prix_modif->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        comboBox_2 = new QComboBox(tab_9);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(200, 250, 111, 31));
        label_49 = new QLabel(tab_9);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setGeometry(QRect(170, 70, 301, 301));
        label_49->setPixmap(QPixmap(QString::fromUtf8("../Final/images/PolishedJointCopperbutterfly-size_restricted.gif")));
        label_52 = new QLabel(tab_9);
        label_52->setObjectName(QStringLiteral("label_52"));
        label_52->setGeometry(QRect(0, 340, 61, 51));
        label_52->setPixmap(QPixmap(QString::fromUtf8("../Final/images/logo (1) (1) (1).png")));
        label_40 = new QLabel(tab_9);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(-10, 0, 491, 401));
        label_40->setPixmap(QPixmap(QString::fromUtf8("../Final/images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_29 = new QLabel(tab_9);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(-10, 0, 601, 411));
        label_37 = new QLabel(tab_9);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(150, 100, 291, 221));
        tabWidget->addTab(tab_9, QString());
        label_29->raise();
        label_40->raise();
        label_15->raise();
        label_9->raise();
        lineEdit_id_modif->raise();
        pb_modifier->raise();
        label_18->raise();
        label_19->raise();
        label_20->raise();
        lineEdit_nom_modif->raise();
        lineEdit_prix_modif->raise();
        comboBox_2->raise();
        label_49->raise();
        label_52->raise();
        label_37->raise();
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        widget = new pieChart(tab_3);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(30, 60, 401, 321));
        label_53 = new QLabel(tab_3);
        label_53->setObjectName(QStringLiteral("label_53"));
        label_53->setGeometry(QRect(0, 340, 61, 51));
        label_53->setPixmap(QPixmap(QString::fromUtf8("../Final/images/logo (1) (1) (1).png")));
        label_41 = new QLabel(tab_3);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(50, 40, 101, 21));
        QFont font;
        font.setFamily(QStringLiteral("MV Boli"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        label_41->setFont(font);
        label_41->setStyleSheet(QLatin1String("color: black;\n"
"font:  12pt \"MV Boli\";\n"
"background: white;\n"
""));
        a_2 = new QLineEdit(tab_3);
        a_2->setObjectName(QStringLiteral("a_2"));
        a_2->setGeometry(QRect(20, 10, 21, 21));
        a_2->setStyleSheet(QLatin1String(" border-style: inset;\n"
"background-color:green;\n"
"  border-color: green;\n"
"  border-width: 7px;\n"
"\n"
"color: green;\n"
""));
        a = new QLineEdit(tab_3);
        a->setObjectName(QStringLiteral("a"));
        a->setGeometry(QRect(20, 40, 21, 21));
        a->setStyleSheet(QLatin1String(" border-style: inset;\n"
"background-color: rgb(255, 255, 0);\n"
"  border-color: yellow;\n"
"  border-width: 7px;\n"
"\n"
"color: yellow\n"
""));
        label_42 = new QLabel(tab_3);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setGeometry(QRect(50, 10, 101, 21));
        label_42->setFont(font);
        label_42->setStyleSheet(QLatin1String("color: black;\n"
"font:  12pt \"MV Boli\";\n"
"background: white;\n"
"\n"
""));
        label_43 = new QLabel(tab_3);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(-10, 0, 491, 401));
        label_43->setPixmap(QPixmap(QString::fromUtf8("../Final/images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_30 = new QLabel(tab_3);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(-10, 0, 601, 411));
        tabWidget->addTab(tab_3, QString());
        label_30->raise();
        label_43->raise();
        widget->raise();
        label_53->raise();
        label_41->raise();
        a_2->raise();
        a->raise();
        label_42->raise();
        label_79 = new QLabel(tab_4);
        label_79->setObjectName(QStringLiteral("label_79"));
        label_79->setGeometry(QRect(0, 360, 51, 51));
        label_79->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        tabWidget_2->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        tabWidget_3 = new QTabWidget(tab_5);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(0, 0, 511, 421));
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        lineEdit_num_s = new QLineEdit(tab_6);
        lineEdit_num_s->setObjectName(QStringLiteral("lineEdit_num_s"));
        lineEdit_num_s->setGeometry(QRect(150, 110, 113, 31));
        lineEdit_num_s->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        lineEdit_nom_s = new QLineEdit(tab_6);
        lineEdit_nom_s->setObjectName(QStringLiteral("lineEdit_nom_s"));
        lineEdit_nom_s->setGeometry(QRect(150, 160, 113, 31));
        lineEdit_nom_s->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        lineEdit_max_s = new QLineEdit(tab_6);
        lineEdit_max_s->setObjectName(QStringLiteral("lineEdit_max_s"));
        lineEdit_max_s->setGeometry(QRect(150, 210, 113, 31));
        lineEdit_max_s->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        label_6 = new QLabel(tab_6);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(40, 110, 101, 21));
        label_6->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_7 = new QLabel(tab_6);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(40, 160, 101, 21));
        label_7->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_8 = new QLabel(tab_6);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(40, 210, 101, 21));
        label_8->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        pb_ajouter_s = new QPushButton(tab_6);
        pb_ajouter_s->setObjectName(QStringLiteral("pb_ajouter_s"));
        pb_ajouter_s->setGeometry(QRect(270, 260, 81, 31));
        pb_ajouter_s->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        label_14 = new QLabel(tab_6);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(0, 30, 461, 61));
        label_14->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_38 = new QLabel(tab_6);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(160, 0, 171, 101));
        label_38->setPixmap(QPixmap(QString::fromUtf8("../Final/images/e67d03c3 (1) (1) (1) (1).png")));
        label_31 = new QLabel(tab_6);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(-10, 0, 601, 411));
        label_35 = new QLabel(tab_6);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(170, 0, 201, 71));
        tabWidget_3->addTab(tab_6, QString());
        label_31->raise();
        lineEdit_num_s->raise();
        lineEdit_nom_s->raise();
        lineEdit_max_s->raise();
        label_6->raise();
        label_7->raise();
        label_8->raise();
        pb_ajouter_s->raise();
        label_14->raise();
        label_38->raise();
        label_35->raise();
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        tabsalle = new QTableView(tab_7);
        tabsalle->setObjectName(QStringLiteral("tabsalle"));
        tabsalle->setGeometry(QRect(0, 30, 471, 171));
        label_13 = new QLabel(tab_7);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(0, 200, 201, 31));
        label_13->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        pb_supprimer_s = new QPushButton(tab_7);
        pb_supprimer_s->setObjectName(QStringLiteral("pb_supprimer_s"));
        pb_supprimer_s->setGeometry(QRect(130, 260, 91, 31));
        pb_supprimer_s->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        label_10 = new QLabel(tab_7);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(20, 230, 71, 21));
        label_10->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        comboBox_6 = new QComboBox(tab_7);
        comboBox_6->setObjectName(QStringLiteral("comboBox_6"));
        comboBox_6->setGeometry(QRect(20, 260, 111, 31));
        label_27 = new QLabel(tab_7);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(240, 200, 201, 31));
        label_27->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_28 = new QLabel(tab_7);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(270, 230, 71, 21));
        label_28->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        tabsalle_2 = new QTableView(tab_7);
        tabsalle_2->setObjectName(QStringLiteral("tabsalle_2"));
        tabsalle_2->setGeometry(QRect(0, 290, 471, 51));
        comboBox_7 = new QComboBox(tab_7);
        comboBox_7->setObjectName(QStringLiteral("comboBox_7"));
        comboBox_7->setGeometry(QRect(270, 260, 111, 31));
        pb_chercher_s = new QPushButton(tab_7);
        pb_chercher_s->setObjectName(QStringLiteral("pb_chercher_s"));
        pb_chercher_s->setGeometry(QRect(380, 260, 91, 31));
        pb_chercher_s->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        pb_trier_s = new QPushButton(tab_7);
        pb_trier_s->setObjectName(QStringLiteral("pb_trier_s"));
        pb_trier_s->setGeometry(QRect(350, 0, 121, 31));
        pb_trier_s->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        comboBox_8 = new QComboBox(tab_7);
        comboBox_8->setObjectName(QStringLiteral("comboBox_8"));
        comboBox_8->setGeometry(QRect(260, 0, 91, 31));
        label_55 = new QLabel(tab_7);
        label_55->setObjectName(QStringLiteral("label_55"));
        label_55->setGeometry(QRect(250, 340, 201, 71));
        label_55->setPixmap(QPixmap(QString::fromUtf8("../Final/images/kindergarten-png-transparent-images-pictures-photos-png-arts-kindergarten-png-images-602_312.png")));
        label_45 = new QLabel(tab_7);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(-10, 0, 491, 401));
        label_45->setPixmap(QPixmap(QString::fromUtf8("../Final/images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_32 = new QLabel(tab_7);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(-20, -10, 601, 411));
        tabWidget_3->addTab(tab_7, QString());
        label_32->raise();
        label_45->raise();
        tabsalle->raise();
        label_13->raise();
        pb_supprimer_s->raise();
        label_10->raise();
        comboBox_6->raise();
        label_27->raise();
        label_28->raise();
        tabsalle_2->raise();
        comboBox_7->raise();
        pb_chercher_s->raise();
        pb_trier_s->raise();
        comboBox_8->raise();
        label_55->raise();
        tab_10 = new QWidget();
        tab_10->setObjectName(QStringLiteral("tab_10"));
        label_16 = new QLabel(tab_10);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(0, 30, 471, 61));
        label_16->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_17 = new QLabel(tab_10);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(40, 120, 111, 21));
        label_17->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        lineEdit_num_modif_s = new QLineEdit(tab_10);
        lineEdit_num_modif_s->setObjectName(QStringLiteral("lineEdit_num_modif_s"));
        lineEdit_num_modif_s->setGeometry(QRect(170, 120, 113, 31));
        lineEdit_num_modif_s->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        pb_modifier_s = new QPushButton(tab_10);
        pb_modifier_s->setObjectName(QStringLiteral("pb_modifier_s"));
        pb_modifier_s->setGeometry(QRect(300, 280, 91, 31));
        pb_modifier_s->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\""));
        label_21 = new QLabel(tab_10);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(40, 170, 111, 21));
        label_21->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        label_22 = new QLabel(tab_10);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(40, 220, 111, 21));
        label_22->setStyleSheet(QStringLiteral("font: 8pt \"MV Boli\";"));
        lineEdit_nom_modif_s = new QLineEdit(tab_10);
        lineEdit_nom_modif_s->setObjectName(QStringLiteral("lineEdit_nom_modif_s"));
        lineEdit_nom_modif_s->setGeometry(QRect(170, 170, 113, 31));
        lineEdit_nom_modif_s->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        lineEdit_max_modif_s = new QLineEdit(tab_10);
        lineEdit_max_modif_s->setObjectName(QStringLiteral("lineEdit_max_modif_s"));
        lineEdit_max_modif_s->setGeometry(QRect(170, 220, 113, 31));
        lineEdit_max_modif_s->setStyleSheet(QLatin1String("border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;"));
        label_56 = new QLabel(tab_10);
        label_56->setObjectName(QStringLiteral("label_56"));
        label_56->setGeometry(QRect(550, 320, 61, 31));
        label_56->setPixmap(QPixmap(QString::fromUtf8("../Final/images/PolishedJointCopperbutterfly-size_restricted.gif")));
        label_46 = new QLabel(tab_10);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setGeometry(QRect(-10, 230, 191, 171));
        label_46->setPixmap(QPixmap(QString::fromUtf8("../Final/images/Wallpaper-MuffinMani_Confetti_1.jpg")));
        label_33 = new QLabel(tab_10);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(-10, -10, 601, 411));
        label_44 = new QLabel(tab_10);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(130, 80, 291, 221));
        tabWidget_3->addTab(tab_10, QString());
        label_33->raise();
        label_46->raise();
        label_16->raise();
        label_17->raise();
        lineEdit_num_modif_s->raise();
        pb_modifier_s->raise();
        label_21->raise();
        label_22->raise();
        lineEdit_nom_modif_s->raise();
        lineEdit_max_modif_s->raise();
        label_56->raise();
        label_44->raise();
        label_54 = new QLabel(tab_5);
        label_54->setObjectName(QStringLiteral("label_54"));
        label_54->setGeometry(QRect(0, 360, 61, 51));
        label_54->setPixmap(QPixmap(QString::fromUtf8("../Final/images/logo (1) (1) (1).png")));
        label_80 = new QLabel(tab_5);
        label_80->setObjectName(QStringLiteral("label_80"));
        label_80->setGeometry(QRect(0, 360, 51, 51));
        label_80->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        tabWidget_2->addTab(tab_5, QString());

        retranslateUi(Dialog1);

        tabWidget_2->setCurrentIndex(0);
        tabWidget->setCurrentIndex(0);
        tabWidget_3->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Dialog1);
    } // setupUi

    void retranslateUi(QDialog *Dialog1)
    {
        Dialog1->setWindowTitle(QApplication::translate("Dialog1", "Dialog", nullptr));
#ifndef QT_NO_TOOLTIP
        tabWidget->setToolTip(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><br/></p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        lineEdit_nom->setText(QString());
        lineEdit_id->setText(QString());
        lineEdit_prix->setText(QString());
        label->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Nom</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Id</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Prix</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Num_salle</span></p></body></html>", nullptr));
        pb_ajouter->setText(QApplication::translate("Dialog1", "Ajouter", nullptr));
        label_11->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; color:#00aa00;\">Ajouter un club</span></p></body></html>", nullptr));
        label_50->setText(QString());
        label_36->setText(QString());
        label_25->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        label_34->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/balloons.png\"/></p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("Dialog1", "Ajouter", nullptr));
        label_5->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Identifiant</span></p></body></html>", nullptr));
        pb_supprimer->setText(QApplication::translate("Dialog1", "Supprimer", nullptr));
        label_12->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#00aa00;\">Supprimer un club</span></p></body></html>", nullptr));
        label_23->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#00aa00;\">Chercher un club</span></p></body></html>", nullptr));
        label_24->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Identifiant</span></p></body></html>", nullptr));
        pushButton_2->setText(QApplication::translate("Dialog1", "Trier ma liste", nullptr));
        pushButton->setText(QApplication::translate("Dialog1", "Chercher", nullptr));
        label_51->setText(QString());
        label_48->setText(QString());
        label_39->setText(QString());
        label_26->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("Dialog1", "Afficher", nullptr));
        label_15->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; color:#00aa00;\">Modifier un club</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Identifiant</span></p></body></html>", nullptr));
        lineEdit_id_modif->setText(QString());
        pb_modifier->setText(QApplication::translate("Dialog1", "Modifier", nullptr));
        label_18->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Nouveau nom</span></p></body></html>", nullptr));
        label_19->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Nouveau prix</span></p></body></html>", nullptr));
        label_20->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Nouveau num salle</span></p></body></html>", nullptr));
        lineEdit_nom_modif->setText(QString());
        lineEdit_prix_modif->setText(QString());
        label_49->setText(QString());
        label_52->setText(QString());
        label_40->setText(QString());
        label_29->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        label_37->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/balloon.gif\"/></p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_9), QApplication::translate("Dialog1", "Modifier", nullptr));
        label_53->setText(QString());
        label_41->setText(QApplication::translate("Dialog1", "+ que 50 dt", nullptr));
        label_42->setText(QApplication::translate("Dialog1", "- que 50 dt", nullptr));
        label_43->setText(QString());
        label_30->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("Dialog1", "Statistiques", nullptr));
        label_79->setText(QString());
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_4), QApplication::translate("Dialog1", "club", nullptr));
        lineEdit_num_s->setText(QString());
        lineEdit_nom_s->setText(QString());
        lineEdit_max_s->setText(QString());
        label_6->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Num</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Nom</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Max</span></p></body></html>", nullptr));
        pb_ajouter_s->setText(QApplication::translate("Dialog1", "Ajouter", nullptr));
        label_14->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; color:#00aa00;\">Ajouter une salle</span></p></body></html>", nullptr));
        label_38->setText(QString());
        label_31->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        label_35->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/balloons.png\"/></p></body></html>", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_6), QApplication::translate("Dialog1", "Ajouter", nullptr));
        label_13->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#00aa00;\">Supprimer une salle</span></p></body></html>", nullptr));
        pb_supprimer_s->setText(QApplication::translate("Dialog1", "Supprimer", nullptr));
        label_10->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Numero</span></p></body></html>", nullptr));
        label_27->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#00aa00;\">Chercher une salle</span></p></body></html>", nullptr));
        label_28->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Numero</span></p></body></html>", nullptr));
        pb_chercher_s->setText(QApplication::translate("Dialog1", "Chercher", nullptr));
        pb_trier_s->setText(QApplication::translate("Dialog1", "Trier ma liste", nullptr));
        label_55->setText(QString());
        label_45->setText(QString());
        label_32->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_7), QApplication::translate("Dialog1", "Afficher", nullptr));
        label_16->setText(QApplication::translate("Dialog1", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; color:#00aa00;\">Modifier une salle</span></p></body></html>", nullptr));
        label_17->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Numero</span></p></body></html>", nullptr));
        lineEdit_num_modif_s->setText(QString());
        pb_modifier_s->setText(QApplication::translate("Dialog1", "Modifier", nullptr));
        label_21->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Nom</span></p></body></html>", nullptr));
        label_22->setText(QApplication::translate("Dialog1", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff5500;\">Max</span></p></body></html>", nullptr));
        lineEdit_nom_modif_s->setText(QString());
        lineEdit_max_modif_s->setText(QString());
        label_56->setText(QString());
        label_46->setText(QString());
        label_33->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/background.jpg\"/></p></body></html>", nullptr));
        label_44->setText(QApplication::translate("Dialog1", "<html><head/><body><p><img src=\":/balloon.gif\"/></p></body></html>", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_10), QApplication::translate("Dialog1", "Modifier", nullptr));
        label_54->setText(QString());
        label_80->setText(QString());
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_5), QApplication::translate("Dialog1", "salle", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog1: public Ui_Dialog1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_D_CLUB_H
