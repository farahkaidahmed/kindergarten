#include "produit_ui.h"
#include "ui_produit_ui.h"
#include "menu_ui.h"
#include "ui_menu_ui.h"
#include "produit.h"
#include <QDebug>
#include <QMessageBox>
#include <QFileInfo>
#include<QFileDialog>
#include <QDate>
#include <QDateEdit>
#include "fournisseur.h"
produit_ui::produit_ui(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::produit_ui)
{fournisseur f;
    ui->setupUi(this);
    QPixmap back1("C:/Users/djoe/Desktop/picture");  //calling our background
    back1 = back1.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, back1);
    this->setPalette(palette);
     QSqlQueryModel *model =f.rechercherr();
 ui->comboBox->setModel(model);
 QList<QString> stringsList;
 QList<QString> stringsList1;
 stringsList.append("prix_achat");
 stringsList.append("quantite");
 stringsList.append("prix_unitaire");
 stringsList.append("designation");
 stringsList.append("ref");
 stringsList.append("fournisseur");
ui->comboBox_2->addItems(stringsList);
ui->comboBox_2->setCurrentIndex(4);
stringsList1.append("croissant");
stringsList1.append("decroissant");
ui->comboBox_3->addItems(stringsList1);
ui->comboBox_3->setCurrentIndex(0);
}

produit_ui::~produit_ui()
{
    delete ui;
}

void produit_ui::on_pushButton_clicked()
{
    menu_ui *I =new menu_ui () ;
    this->hide();
    I->show () ;
}

void produit_ui::on_ajout_produit_clicked()
{QString ref = (ui->ref->text());
    produit  P;
QString b(ui->prix_achat->text());
 QString p1 = ui->comboBox->currentText();
P.setref(ui->ref->text());
    P.setdesignation(ui->designation->text());
    P.setprix_achat(ui->prix_achat->text().toFloat());
    P.setquantite(ui->quantite->text().toInt());
    P.setdate_achat(ui->date_achat->text());
P.setfournisseur(p1);
    if (P.Getdesignation() =="") ui->l_controle_saisie->setText(("veuillez remplir  la designation du produit"));


   else if (b =="") ui->l_controle_saisie->setText(("veuillez remplir  le prix du produit"));



else if(P.rechercher(ref)->data(P.rechercher(ref)->index(0,0)).toString() !="" ){   QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "le produit existe deja ", "ce produit existe deja modifier ce produit ???",
                                      QMessageBox::Yes|QMessageBox::No);
        if (reply == QMessageBox::Yes) {
            P.supprimer_produit(ref);
            P.ajout_produit(P);
 QMessageBox::information(this,tr("Success"),"le produit a ete modifie ");
          qDebug() << "le produit a ete modifié";



}}


       else if (P.ajout_produit(P)==true)
        {
            QMessageBox::information(0,qApp->tr("ajout"),
                                     qApp->tr("un nouveau produit a ete ajoute")) ;
        }
        else
        {
            //if not we will show the erreur that caused the probleme (not connected to database....)
            QMessageBox::critical(this,tr("operation annulé "),tr("Operation a echoué"));
        }
}

void produit_ui::on_supprimer_2_clicked()
{
    QString  designation= ui->designation_produit->text();




    produit pr;
    qApp->tr("voulez vous vraiment supprimer ce produit?.");


    if (pr.supprimer_produit(designation))
    {
        QMessageBox::information(0, qApp->tr("supprimer"),
                                 qApp->tr("supprimer OK."), QMessageBox::Ok);

    }
    else
        QMessageBox::critical(0, qApp->tr("supprimer"),
                              qApp->tr("supprimer not  OK."), QMessageBox::Cancel);
}

void produit_ui::on_modifier_2_activated(const QModelIndex &index)
{QString liste_a;

    produit P  ;
    QString val = ui->modifier_2->model()->data(index).toString();
    if(P.rechercherproduit(val,P) == true){

        ui->ref2->setText(P.Getref());
        ui->designation2->setText(P.Getdesignation());

        ui->date_achat2->setText(P.Getdate_achat());
        ui->fournisseur_2->setText(P.Getfournisseur());
        ui->prix_achat2->setText(QString::number(P.Getprix_achat()));
        ui->quantite_2->setText(QString::number(P.Getquantite()));
        ui->montantTVA_2->setText(QString::number(P.Getmontant_TVA()));
        ui->prix_unitaire2->setText(QString::number(P.Getprix_unitaire()));
ui->ref2->setDisabled(true);
ui->montantTVA_2->setDisabled(true);
ui->prix_unitaire2->setDisabled(true);
}
}



void produit_ui::on_recherche_afficher_cursorPositionChanged(int arg1, int arg2)
{
    produit aff;
        QString designation=ui->recherche_afficher->text();

            QSqlQueryModel *model =aff.rechercher(designation);
             ui->affiche->setModel(model);
}

void produit_ui::on_recherche_afficher_2_cursorPositionChanged(int arg1, int arg2)
{
    produit aff;
        QString designation=ui->recherche_afficher_2->text();

            QSqlQueryModel *model =aff.rechercher(designation);
             ui->modifier_2->setModel(model);
}

void produit_ui::on_ajouter_tabBarClicked(int index)
{
    produit aff;

        ui->supprimer->setModel(aff.afficher()) ;
        ui->affiche->setModel(aff.afficher()) ;
        ui->modifier_2->setModel(aff.afficher()) ;
}

void produit_ui::on_pushButton_2_clicked()
{
    produit aff ;
    ui->modifier_2->setModel(aff.afficher()) ;
}

void produit_ui::on_recherche_afficher_3_textChanged(const QString &arg1)
{
    produit aff;
        QString designation=ui->recherche_afficher_3->text();

            QSqlQueryModel *model =aff.rechercher(designation);
             ui->supprimer->setModel(model);
}

void produit_ui::on_supprimer_activated(const QModelIndex &index)
{
    produit P  ;
    QString val = ui->supprimer->model()->data(index).toString();
    if(P.rechercherproduit(val,P) == true){
        ui->designation_produit->setText(P.Getdesignation());
         ui->designation_produit->setDisabled(true);
    }
    else
        QMessageBox::information(this,tr("Error"),"impossible de definir le nom du produit!");
}



void produit_ui::on_recherche_afficher_3_cursorPositionChanged(int arg1, int arg2)
{
    produit aff;
        QString designation=ui->recherche_afficher_2->text();

            QSqlQueryModel *model =aff.rechercher(designation);
             ui->modifier_2->setModel(model);
}




void produit_ui::on_modifier_clicked()
{
     produit P  ;
    P.setref(ui->ref2->text());
    P.setdesignation(ui->designation2->text());
    P.setprix_achat(ui->prix_achat2->text().toFloat());
    P.setquantite(ui->quantite_2->text().toInt());
    P.setdate_achat(ui->date_achat2->text());
    P.setfournisseur(ui->fournisseur_2->text());

     int reponse = QMessageBox::question(0, qApp->tr("Modifier"),
          qApp->tr("voulez vous vraiment Modifier ce fournisseur ?."), QMessageBox::Yes|QMessageBox::No);

     if (reponse==QMessageBox::Yes)
     {


        if (P.modifier_produit(P)==true)
        {
            QMessageBox::information(0, qApp->tr("modifier"),
                qApp->tr("modifier OK."), QMessageBox::Ok);


        }
        else
            QMessageBox::critical(0, qApp->tr("modifier"),
                qApp->tr("modifier not  OK."), QMessageBox::Cancel);
}
}

void produit_ui::on_comboBox_2_currentIndexChanged(const QString &arg1)
{   QString  y;
    produit aff;
    QString x = ui->comboBox_2->currentText();
    QString a = ui->comboBox_3->currentText();
    if (a=="croissant")     y="asc";
            else
    if (a=="decroissant")     y="desc" ;
            else
        y="asc";
    QSqlQueryModel *modele =aff.recherchertri(x,y);
     ui->affiche->setModel(modele);

}

void produit_ui::on_comboBox_3_currentIndexChanged(const QString &arg1)
{
        QString  y;
        produit aff;
        QString x = ui->comboBox_2->currentText();
        QString a = ui->comboBox_3->currentText();
        if (a=="croissant")     y="asc";
        else
        if (a=="decroissant")     y="desc";
        else
        y="asc";
        QSqlQueryModel *modele =aff.recherchertri(x,y);
         ui->affiche->setModel(modele);
}









