#include "fete.h"
#include <QDebug>
#include <QString>
#include <QtSql/QSqlDatabase>
#include "connexion.h"
#include <QSqlQueryModel>
//#include <SqlQuery>
#include <QtSql/QSqlQuery>

Fete::Fete() //constructeur non parametre
{
    idF=0;
    nomF="";
    descF="";
    prixF=0;
}


Fete::Fete(int id,QString nom,QString desc,int prix) //constructeur parametre
{
  this->idF=id;
  this->nomF=nom;
  this->descF=desc;
  this->prixF=prix;
}

//Getters
int Fete::getidF(){return  idF;}
QString Fete::getnomF(){return nomF;}
QString Fete::getdescF(){return descF;}
int Fete::getprixF(){return  prixF;}


//Fonction ajout evenement
bool Fete::ajouter()
{
QSqlQuery query;
QString res= QString::number(idF);
query.prepare("INSERT INTO fete (IDF, NOMF, DESCF, PRIXF) "
                    "VALUES (:idF, :nomF, :descF, :prixF)");
query.bindValue(":idF", res);
query.bindValue(":nomF", nomF);
query.bindValue(":descF", descF);
query.bindValue(":prixF", prixF);


return    query.exec();
}

//Fonction afficher liste de fetes
QSqlQueryModel * Fete::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from fete");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID fete"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom fete "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Description fete")); //QObject::tr("") : nom de la colonne
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Prix estimé "));


    return model;
}

//fonction evenemet A REVOIR
bool Fete::modifier(int idF, QString nomF, QString descF, int prixF)
{
    QSqlQuery query;

        query.prepare("UPDATE fete SET nomF=:nomF, descF=:descF, prixF=:prixF  WHERE idF=:idF;");

        query.bindValue(":idF", idF);
        query.bindValue(":nomF", nomF);
        query.bindValue(":descF", descF);
        query.bindValue(":prixF", prixF);


        return    query.exec();
}


//Fonction supprimer fete
bool Fete::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from fete where IDF = :idF ");
query.bindValue(":idF", res);
return    query.exec();
}



//fonction recherche selon id
QSqlQueryModel * Fete::rechercher(int id){

    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * from fete where IDF =:id");
    query.bindValue(":id",id);
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("id F"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom F"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Description F"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Prix F"));



    return model;
}

//tri par prix
QSqlQueryModel * Fete::afficher_tri_prix()
{
    QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from fete order by prixF ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id F"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom F"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Description F"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Prix F"));

    return model;
}

/*//Compter les fetes avec prix +200 et retourner leur pourcentage
int Fete::stat_plus()
{   int plus =0;
    int total =0;
    QSqlQuery query0;
     query0.exec("SELECT * FROM fete ");
     while(query0.next())
                 {
                     total = total + 1;

                 }
    QSqlQuery query;
     query.exec("SELECT * FROM fete WHERE prixF >= 200");
     while(query.next())
                 {
                     plus = plus + 1;

                 }
     return ((plus*100)/total);

}*/

//Compter les fetes avec prix -200 et retourner leur pourcentage
int Fete::stat_moins()
{   int moins =0;
    int total =0;
    QSqlQuery query0;
     query0.exec("SELECT * FROM fete ");
     while(query0.next())
                 {
                     total = total + 1;

                 }
    QSqlQuery query;
     query.exec("SELECT * FROM fete WHERE prixF < 200");
     while(query.next())
                 {
                     moins = moins + 1;

                 }
     return ((moins*100)/total);

}
