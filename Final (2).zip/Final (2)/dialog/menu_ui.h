#ifndef MENU_UI_H
#define MENU_UI_H

#include <QDialog>

namespace Ui {
class menu_ui;
}

class menu_ui : public QDialog
{
    Q_OBJECT

public:
    explicit menu_ui(QWidget *parent = 0);
    ~menu_ui();

private slots:
    void on_commandLinkButton_clicked();



    void on_Commande_link_clicked();




    void on_Commande_link_2_clicked();

private:
    Ui::menu_ui *ui;
};

#endif // MENU_UI_H
