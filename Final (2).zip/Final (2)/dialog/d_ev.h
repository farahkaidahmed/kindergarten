#ifndef DIALOG_H
#define DIALOG_H
#include "evenement.h"
#include "fete.h"
#include <QDialog>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();


private slots:
    void on_pb_ajouter_clicked(); //ajout d'un event

    void on_pb_supprimer_clicked(); //suppression d'un event

    void on_pb_ajouter_2_clicked();//ajout d'une fete

    void on_pb_supprimer_2_clicked(); //suppression d'une fete

    void on_pb_recherche_ev_clicked(); // recherche evenement a modifier

    void on_pb_rech_ev_clicked(); // recherche evenement parmis liste

    void on_pb_rech_fete_clicked(); //recherche fete pour liste

    void on_pb_recherche_fete_clicked(); // rech fete pour modif

    void on_pb_modifier_ev_clicked(); // modifier evenement

    void on_pb_modifier_fete_clicked();//modifier fete

    void on_tri_date_clicked();//trier event par date

    void on_tri_prix_clicked();//trier fete par prix


private:
    Ui::Dialog *ui;
    Evenement tmpevenement;
    Fete tmpfete;
};

#endif // DIALOG_H
