#include "d_ev.h"
#include "ui_d_ev.h"
#include "evenement.h"
#include "fete.h"
#include <QDialog>
#include <QMessageBox>
#include <QtSql/QSqlQueryModel>
//#include <QtSql/QSqlQuery>



Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    ui->tabevent->setModel(tmpevenement.afficher()); // affichage de la liste des evenements
    ui->tabfete->setModel(tmpfete.afficher()); //affichage de la liste des fetes
    ui->tabevent_modif->setModel(tmpevenement.afficher()); //affichage de la liste des fetes
    ui->tabfete_modif->setModel(tmpfete.afficher()); //affichage de la liste des fetes

    //QSqlQuery query;
    //query.prepare("select idf from fete");
    //QString s=query.value(0).toString();
    //if(query.exec())
      //  {
        //    while(query.next())
      //      {
                //QString s = query.value(0).toString();//Récupère le résultat de la requête
                //ui->comboBox1->addItem(s);
                //ui->comboBox2->addItem(s);
                QSqlQueryModel *model = new QSqlQueryModel();
                   model->setQuery("select idf from fete");
               ui->comboBox1->setModel(model);//Combobox ajout event
               ui->comboBox2->setModel(model);//Combobox modif event
               ui->comboBoxsupp2->setModel(model);//combobox supprimer fete

               QSqlQueryModel *model1 = new QSqlQueryModel();
                  model1->setQuery("select idEv from evenement");
              ui->comboBoxsupp1->setModel(model1);//Combobox supp event


               //id2=ui->comboBox1->currentText();
            //}
       // }
    //else {
      //  ui->comboBox1->addItem("Id fete");


    //}
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pb_ajouter_clicked()
{
    int idEv = ui->lineEdit_id->text().toInt();
    QString nomEv= ui->lineEdit_nom->text();
    QString dateEv= ui->dateEv->date().toString();
    int idFete = ui->comboBox1->currentText().toInt();
    //Evenement e(idEv,nomEv,dateEv,idFete);

    QString id = ui->lineEdit_id->text();
    QString verifnom= ui->lineEdit_nom->text();
    QString verifdate= ui->dateEv->date().toString();
    QString verifidfet= ui->comboBox1->currentText();

    QString numeros = "0123456789";
    bool verifid =false;

    //verification id numbers only
              for (int i = 0; i < id.length(); i++)
                   { verifid= false;
                         for (int j = 0; j < numeros.length(); j++)
                         {
                            if (id[i] == numeros [j])
                            {verifid = true;}
                         }
                    if (verifid == false)
                    { QMessageBox::information(nullptr, QObject::tr(" ID"),
                                     QObject::tr("ID INCORRECT.\n"
                                                 "Verifier l'id."), QMessageBox::Cancel);
                        ;}}

    //verification le reste des champs non vides
              bool test1 = verifnom.length() == 0 ;
              bool test2 = verifdate.length() == 0 ;
              bool test3 = verifidfet.length() == 0 ;


                     if (test1)
                     {QMessageBox::information(nullptr, QObject::tr("NOM"),
                               QObject::tr("CHAMP VIDE.\n"
                               "Verifier nom."), QMessageBox::Cancel);}

                     if (test2)
                     {QMessageBox::information(nullptr, QObject::tr("DATE"),
                               QObject::tr("CHAMP VIDE.\n"
                               "Verifier date."), QMessageBox::Cancel);}

                     if (test3)
                     {QMessageBox::information(nullptr, QObject::tr("FETE ID"),
                               QObject::tr("CHAMP VIDE.\n"
                               "verifier id fete ."), QMessageBox::Cancel);}






    if ((verifid == true) && (test1==false) && (test2==false) && (test3==false))
        {    Evenement e(idEv,nomEv,dateEv,idFete);
              bool test=e.ajouter();
              if (test)

           {ui->tabevent->setModel(tmpevenement.afficher());//refresh
           ui->tabevent_modif->setModel(tmpevenement.afficher());//refresh
           QMessageBox::information(nullptr, QObject::tr("Ajouter un évenement"),
                  QObject::tr("Evenement ajouté avec succes.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
           QSqlQueryModel *model = new QSqlQueryModel();
              model->setQuery("select idf from fete");
          ui->comboBox1->setModel(model);//Combobox ajout event
          ui->comboBox2->setModel(model);//Combobox modif event
          ui->comboBoxsupp2->setModel(model);//combobox supprimer fete


           //refresh combobox supp event
           QSqlQueryModel *model1 = new QSqlQueryModel();
              model1->setQuery("select idEv from evenement");
              ui->comboBoxsupp1->setModel(model1);//Combobox supp event

        }
  else
           QMessageBox::critical(nullptr, QObject::tr("Ajouter un évenement"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}}
//Action click bouton supprimer evenement
void Dialog::on_pb_supprimer_clicked()
{                    //id2=ui->comboBox1->currentText();

   int id = ui->comboBoxsupp1->currentText().toInt();
   bool test=tmpevenement.supprimer(id);
   if(test)
       {ui->tabevent->setModel(tmpevenement.afficher());//refresh
        ui->tabevent_modif->setModel(tmpevenement.afficher());//refresh
        QSqlQueryModel *model = new QSqlQueryModel();
           model->setQuery("select idf from fete");
           ui->comboBox2->setModel(model);//Combobox modif event
           ui->comboBoxsupp2->setModel(model);//combobox supprimer fete
        QMessageBox::information(nullptr, QObject::tr("Supprimer un evenement"),
                QObject::tr("Evenement supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

       }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un evenement"),
                QObject::tr("Erreur de suppression!.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}

//Action click bouton ajouter fete
void Dialog::on_pb_ajouter_2_clicked()
{
    int idF = ui->lineEdit_idf->text().toInt();
    QString nomF= ui->lineEdit_nomf->text();
    QString descF= ui->lineEdit_desc->text();
    int prixF = ui->lineEdit_prix->text().toInt();

    QString id = ui->lineEdit_idf->text();
    QString verifnomF= ui->lineEdit_nomf->text();
    QString verifdescF= ui->lineEdit_desc->text();
    QString verifprixF= ui->lineEdit_prix->text();


    QString numeros = "0123456789";
    bool verifidF =false;
    bool verifprixF2 = false;

    //verification id numbers only
              for (int i = 0; i < id.length(); i++)
                   { verifidF= false;
                         for (int j = 0; j < numeros.length(); j++)
                         {
                            if (id[i] == numeros [j])
                            {verifidF = true;}
                         }
                    if (verifidF == false)
                    { QMessageBox::information(nullptr, QObject::tr(" ID"),
                                     QObject::tr("ID INCORRECT.\n"
                                                 "Verifier l'id."), QMessageBox::Cancel);
                        ;}}


     //verification prix numbers only
              for (int i = 0; i < verifprixF.length(); i++)
                   { verifprixF2= false;
                         for (int j = 0; j < numeros.length(); j++)
                         {
                            if (verifprixF[i] == numeros [j])
                            {verifprixF2 = true;}
                         }
                    if (verifprixF2 == false)
                    { QMessageBox::information(nullptr, QObject::tr(" PRIX"),
                                     QObject::tr("PRIX INCORRECT.\n"
                                                 "Verifier le prix."), QMessageBox::Cancel);
                        ;}}

    bool testF1 = verifnomF.length() == 0 ;
    bool testF2 = verifdescF.length() == 0 ;
    bool testF3 = verifprixF.length() == 0 ;



           if (testF1)
           {QMessageBox::information(nullptr, QObject::tr("NOM"),
                     QObject::tr("CHAMP VIDE.\n"
                     "Verifier nom."), QMessageBox::Cancel);}

           if (testF2)
           {QMessageBox::information(nullptr, QObject::tr("DESCRIPTION"),
                     QObject::tr("CHAMP VIDE.\n"
                     "Verifier description."), QMessageBox::Cancel);}

           if (testF3)
           {QMessageBox::information(nullptr, QObject::tr("PRIX"),
                     QObject::tr("CHAMP VIDE.\n"
                     "verifier prix."), QMessageBox::Cancel);}

           if ((verifidF == true ) && (testF1 == false) && ( testF2 == false) && (testF3 == false) && ( verifprixF2 == true))
           {
    Fete f(idF,nomF,descF,prixF);
    bool test=f.ajouter();
    if(test)
        {

           ui->tabfete->setModel(tmpfete.afficher());//refresh
           QMessageBox::information(nullptr, QObject::tr("Ajouter une fete"),
                  QObject::tr("Fete ajoutée avec succes.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

           //mise a jour combobox suppression fete
           QSqlQueryModel *model = new QSqlQueryModel();
              model->setQuery("select idf from fete");
              ui->comboBoxsupp2->setModel(model);//combobox supprimer fete

        }
  else
           QMessageBox::critical(nullptr, QObject::tr("Ajouter une fete"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}}

//Action click bouton supprimer fete
void Dialog::on_pb_supprimer_2_clicked()
{
   int id = ui->comboBoxsupp2->currentText().toInt();
   bool test=tmpfete.supprimer(id);
   if(test)
       {ui->tabfete->setModel(tmpfete.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une fete"),
                QObject::tr("Fete supprimée.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
        QSqlQueryModel *model = new QSqlQueryModel();
        model->setQuery("select idf from fete");
        ui->comboBoxsupp2->setModel(model);//combobox supprimer fete

       }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer une fete"),
                QObject::tr("Erreur de suppression!.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}

//Action click bouton recherche evenement pour modification
void Dialog::on_pb_recherche_ev_clicked()
{
    ui->tabevent_modif->setModel(tmpevenement.rechercher(ui->recherche_ev->text().toInt()));
    if(ui->recherche_ev->text().isEmpty())
        ui->tabevent_modif->setModel(tmpevenement.afficher());
}

//Action click bouton recherche evenement dans la liste selon id
void Dialog::on_pb_rech_ev_clicked()
{
    ui->tabevent->setModel(tmpevenement.rechercher(ui->rech_ev->text().toInt()));
    if(ui->rech_ev->text().isEmpty())
        ui->tabevent->setModel(tmpevenement.afficher());

}

//Action click bouton recherche fete dans la liste selon id
void Dialog::on_pb_rech_fete_clicked()
{
    ui->tabfete->setModel(tmpfete.rechercher(ui->rech_fete->text().toInt()));
    if(ui->rech_fete->text().isEmpty())
        ui->tabfete->setModel(tmpfete.afficher());

}

//Action click bouton recherche fete pour modification
void Dialog::on_pb_recherche_fete_clicked()
{
    ui->tabfete_modif->setModel(tmpfete.rechercher(ui->recherche_fete->text().toInt()));
    if(ui->recherche_fete->text().isEmpty())
        ui->tabfete_modif->setModel(tmpfete.afficher());

}
//Action bouton modifier evenement
void Dialog::on_pb_modifier_ev_clicked()
{


        QString nom_Ev = ui->nom_ev_modif->text();
        int id_Ev = ui->recherche_ev->text().toInt();
        QString date_Ev = ui->date_ev_modif->date().toString();
        int id_Fete = ui->comboBox2->currentText().toInt();


    bool test=tmpevenement.modifier(id_Ev,nom_Ev,date_Ev,id_Fete);


    if (test)
      {
        ui->tabevent->setModel(tmpevenement.afficher());//refresh
        ui->tabevent_modif->setModel(tmpevenement.afficher());//refresh

    QMessageBox::information(nullptr, QObject::tr("Modifier un événement"),
                    QObject::tr("Modification faite avec succés.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Modifier un événement"),
                    QObject::tr("Echec de la modification ! !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

//Action bouton modifier fete
void Dialog::on_pb_modifier_fete_clicked()
{


        QString nomF = ui->lineEdit_nom_fete_modif->text();
        int idF = ui->recherche_fete->text().toInt();
        QString descF = ui->lineEdit_desc_fete_modif->text();
        int prixF = ui->lineEdit_prix_fete_modif->text().toInt();


    bool test=tmpfete.modifier(idF,nomF,descF,prixF);


    if (test)
      {  //MISE A JOUR:
        //refresh affichage liste
        ui->tabfete->setModel(tmpfete.afficher());
        //refresh affichage liste modification
        ui->tabfete_modif->setModel(tmpfete.afficher());
        //refresh comboBox
        QSqlQueryModel *model = new QSqlQueryModel();
           model->setQuery("select idf from fete");
       ui->comboBox1->setModel(model);


    QMessageBox::information(nullptr, QObject::tr("Modifier une fete"),
                    QObject::tr("Modification faite avec succés.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Modifier une fete"),
                    QObject::tr("Echec de la modification ! !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

//action bouton tri date evenement
void Dialog::on_tri_date_clicked()
{
    ui->tabevent->setModel(tmpevenement.afficher_tri_date());

}

//action bouton tri fete prix
void Dialog::on_tri_prix_clicked()
{
    ui->tabfete->setModel(tmpfete.afficher_tri_prix());

}


