#ifndef FETE_H
#define FETE_H
#include <QString>
#include <QtSql/QSqlQueryModel>

class Fete
{public:

    Fete(); //constructeur non parametre
    Fete(int,QString,QString,int); //constructeur parametre

    //getters
    int getidF();
    QString getnomF();
    QString getdescF();
    int getprixF();

    bool ajouter();//Ajouter une fete
    QSqlQueryModel * afficher(); //Afficher liste de fetes
    bool modifier(int,QString,QString,int);//modifier fete selon id

    bool supprimer(int);//supprimer une fete selon id
    QSqlQueryModel *rechercher(int); //recherche selon id
    QSqlQueryModel * afficher_tri_prix();//tri par prix

    int stat_moins();
    int stat_plus();



private:
    int idF;
    QString nomF;
    QString descF;
    int prixF;
};

#endif // FETE_H
