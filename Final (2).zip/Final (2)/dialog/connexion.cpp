#include "connexion.h"
#include <QtSql/QSqlQueryModel>

Connexion::Connexion()
{}

bool Connexion::ouvrirConnexion()
{
bool test=false;
    db=QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("Test");
db.setUserName("esprit");//inserer nom de l'utilisateur
db.setPassword("esprit");//inserer mot de passe de cet utilisateur


if (db.open()) test = true;


return test;

}
void Connexion::fermerConnexion()
{db.close();}
