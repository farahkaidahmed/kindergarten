#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "connexion.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_connect_clicked()
{
    Connexion c;
    bool test= c.ouvrirConnexion();
    Dialog w;
               if(test)
 {
         w.show();


     }
           else
                QMessageBox::information(nullptr, QObject::tr("Echec de connexion de la Base."),
                            QObject::tr("Echec de la connexion.\n""Cliquez sur Cancel pour Quitter."), QMessageBox::Cancel);



}
