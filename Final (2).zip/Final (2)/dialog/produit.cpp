#include "produit.h"

#include <QApplication>
#include "QSqlQuery"
#include "QMessageBox"
#include "QSqlQuery"
#include <QDebug>
#include <QString>
produit::produit()
{}



bool produit::ajout_produit(produit &P)
{
    QSqlQuery query;
    P.montant_TVA=(((P.Getprix_achat())*18)/100);
    P.prix_unitaire=((P.Getprix_achat())/((P.Getquantite())));

    query.prepare("INSERT INTO produit (ref,designation,prix_achat,date_achat,fournisseur,quantite,montant_TVA,prix_unitaire) "
                  "VALUES (:ref,:designation,:prix_achat,:date_achat,:fournisseur,:quantite,:montant_TVA,:prix_unitaire)");
query.bindValue(0,P.Getref());
    query.bindValue(1,P.Getdesignation());
    query.bindValue(2,P.Getprix_achat());
    query.bindValue(3,P.Getdate_achat());
    query.bindValue(4,P.Getfournisseur());
     query.bindValue(5,P.Getquantite());
    query.bindValue(6,P.montant_TVA);
    query.bindValue(7,P.prix_unitaire);
    if(query.exec()){
       return true;
    }
   else return false;

}
QSqlQueryModel *produit::afficher()
{
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select * from produit");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ref"));

    model->setHeaderData(1, Qt::Horizontal, QObject::tr("designation"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prix_achat"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("date_achat"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("fournisseur"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("quantite"));

    model->setHeaderData(6, Qt::Horizontal, QObject::tr("montant_TVA"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("prix_unitaire"));

    return model;
}
bool produit::supprimer_produit(QString designation)
{


    QSqlQuery query;
        QString ID1=designation;
        query.prepare("delete from produit where designation=?");
        query.addBindValue(designation);;

    return (query.exec());
}
bool produit::modifier_produit(produit &P)
 {
    QSqlQuery query;
    P.montant_TVA=(((P.Getprix_achat())*18)/100);
    P.prix_unitaire=((P.Getprix_achat())/((P.Getquantite())));





    query.prepare("update produit set ref = ? ,designation = ?,"
                  "prix_achat = ?, date_achat = ?, fournisseur = ?,quantite = ?, montant_TVA = ?,prix_unitaire = ?"
                  " where ref = ?"
                  );
    query.addBindValue(P.Getref());
    query.addBindValue(P.Getdesignation());
    query.addBindValue(P.Getprix_achat());
    query.addBindValue(P.Getdate_achat());
    query.addBindValue(P.Getfournisseur());


    query.addBindValue(P.Getquantite());
    query.addBindValue(P.montant_TVA);
    query.addBindValue(P.prix_unitaire);
    query.addBindValue(P.Getref());
    if(query.exec()){
        return true;
    }
    else
        return false;
 }
bool produit::rechercherproduit(QString val,produit &P){
    QSqlQuery query;

    query.prepare("select * from produit where ref = '"+val+"' or designation='"+val+"'or prix_achat='"+val+"'or date_achat='"+val+"' or fournisseur='"+val+"'or quantite='"+val+"' or  montant_TVA='"+val+"' or prix_unitaire='"+val+"' ");
    if(query.exec()){
        while(query.next()){
             P.setref(query.value(0).toString());
            P.setdesignation(query.value(1).toString());
            P.setprix_achat(query.value(2).toFloat());
            P.setdate_achat(query.value(3).toString());
             P.setfournisseur(query.value(4).toString());
            P.setquantite(query.value(5).toFloat());
            P.setmontant_TVA(query.value(6).toFloat());
            P.setprix_unitaire(query.value(7).toInt());
        }
        return true;
    }
    else
        return false;
}
QSqlQueryModel * produit::rechercher(QString val)
{

    QSqlQuery query;
    QSqlQueryModel* model = new QSqlQueryModel();
    query.prepare("select * from produit where designation like '%"+val+"%' or ref like '%"+val+"%' ");
    if(query.exec()){
        model->setQuery(query);
    }
return model;
}
QSqlQueryModel * produit::recherche()
{

    QSqlQuery query;
    QSqlQueryModel* model = new QSqlQueryModel();
    query.prepare("select designation from produit ");
    if(query.exec()){
        model->setQuery(query);
    }
return model;
}
QSqlQueryModel * produit::recherchertri(QString val1,QString val2)
{

    QSqlQuery query;
    QSqlQueryModel* model = new QSqlQueryModel();

    query.prepare("select * from produit order by  "+val1+" "+val2+" ");
    if(query.exec()){
        model->setQuery(query);
    }
return model;
}
