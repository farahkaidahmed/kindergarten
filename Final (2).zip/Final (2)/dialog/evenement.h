#ifndef EVENEMENT_H
#define EVENEMENT_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class Evenement
{public:

    Evenement();//constructeur non parametre
    Evenement(int,QString,QString,int); //constructeur parametre

    //getters
    int getidEv();
    QString getnomEv();
    QString getdateEv();
    int getidFete();



    bool ajouter(); //ajouter un event
    QSqlQueryModel * afficher(); //afficher un event
    bool supprimer(int); //supprimer un event selon id
    bool modifier(int,QString,QString,int);//modifier event selon id
    QSqlQueryModel *rechercher(int); //recherche selon id
    QSqlQueryModel * afficher_tri_date();//tri par date



private:
    int idEv;
    QString nomEv;
    QString dateEv;
    int idFete;
};

#endif // EVENEMENT_H
