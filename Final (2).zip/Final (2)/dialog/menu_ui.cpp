#include "menu_ui.h"
#include "ui_menu_ui.h"
#include "fournisseurs.h"
#include "ui_fournisseurs.h"
#include "gestion_menu_ui.h"

#include "produit_ui.h"
#include "ui_produit_ui.h"

//#include "mail.h"
//#include "ui_mail.h"


menu_ui::menu_ui(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::menu_ui)
{
    ui->setupUi(this);
    QPixmap back1("C:/Users/djoe/Desktop/picture");  //calling our background
    back1 = back1.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, back1);
    this->setPalette(palette);

}

menu_ui::~menu_ui()
{
    delete ui;
}

void menu_ui::on_commandLinkButton_clicked()
{
    fournisseurs *I =new fournisseurs () ;
    this->hide();
    I->show () ;
}



void menu_ui::on_Commande_link_clicked()
{
    produit_ui *I =new produit_ui () ;
    this->hide();
    I->show () ;
}





//void menu_ui::on_Commande_link_windowIconChanged(const QIcon &icon)
//{

//}

void menu_ui::on_Commande_link_2_clicked()
{
    gestion_menu_ui *I =new gestion_menu_ui () ;
    this->hide();
    I->show () ;
}
