#include "d_ev.h"
#include "d_club.h"
#include "acc.h"
#include <QApplication>
#include <QMessageBox>
#include <QDebug>
#include "connexion.h"
#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   Connexion c;
   bool test= c.ouvrirConnexion();
   //Dialog d_ev;

   MainWindow w;

              if(test)
{
        w.show();
         //d_ev.show();

    }
          else
               QMessageBox::information(nullptr, QObject::tr("Echec de connexion de la Base."),
                           QObject::tr("Echec de la connexion.\n""Cliquez sur Cancel pour Quitter."), QMessageBox::Cancel);



    return a.exec();
}
