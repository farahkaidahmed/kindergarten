#include "d_club.h"
#include "ui_d_ev.h"
#include "ui_d_club.h"

#include "club.h"
#include "salle.h"
#include <QMessageBox>

#include <QDialog>
#include <QtSql/QSqlQueryModel>

Dialog1::Dialog1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog1)
{
ui->setupUi(this);
QSqlQuery query;
query.prepare("select NUM from salle");

//QString s=query.value(0).toString();
if(query.exec())
    {
        while(query.next())
        {
            ui->tabclub->setModel(tmpclub.afficher());
            ui->tabsalle->setModel(tmpsalle.afficher());
            QString s = query.value(0).toString();//Récupère le résultat de la requête
            ui->comboBox->addItem(s);
            ui->comboBox_2->addItem(s);
        }
    }

QSqlQuery query1;
query1.prepare("select ID from club");
if(query1.exec())
    {
        while(query1.next())
        {
            QString ss = query1.value(0).toString();
            ui->comboBox_3->addItem(ss);
            ui->comboBox_4->addItem(ss);

        }
    }

ui->tabclub->setModel(tmpclub.afficher());
ui->tabsalle->setModel(tmpsalle.afficher());
//ui->comboBox->addItem("1112");
//ui->tabclub->setModel(tmpclub.afficher());
ui->comboBox_5->addItem("ID croissant");
ui->comboBox_5->addItem("ID decroissant");
ui->comboBox_5->addItem("PRIX croissant");
ui->comboBox_5->addItem("PRIX decroissant");

ui->comboBox_8->addItem("NUM croissant");
ui->comboBox_8->addItem("NUM decroissant");
ui->comboBox_8->addItem("MAX croissant");
ui->comboBox_8->addItem("MAX decroissant");


QSqlQuery query2;
query2.prepare("select NUM from salle");
if(query2.exec())
    {
        while(query2.next())
        {
            QString sss = query2.value(0).toString();
            ui->comboBox_6->addItem(sss);
            ui->comboBox_7->addItem(sss);
        }
    }



}




Dialog1::~Dialog1()
{
    delete ui;
}


void Dialog1::on_pb_ajouter_clicked()
{
    ui->tabclub->setModel(tmpclub.afficher());
    QString nom= ui->lineEdit_nom->text();
    int id = ui->lineEdit_id->text().toInt();
    int prix = ui->lineEdit_prix->text().toInt();
    int num_salle = ui->comboBox->currentText().toInt();
  club e(nom,id,prix,num_salle);
  //bool test=e.ajouter();
  if(nom.isEmpty() || id==0)
  {
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un club"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);}
  else
  {
      bool test=e.ajouter();
      if(test)
    {

          ui->tabclub->setModel(tmpclub.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("Ajouter un club"),
                      QObject::tr("club ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
    ui->tabclub->setModel(tmpclub.afficher());

    }
      else
      {
          QMessageBox::critical(nullptr, QObject::tr("Ajouter un club"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);}


  }
  /***pour actualiser les combobox***/QSqlQueryModel *model = new QSqlQueryModel();
  model->setQuery("select id from club");
  ui->comboBox_3->setModel(model);
  ui->comboBox_4->setModel(model);/***pour actualiser les combobox***/
          }





void Dialog1::on_pb_supprimer_clicked()
{
    ui->tabclub->setModel(tmpclub.afficher());
    //int id = ui->lineEdit_id_2->text().toInt();
    int id = ui->comboBox_3->currentText().toInt();
    bool test=tmpclub.supprimer(id);
    if(test)
    {ui->tabclub->setModel(tmpclub.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un club"),
                    QObject::tr("club supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un club"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);}
    /***pour actualiser les combobox***/QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select id from club");
    ui->comboBox_3->setModel(model);
    ui->comboBox_4->setModel(model);/***pour actualiser les combobox***/

}



void Dialog1::on_pb_ajouter_s_clicked()
{
    ui->tabsalle->setModel(tmpsalle.afficher());
    QString nom= ui->lineEdit_nom_s->text();
    int num = ui->lineEdit_num_s->text().toInt();
    int max = ui->lineEdit_max_s->text().toInt();
  salle s(nom,num,max);
  bool test=s.ajouter();
  if(test)
{

      ui->tabsalle->setModel(tmpsalle.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter une salle"),
                  QObject::tr("salle ajoutée.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
  {
      QMessageBox::critical(nullptr, QObject::tr("Ajouter une salle"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);}
  /***pour actualiser les combobox***/QSqlQueryModel *model = new QSqlQueryModel();
  model->setQuery("select NUM from salle");
  ui->comboBox_6->setModel(model);
  ui->comboBox_7->setModel(model);
  ui->comboBox_2->setModel(model);
  ui->comboBox->setModel(model);/***pour actualiser les combobox***/

}

void Dialog1::on_pb_supprimer_s_clicked()
{
    ui->tabsalle->setModel(tmpsalle.afficher());
    int id = ui->comboBox_6->currentText().toInt();
    //int id = ui->lineEdit_num_2->text().toInt();
    bool test=tmpsalle.supprimer(id);
    if(test)
    {ui->tabsalle->setModel(tmpsalle.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une salle"),
                    QObject::tr("salle supprimée.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Supprimer une salle"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);}

    /***pour actualiser les combobox***/QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select NUM from salle");
    ui->comboBox_6->setModel(model);
    ui->comboBox_7->setModel(model);
    ui->comboBox_2->setModel(model);
    ui->comboBox->setModel(model);/***pour actualiser les combobox***/

}





void Dialog1::on_pb_modifier_clicked()
{
    ui->tabclub->setModel(tmpclub.afficher());
QString nom_nv= ui->lineEdit_nom_modif->text();
int id = ui->lineEdit_id_modif->text().toInt();
int prix_nv = ui->lineEdit_prix_modif->text().toInt();
int num_salle_nv = ui->comboBox_2->currentText().toInt();

club e1(nom_nv,id,prix_nv,num_salle_nv);
bool test=e1.modifier(id);
if(test)
{ui->tabclub->setModel(tmpclub.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("Modifier un club"),
                QObject::tr("club modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
{
    QMessageBox::critical(nullptr, QObject::tr("Modifier un club"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);}
/***pour actualiser les combobox***/QSqlQueryModel *model = new QSqlQueryModel();
model->setQuery("select id from club");
ui->comboBox_3->setModel(model);
ui->comboBox_4->setModel(model);/***pour actualiser les combobox***/

}

void Dialog1::on_pb_modifier_s_clicked()
{
    ui->tabsalle->setModel(tmpsalle.afficher());
    int numm = ui->lineEdit_num_modif_s->text().toInt();
    QString nom_nv= ui->lineEdit_nom_modif_s->text();
    int max_nv = ui->lineEdit_max_modif_s->text().toInt();

    salle s1(nom_nv,numm,max_nv);
    bool test=s1.modifier(numm);
    if(test)
    {ui->tabsalle->setModel(tmpsalle.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Modifier une salle"),
                    QObject::tr("salle modifiée.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Modifier une salle"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);}
    /***pour actualiser les combobox***/QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery("select NUM from salle");
    ui->comboBox_6->setModel(model);/***pour actualiser les combobox***/
}


void Dialog1::on_pushButton_2_clicked() //bouton Trier ma liste
{
    QString combo = ui->comboBox_5->currentText() ;
    if(combo == "ID croissant" )
    {
        QSqlQueryModel * model= new QSqlQueryModel();
        model->setQuery("select * from club order by ID ASC");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("Nom "));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prix "));
        model->setHeaderData(3, Qt::Horizontal, QObject::tr("Num_salle"));
        ui->tabclub->setModel(model);
            ui->tabclub->show();
    }
    else
        if(combo == "ID decroissant")
        {
            QSqlQueryModel * model= new QSqlQueryModel();
            model->setQuery("select * from club order by ID DESC");
            model->setHeaderData(0, Qt::Horizontal, QObject::tr("Nom "));
            model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
            model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prix "));
            model->setHeaderData(3, Qt::Horizontal, QObject::tr("Num_salle"));
            ui->tabclub->setModel(model);
                ui->tabclub->show();
        }
    else
            if(combo == "PRIX croissant")
            {
                QSqlQueryModel * model= new QSqlQueryModel();
                model->setQuery("select * from club order by PRIX ASC");
                model->setHeaderData(0, Qt::Horizontal, QObject::tr("Nom "));
                model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
                model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prix "));
                model->setHeaderData(3, Qt::Horizontal, QObject::tr("Num_salle"));
                ui->tabclub->setModel(model);
                    ui->tabclub->show();
            }
    else
                if(combo == "PRIX decroissant")
                {
                    QSqlQueryModel * model= new QSqlQueryModel();
                    model->setQuery("select * from club order by PRIX DESC");
                    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Nom "));
                    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
                    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prix "));
                    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Num_salle"));
                    ui->tabclub->setModel(model);
                        ui->tabclub->show();
                }

}

void Dialog1::on_pushButton_clicked() //bouton Chercher
{
    int id = ui->comboBox_4->currentText().toInt();
    QSqlQuery query;
    QString res = QString::number(id);
    query.prepare("select * from club WHERE ID = :id");
    query.bindValue(":id", res);
    query.exec();





    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Nom "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prix "));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Num_salle"));
    ui->tabclub_2->setModel(model);
        ui->tabclub_2->show();



    /*ui->tabclub_2->setModel(tmpclub.rechercher(id));
    ui->tabclub_2->show();


    bool test=tmpclub.rechercher(id);
    if(test)
    {//ui->tabclub->setModel(tmpclub.rechercher(id));//refresh
        QMessageBox::information(nullptr, QObject::tr("cc"),
                    QObject::tr("cc.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("dd"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);}*/

}

void Dialog1::on_pb_chercher_s_clicked()
{
    int num = ui->comboBox_7->currentText().toInt();
    QSqlQuery query;
    QString res = QString::number(num);
    query.prepare("select * from salle WHERE NUM = :num");
    query.bindValue(":num", res);
    query.exec();


    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Max "));
    ui->tabsalle_2->setModel(model);
        ui->tabsalle_2->show();
}

void Dialog1::on_pb_trier_s_clicked()
{
    QString combo = ui->comboBox_8->currentText() ;
    if(combo == "NUM croissant" )
    {
        QSqlQueryModel * model= new QSqlQueryModel();
        model->setQuery("select * from salle order by NUM ASC");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num "));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("Max "));
        ui->tabsalle->setModel(model);
            ui->tabsalle->show();
    }
    else
        if(combo == "NUM decroissant")
        {
            QSqlQueryModel * model= new QSqlQueryModel();
            model->setQuery("select * from salle order by NUM DESC");
            model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num "));
            model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
            model->setHeaderData(2, Qt::Horizontal, QObject::tr("Max "));
            ui->tabsalle->setModel(model);
                ui->tabsalle->show();
        }
    else
            if(combo == "MAX croissant")
            {
                QSqlQueryModel * model= new QSqlQueryModel();
                model->setQuery("select * from salle order by MAX ASC");
                model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num "));
                model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
                model->setHeaderData(2, Qt::Horizontal, QObject::tr("Max "));
                ui->tabsalle->setModel(model);
                    ui->tabsalle->show();
            }
    else
                if(combo == "MAX decroissant")
                {
                    QSqlQueryModel * model= new QSqlQueryModel();
                    model->setQuery("select * from salle order by MAX DESC");
                    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num "));
                    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
                    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Max "));
                    ui->tabsalle->setModel(model);
                        ui->tabsalle->show();
                }
}
