#include "evenement.h"
#include <QDebug>
#include "connexion.h"
#include <QtSql/QSqlQueryModel>
//#include <QtSql/QSqlQuery>
Evenement::Evenement() //constructeur par def
{
idEv=0;
nomEv="";
dateEv="";
}


Evenement::Evenement(int id,QString nom,QString date,int idf) // constructeur parametre
{
  this->idEv=id;
  this->nomEv=nom;
  this->dateEv=date;
  this->idFete=idf;
}

//Getters
QString Evenement::getnomEv(){return  nomEv;}
QString Evenement::getdateEv(){return dateEv;}
int Evenement::getidEv(){return  idEv;}


//fonction ajouter evenement
bool Evenement::ajouter()
{
QSqlQuery query;
QString res= QString::number(idEv);
query.prepare("INSERT INTO evenement (IDEV, NOMEV, DATEEV, IDFETE) "
                    "VALUES (:idEv, :nomEv, :dateEv, :idFete)");
query.bindValue(":idEv", res);
query.bindValue(":nomEv", nomEv);
query.bindValue(":dateEv", dateEv);
query.bindValue(":idFete", idFete);


return    query.exec();
}


//fonction afficher liste d'évenements
QSqlQueryModel * Evenement::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from evenement");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID event"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom event"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Date event")); //QObject::tr("") : nom de la colonne
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Id de la fete affectée "));


    return model;
}


//fonction modifier evenemet
bool Evenement::modifier(int id_Ev, QString nom_Ev, QString date_Ev, int id_Fete)
{
    QSqlQuery query;

        query.prepare("UPDATE evenement SET nomEv=:nomEv, dateEv=:dateEv, idFete=:idFete  WHERE idEv=:idEv;");

        query.bindValue(":idEv", id_Ev);
        query.bindValue(":nomEv", nom_Ev);
        query.bindValue(":dateEv", date_Ev);
        query.bindValue(":idFete", id_Fete);


        return    query.exec();
}



//fonction supprimer evenement
bool Evenement::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from evenement where IDEV = :idEv ");
query.bindValue(":idEv", res);
return    query.exec();
}

//fonction recherche selon id
QSqlQueryModel * Evenement::rechercher(int id){

    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * from evenement where IDEV =:id");
    query.bindValue(":id",id);
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("id event"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom event"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Date event"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("id de la fete affectee"));



    return model;
}

//Tri evenement par date plus recente
QSqlQueryModel * Evenement::afficher_tri_date()
{
    QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from evenement order by dateEv ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id event"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom event"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Date event"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("id de la fete affectee"));

    return model;
}


