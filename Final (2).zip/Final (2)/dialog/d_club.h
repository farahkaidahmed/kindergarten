#ifndef DIALOG1_H
#define DIALOG1_H
#include "club.h"
#include "ui_d_ev.h"
#include "salle.h"
#include <QDialog>
//#include <QtSql/QSqlQuery>
//#include <QtSql/QSqlQueryModel>

namespace Ui {
class Dialog1;
}

class Dialog1 : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog1(QWidget *parent = nullptr);
    ~Dialog1();
private slots:
    //void on_pushButton_1_clicked();

    void on_pb_ajouter_clicked();

    void on_pb_supprimer_clicked();

    void on_pb_ajouter_s_clicked();

    void on_pb_supprimer_s_clicked();

    //void on_spinBox_valueChanged(const QString &arg1);

    //void on_comboBox_activated(const QString &arg1);

    void on_pb_modifier_clicked();

    void on_pb_modifier_s_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pb_chercher_s_clicked();

    void on_pb_trier_s_clicked();

private:
    Ui::Dialog1 *ui;
    club tmpclub;
    salle tmpsalle;
};

#endif // DIALOG_H
