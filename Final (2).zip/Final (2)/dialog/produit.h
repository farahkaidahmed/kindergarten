#ifndef PRODUIT_H
#define PRODUIT_H


#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class produit
{
    QString ref;
    QString designation;
    QString fournisseur;
    double prix_achat;
    QString date_achat;
    double montant_TVA;
   double prix_unitaire;
    int quantite;
public:
    QString Getref () {return  ref ;}
    void setref (QString val) { ref=val ;}
    QString Getdesignation () {return designation ;}
    void setdesignation (QString val) {designation=val ;}
    QString Getfournisseur () {return fournisseur ;}
    void setfournisseur (QString val) {fournisseur=val ;}
    double Getprix_achat () {return prix_achat ;}
    void setprix_achat (double val) {prix_achat=val ;}
    QString Getdate_achat () {return  date_achat ;}
    void setdate_achat (QString val) { date_achat=val ;}
    double Getmontant_TVA () {return montant_TVA ;}
    void setmontant_TVA (double val) {montant_TVA=val ;}
    double Getprix_unitaire () {return prix_unitaire;}
    void setprix_unitaire(double val) {prix_unitaire=val ;}
    int Getquantite () {return quantite;}
    void setquantite(int val) {quantite=val ;}
    produit();
    float pourcentage();
    float pourcentage_h();
    bool ajout_produit(produit &P);
    QSqlQueryModel *afficher();
    bool supprimer_produit(QString designation);
    bool rechercherproduit(QString val,produit &P);
    bool modifier_produit(produit &P);
    QSqlQueryModel * rechercher(QString designation);
    QSqlQueryModel * recherche();
    QSqlQueryModel * recherchertri(QString val1,QString val2);


};
#endif // PRODUIT_H
