#include "piechartwidget.h"
#include "fete.h"
#include "d_ev.h"
#include <QPainter>


PieChartWidget::PieChartWidget(QWidget *parent) :
    QWidget(parent)
{

}

void PieChartWidget::paintEvent(QPaintEvent *)
{   Fete tmpfete;
    QPainter painter (this);
    QRectF size = QRectF(5,5, this->width()-10,this->width()-10);

    int moins = tmpfete.stat_moins();
    //moins= ((moins * 360) / 100);
    painter.setBrush(Qt::green);
    painter.drawPie(size, 0, ((moins*36)/10)*16);

    //int plus = tmpfete.stat_plus();
    //plus= ((plus * 360) / 100);
    painter.setBrush(Qt::yellow);
    painter.drawPie(size, ((moins*36)/10)*16,(360-((moins*36)/10))*16);

}
