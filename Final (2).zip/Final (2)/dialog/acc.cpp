#include "acc.h"
#include "ui_mainwindow.h"
#include "d_ev.h"
#include "d_club.h"
#include "menu_ui.h"
#include "QDialog"
#include "QMessageBox"
#include <QApplication>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_connect_clicked()
{ if ( (ui->connect1->text()== "event") && (ui->connect2->text() == "event") )
   {  QMessageBox::information(nullptr, QObject::tr("Bienvenue, organisateur d'événements!."),
      QObject::tr("Vous avez maintenant accés à la gestion des événements.\n""Poursuivre:"), QMessageBox::Accepted);

     MainWindow w;
     close();
     Dialog d_ev;
     d_ev.exec();}
    else
        if ( (ui->connect1->text()== "club") && (ui->connect2->text() == "club") )
        {  QMessageBox::information(nullptr, QObject::tr("Bienvenue, gestionnaire des clubs!."),
           QObject::tr("Vous avez maintenant accés à la gestion des clubs.\n""Poursuivre:"), QMessageBox::Accepted);

          MainWindow w;
          close();
          Dialog1 d_club;
          d_club.exec();}


        else
            if ( (ui->connect1->text()== "menu") && (ui->connect2->text() == "menu") )
            {  QMessageBox::information(nullptr, QObject::tr("Bienvenue, gestionnaire des menus!."),
               QObject::tr("Vous avez maintenant accés à la gestion des menus.\n""Poursuivre:"), QMessageBox::Accepted);

              MainWindow w;
              close();
              menu_ui d_menu;
              d_menu.exec();}



        else {
        QMessageBox::information(nullptr, QObject::tr("Echec de connexion."),
        QObject::tr("Verifier vos parametres.\n""Cliquez sur Cancel pour Quitter."), QMessageBox::Cancel);

    }
}
