#include "mon_menu.h"
#include <QDebug>
mon_menu::mon_menu()
{}
    bool mon_menu::ajout_menu(mon_menu &m)
    {
        QSqlQuery query;

        query.prepare("INSERT INTO menu (designation_menu,preparateur,jour,ref_produit1,ref_produit2,ref_produit3) "
                      "VALUES (:designation_menu,:preparateur,:jour,:ref_produit1,:ref_produit2,:ref_produit3)");
    query.bindValue(0,m.Getdesignation_menu());
        query.bindValue(1,m.Getpreparateur());

        query.bindValue(2,m.Getjour());
        query.bindValue(3,m.Getref_produit1());
         query.bindValue(4,m.Getref_produit2());
        query.bindValue(5,m.Getref_produit3());

        if(query.exec()){
           return true;
        }
       else return false;

    }
    QSqlQueryModel *mon_menu::affiche_menu()
    {
        QSqlQueryModel *model = new QSqlQueryModel();
        model->setQuery("select * from menu");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("designation"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("preparateur"));
        model->setHeaderData(3, Qt::Horizontal, QObject::tr("jour"));
        model->setHeaderData(4, Qt::Horizontal, QObject::tr("entree"));
        model->setHeaderData(5, Qt::Horizontal, QObject::tr("plat principal"));
        model->setHeaderData(6, Qt::Horizontal, QObject::tr("dessert"));

        return model;
    }
    float mon_menu::pourcentage_produit(QString val)
    {
    QSqlQueryModel *model1 = new QSqlQueryModel() ;
        QSqlQueryModel *model = new QSqlQueryModel() ;
       QSqlQuery afficheeh;
       model->setQuery("select * from menu ");
       if(afficheeh.exec("select * from menu where ref_produit1  like '%"+val+"%' or ref_produit2  like  '%"+val+"%' or ref_produit3  like '%"+val+"%' "))
       qDebug()<<"bb";

       model1->setQuery(afficheeh);
       int nbr_total = 0 ;
       int nbr_hygiene = 0 ;
       int pourcentage_b = 0 ;
       nbr_total = model->rowCount();

       nbr_hygiene = model1->rowCount();
       qDebug()<<"hygiene="<<nbr_hygiene<<"total="<<nbr_total;
       pourcentage_b = (nbr_hygiene * 100) / nbr_total ;

       return pourcentage_b;
    }
    QSqlQueryModel * mon_menu::rechercher(QString val)
    {

        QSqlQuery query;
        QSqlQueryModel* model = new QSqlQueryModel();
        query.prepare("select * from menu where DESIGNATION_MENU like '%"+val+"%' or PREPARATEUR like '%"+val+"%' or JOUR  like '%"+val+"%' or REF_PRODUIT1 like '%"+val+"%' or REF_PRODUIT2 like '%"+val+"%' or REF_PRODUIT3 like '%"+val+"%' or ID_MENU  like '%"+val+"%' ");
        if(query.exec()){
            model->setQuery(query);
        }
    return model;
    }
    bool mon_menu::recherchermon_menu(QString val,mon_menu &F){
        QSqlQuery query;

        query.prepare("select * from menu where id_menu like '%"+val+"%' or DESIGNATION_MENU like '%"+val+"%' or PREPARATEUR like '%"+val+"%' or JOUR  like '%"+val+"%' or REF_PRODUIT1 like '%"+val+"%' or REF_PRODUIT2 like '%"+val+"%' or REF_PRODUIT3 like '%"+val+"%' or ID_MENU  like '%"+val+"%' ");
        if(query.exec()){
            while(query.next()){
    F.setid_menu(query.value(0).toInt());
                F.setdesignation_menu(query.value(1).toString());
                F.setpreparateur(query.value(2).toString());
                F.setjour(query.value(3).toString());
                F.setref_produit1(query.value(4).toString());
                F.setref_produit2(query.value(5).toString());
                F.setref_produit3(query.value(5).toString());
            }
            return true;
        }
        else
            return false;
    }

    bool mon_menu::supprimer_menu(QString nom)
    {
    QSqlQuery query;
        QString ID1=nom;
        query.prepare("delete from menu where designation_menu=?");
        query.addBindValue(ID1);
        return (query.exec());
    }
    bool mon_menu::modifier_menu(mon_menu &F)
     {
        QSqlQuery query;
        query.prepare("update menu set id_menu = ? ,designation_menu = ?,"
                      " PREPARATEUR = ?, JOUR = ?, REF_PRODUIT1 = ?, REF_PRODUIT2 = ?, REF_PRODUIT3 = ?"
                      " where id_menu = ?"
                      );
        query.addBindValue(F.Getid_menu());
        query.addBindValue(F.Getdesignation_menu());
        query.addBindValue(F.Getpreparateur());
        query.addBindValue(F.Getjour());
        query.addBindValue(F.Getref_produit1());
        query.addBindValue(F.Getref_produit2());
        query.addBindValue(F.Getref_produit3());
         query.addBindValue(F.Getid_menu());
        if(query.exec()){
            return true;
        }
        else
            return false;
     }
