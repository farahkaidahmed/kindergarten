#ifndef PRODUIT_UI_H
#define PRODUIT_UI_H

#include <QDialog>

namespace Ui {
class produit_ui;
}

class produit_ui : public QDialog
{
    Q_OBJECT

public:
    explicit produit_ui(QWidget *parent = 0);
    ~produit_ui();

private slots:
    void on_pushButton_clicked();

    void on_ajout_produit_clicked();

    void on_supprimer_2_clicked();

    void on_modifier_2_activated(const QModelIndex &index);



   void on_ajouter_tabBarClicked(int index);

    void on_pushButton_2_clicked();

    void on_recherche_afficher_3_textChanged(const QString &arg1);

    void on_supprimer_activated(const QModelIndex &index);




   void on_recherche_afficher_cursorPositionChanged(int arg1, int arg2);

    void on_recherche_afficher_2_cursorPositionChanged(int arg1, int arg2);

    void on_recherche_afficher_3_cursorPositionChanged(int arg1, int arg2);


    void on_modifier_clicked();





    void on_comboBox_2_currentIndexChanged(const QString &arg1);

    void on_comboBox_3_currentIndexChanged(const QString &arg1);



private:
    Ui::produit_ui *ui;
};

#endif // PRODUIT_UI_H
