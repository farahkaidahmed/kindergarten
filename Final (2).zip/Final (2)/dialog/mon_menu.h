#ifndef MON_MENU_H
#define MON_MENU_H

#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class mon_menu
{
    int id_menu;
    QString designation_menu;
    QString preparateur;
    QString jour;
    QString ref_produit1;
    QString ref_produit2;
    QString ref_produit3;
public:
    mon_menu();
    int Getid_menu() {return id_menu ;}
    void setid_menu (int val) {id_menu=val ;}
    QString Getdesignation_menu () {return  designation_menu ;}
    void setdesignation_menu (QString val) { designation_menu=val ;}

    QString Getpreparateur () {return preparateur ;}
    void setpreparateur (QString val) {preparateur=val ;}
    QString Getjour () {return jour ;}
    void setjour (QString val) {jour=val ;}
    QString Getref_produit1() {return ref_produit1;}
    void setref_produit1(QString val) {ref_produit1=val ;}
    QString Getref_produit2() {return ref_produit2;}
    void setref_produit2(QString val) {ref_produit2=val ;}
    QString Getref_produit3() {return ref_produit3;}
    void setref_produit3(QString val) {ref_produit3=val ;}
    bool ajout_menu(mon_menu &m);
     QSqlQueryModel *affiche_menu();
     float pourcentage_produit(QString val);
      QSqlQueryModel * rechercher(QString designation);
      bool recherchermon_menu(QString val,mon_menu &F);
        bool supprimer_menu(QString nom);
        bool modifier_menu(mon_menu &F);

};

#endif // MON_MENU_H
