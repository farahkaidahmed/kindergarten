#ifndef CLUB_H
#define CLUB_H
#include <QString>
//#include <QSqlQuery>
//#include <QSqlQueryModel>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlQueryModel>
class club
{public:
    club();
    club(QString,int,int,int);
    QString get_nom();
    int get_id();
    int get_prix();
    int get_num_salle();
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(int);
    bool modifier(int);
    QSqlQueryModel * rechercher(int);
    int stat_plus();
    int stat_moins();
private:
    QString nom;
    int id,prix,num_salle;
};


#endif // CLUB_H
