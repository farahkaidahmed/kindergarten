#include "piechart.h"
#include <QDebug>
#include "connexion.h"
//#include <QSqlQuery>
#include <QtSql/QSqlQuery>
#include <QPainter>
#include "club.h"

pieChart::pieChart(QWidget *parent) :
QWidget(parent)
{

}

void pieChart::paintEvent(QPaintEvent *)
{


        club tmpclub;
        QPainter painter (this);
        QRectF size = QRectF(5,5, this->width()-10,this->width()-10);

        int moins = tmpclub.stat_moins();
        //moins= ((moins * 360) / 100);
        painter.setBrush(Qt::green);
        painter.drawPie(/*size, 0, (moins*16)*/  size, 0,((moins*36)/10)*16 );

        //int plus = tmpclub.stat_plus();
        //plus= ((plus * 360) / 100);
        painter.setBrush(Qt::yellow);
        painter.drawPie(/*size, ((360-plus)*16),(plus*16)*/ size,((moins*36)/10)*16,(360-((moins*36)/10))*16  );








  /*************  QSqlQuery query ;
    query.prepare("select count(*) from club");
    QSqlQuery query1 ;
    query1.prepare("select count(*) from club where PRIX > :50 ");
    //query.exec();
    //query1.exec();
    if(query.exec() && query1.exec())
        {
            while(query.next() && query1.next())
            {
                QObject::tr("Ajouter un club") ;
                QString  total= query.value(0).toString();
                int tot=total.toInt();
                QString  n= query1.value(0).toString();
                int nn=n.toInt();
                int x=(nn*100)/tot ;

                QPainter painter(this);
                QRectF size = QRectF(10,10,this->width()-10,this->width()-10);
                painter.setBrush(Qt::green);
                painter.drawPie(size,0,((x*36)/10)*16);
                painter.setBrush(Qt::blue);
                painter.drawPie(size,((x*36)/10)*16,(360-((x*36)/10))*16);
            }
        }
**************/

   /* QSqlQuery query1 ;
    query1.prepare("select count(*) from club where PRIX>50 ");
    if(query1.exec())
        {
            while(query1.next())
            {
                QString  n= query1.value(0).toString();
                int nn=n.toInt();
            }
        }
    int x=(nn*100)/tot ;*/

    /*QPainter painter(this);
    QRectF size = QRectF(10,10,this->width()-10,this->width()-10);
    painter.setBrush(Qt::green);
    painter.drawPie(size,0,((25*36)/10)*16);
    painter.setBrush(Qt::blue);
    painter.drawPie(size,((25*36)/10)*16,(360-((25*36)/10))*16);*/
}

