/********************************************************************************
** Form generated from reading UI file 'gestion_menu_ui.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESTION_MENU_UI_H
#define UI_GESTION_MENU_UI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QCommandLinkButton>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gestion_menu_ui
{
public:
    QTabWidget *tabWidget;
    QWidget *tab_2;
    QTabWidget *jour;
    QWidget *ajout;
    QLineEdit *designation_menu;
    QLabel *label_2;
    QPushButton *ajout_menu;
    QLabel *l_controle_saisie_2;
    QLabel *label_3;
    QLabel *label_6;
    QLineEdit *preparateur_menu;
    QDateEdit *jour_menu;
    QLabel *label_4;
    QLabel *label_14;
    QLabel *label_16;
    QLabel *label_17;
    QComboBox *comboBox_1;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QLabel *ma;
    QWidget *widget;
    QWidget *afficher;
    QTableView *affich;
    QLineEdit *recherche_afficher;
    QCommandLinkButton *commandLinkButton;
    QPushButton *excel;
    QWidget *tab_4;
    QTableView *supprimermenu;
    QCommandLinkButton *commandLinkButton_3;
    QLabel *label_8;
    QPushButton *supprimer_22;
    QLineEdit *nom_22;
    QLineEdit *recherche_afficher_2;
    QWidget *tab_5;
    QTableView *modifier_3;
    QLabel *label_32;
    QLabel *label_33;
    QLabel *label_34;
    QLineEdit *designation;
    QLineEdit *jour_2;
    QLineEdit *id_menu;
    QLineEdit *p1;
    QCommandLinkButton *commandLinkButton_6;
    QLabel *label_35;
    QLabel *label_36;
    QLineEdit *p2;
    QLineEdit *preparateur;
    QPushButton *modifier_4;
    QLineEdit *recherche_afficher_6;
    QLabel *label_37;
    QPushButton *pushButton_3;
    QLineEdit *p3;
    QLabel *label_38;
    QWidget *tab;
    QComboBox *combo;
    QWidget *verticalWidget;
    QVBoxLayout *bbb;
    QPushButton *pushButton;

    void setupUi(QDialog *gestion_menu_ui)
    {
        if (gestion_menu_ui->objectName().isEmpty())
            gestion_menu_ui->setObjectName(QStringLiteral("gestion_menu_ui"));
        gestion_menu_ui->resize(841, 545);
        tabWidget = new QTabWidget(gestion_menu_ui);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 781, 521));
        tabWidget->setStyleSheet(QStringLiteral("background-image: url(:/photos/b.png);"));
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        jour = new QTabWidget(tab_2);
        jour->setObjectName(QStringLiteral("jour"));
        jour->setGeometry(QRect(0, 10, 781, 521));
        jour->setStyleSheet(QStringLiteral(""));
        ajout = new QWidget();
        ajout->setObjectName(QStringLiteral("ajout"));
        designation_menu = new QLineEdit(ajout);
        designation_menu->setObjectName(QStringLiteral("designation_menu"));
        designation_menu->setGeometry(QRect(250, 20, 261, 31));
        designation_menu->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_2 = new QLabel(ajout);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(90, 30, 151, 20));
        ajout_menu = new QPushButton(ajout);
        ajout_menu->setObjectName(QStringLiteral("ajout_menu"));
        ajout_menu->setGeometry(QRect(530, 330, 161, 61));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        ajout_menu->setFont(font);
        ajout_menu->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-color: red;\n"
"\n"
""));
        l_controle_saisie_2 = new QLabel(ajout);
        l_controle_saisie_2->setObjectName(QStringLiteral("l_controle_saisie_2"));
        l_controle_saisie_2->setGeometry(QRect(180, 380, 231, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("Arial Black"));
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        l_controle_saisie_2->setFont(font1);
        label_3 = new QLabel(ajout);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(140, 130, 81, 16));
        label_6 = new QLabel(ajout);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(120, 80, 111, 20));
        preparateur_menu = new QLineEdit(ajout);
        preparateur_menu->setObjectName(QStringLiteral("preparateur_menu"));
        preparateur_menu->setGeometry(QRect(250, 70, 261, 31));
        preparateur_menu->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        jour_menu = new QDateEdit(ajout);
        jour_menu->setObjectName(QStringLiteral("jour_menu"));
        jour_menu->setGeometry(QRect(250, 120, 261, 41));
        jour_menu->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_4 = new QLabel(ajout);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(80, 190, 261, 51));
        label_14 = new QLabel(ajout);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(50, 340, 111, 20));
        label_16 = new QLabel(ajout);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(210, 340, 111, 20));
        label_17 = new QLabel(ajout);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(370, 340, 111, 20));
        comboBox_1 = new QComboBox(ajout);
        comboBox_1->setObjectName(QStringLiteral("comboBox_1"));
        comboBox_1->setGeometry(QRect(40, 281, 91, 31));
        comboBox_2 = new QComboBox(ajout);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(190, 281, 101, 31));
        comboBox_3 = new QComboBox(ajout);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(360, 281, 91, 31));
        ma = new QLabel(ajout);
        ma->setObjectName(QStringLiteral("ma"));
        ma->setGeometry(QRect(370, 190, 161, 41));
        widget = new QWidget(ajout);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(399, 20, 311, 261));
        widget->setStyleSheet(QStringLiteral("image: url(:/balloon.gif);"));
        jour->addTab(ajout, QString());
        label_2->raise();
        ajout_menu->raise();
        l_controle_saisie_2->raise();
        label_3->raise();
        label_6->raise();
        label_4->raise();
        label_14->raise();
        label_16->raise();
        label_17->raise();
        comboBox_1->raise();
        comboBox_2->raise();
        comboBox_3->raise();
        widget->raise();
        ma->raise();
        designation_menu->raise();
        preparateur_menu->raise();
        jour_menu->raise();
        afficher = new QWidget();
        afficher->setObjectName(QStringLiteral("afficher"));
        affich = new QTableView(afficher);
        affich->setObjectName(QStringLiteral("affich"));
        affich->setGeometry(QRect(40, 110, 701, 241));
        recherche_afficher = new QLineEdit(afficher);
        recherche_afficher->setObjectName(QStringLiteral("recherche_afficher"));
        recherche_afficher->setGeometry(QRect(350, 30, 291, 61));
        commandLinkButton = new QCommandLinkButton(afficher);
        commandLinkButton->setObjectName(QStringLiteral("commandLinkButton"));
        commandLinkButton->setGeometry(QRect(230, 30, 81, 51));
        QFont font2;
        font2.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font2.setPointSize(10);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(9);
        commandLinkButton->setFont(font2);
        commandLinkButton->setStyleSheet(QLatin1String("color: rgb(255, 0, 0);\n"
"font: 75 10pt \"MS Shell Dlg 2\";\n"
"\n"
""));
        QIcon icon;
        icon.addFile(QStringLiteral("../../../trouver-recherche-zoom-icone-4701-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        commandLinkButton->setIcon(icon);
        commandLinkButton->setIconSize(QSize(25, 25));
        excel = new QPushButton(afficher);
        excel->setObjectName(QStringLiteral("excel"));
        excel->setGeometry(QRect(1050, 10, 75, 23));
        jour->addTab(afficher, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        supprimermenu = new QTableView(tab_4);
        supprimermenu->setObjectName(QStringLiteral("supprimermenu"));
        supprimermenu->setGeometry(QRect(30, 70, 681, 211));
        commandLinkButton_3 = new QCommandLinkButton(tab_4);
        commandLinkButton_3->setObjectName(QStringLiteral("commandLinkButton_3"));
        commandLinkButton_3->setGeometry(QRect(50, 10, 181, 61));
        QFont font3;
        font3.setFamily(QStringLiteral("Segoe UI"));
        font3.setItalic(true);
        commandLinkButton_3->setFont(font3);
        commandLinkButton_3->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        commandLinkButton_3->setIcon(icon);
        commandLinkButton_3->setIconSize(QSize(25, 25));
        label_8 = new QLabel(tab_4);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(140, 300, 131, 71));
        supprimer_22 = new QPushButton(tab_4);
        supprimer_22->setObjectName(QStringLiteral("supprimer_22"));
        supprimer_22->setGeometry(QRect(560, 310, 151, 51));
        supprimer_22->setFont(font);
        supprimer_22->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        nom_22 = new QLineEdit(tab_4);
        nom_22->setObjectName(QStringLiteral("nom_22"));
        nom_22->setGeometry(QRect(280, 310, 221, 41));
        nom_22->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        recherche_afficher_2 = new QLineEdit(tab_4);
        recherche_afficher_2->setObjectName(QStringLiteral("recherche_afficher_2"));
        recherche_afficher_2->setGeometry(QRect(200, 10, 221, 41));
        jour->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        modifier_3 = new QTableView(tab_5);
        modifier_3->setObjectName(QStringLiteral("modifier_3"));
        modifier_3->setGeometry(QRect(260, 50, 501, 281));
        label_32 = new QLabel(tab_5);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(30, 30, 47, 13));
        label_33 = new QLabel(tab_5);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(20, 220, 47, 13));
        label_34 = new QLabel(tab_5);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(10, 60, 101, 31));
        designation = new QLineEdit(tab_5);
        designation->setObjectName(QStringLiteral("designation"));
        designation->setGeometry(QRect(80, 60, 141, 31));
        designation->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        jour_2 = new QLineEdit(tab_5);
        jour_2->setObjectName(QStringLiteral("jour_2"));
        jour_2->setGeometry(QRect(80, 160, 141, 31));
        jour_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
"\n"
""));
        id_menu = new QLineEdit(tab_5);
        id_menu->setObjectName(QStringLiteral("id_menu"));
        id_menu->setGeometry(QRect(80, 20, 141, 31));
        id_menu->setStyleSheet(QLatin1String("\n"
"border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        p1 = new QLineEdit(tab_5);
        p1->setObjectName(QStringLiteral("p1"));
        p1->setGeometry(QRect(80, 210, 141, 31));
        p1->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        commandLinkButton_6 = new QCommandLinkButton(tab_5);
        commandLinkButton_6->setObjectName(QStringLiteral("commandLinkButton_6"));
        commandLinkButton_6->setGeometry(QRect(320, 0, 181, 51));
        commandLinkButton_6->setFont(font3);
        commandLinkButton_6->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        commandLinkButton_6->setIcon(icon);
        commandLinkButton_6->setIconSize(QSize(25, 25));
        label_35 = new QLabel(tab_5);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(20, 170, 47, 13));
        label_36 = new QLabel(tab_5);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(30, 270, 61, 20));
        p2 = new QLineEdit(tab_5);
        p2->setObjectName(QStringLiteral("p2"));
        p2->setGeometry(QRect(80, 270, 141, 31));
        p2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        preparateur = new QLineEdit(tab_5);
        preparateur->setObjectName(QStringLiteral("preparateur"));
        preparateur->setGeometry(QRect(80, 110, 141, 31));
        preparateur->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        modifier_4 = new QPushButton(tab_5);
        modifier_4->setObjectName(QStringLiteral("modifier_4"));
        modifier_4->setGeometry(QRect(90, 380, 131, 81));
        modifier_4->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;\n"
"\n"
""));
        recherche_afficher_6 = new QLineEdit(tab_5);
        recherche_afficher_6->setObjectName(QStringLiteral("recherche_afficher_6"));
        recherche_afficher_6->setGeometry(QRect(520, 10, 191, 31));
        label_37 = new QLabel(tab_5);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(10, 110, 61, 20));
        pushButton_3 = new QPushButton(tab_5);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(470, 350, 161, 61));
        pushButton_3->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        p3 = new QLineEdit(tab_5);
        p3->setObjectName(QStringLiteral("p3"));
        p3->setGeometry(QRect(80, 320, 141, 31));
        p3->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_38 = new QLabel(tab_5);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(20, 320, 61, 20));
        jour->addTab(tab_5, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        combo = new QComboBox(tab);
        combo->setObjectName(QStringLiteral("combo"));
        combo->setGeometry(QRect(90, 180, 131, 31));
        verticalWidget = new QWidget(tab);
        verticalWidget->setObjectName(QStringLiteral("verticalWidget"));
        verticalWidget->setGeometry(QRect(10, 40, 481, 321));
        verticalWidget->setStyleSheet(QStringLiteral("image: url(:/balloon.gif);"));
        bbb = new QVBoxLayout(verticalWidget);
        bbb->setObjectName(QStringLiteral("bbb"));
        jour->addTab(tab, QString());
        verticalWidget->raise();
        combo->raise();
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(560, 0, 121, 31));
        pushButton->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        tabWidget->addTab(tab_2, QString());
        pushButton->raise();
        jour->raise();

        retranslateUi(gestion_menu_ui);

        tabWidget->setCurrentIndex(0);
        jour->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(gestion_menu_ui);
    } // setupUi

    void retranslateUi(QDialog *gestion_menu_ui)
    {
        gestion_menu_ui->setWindowTitle(QApplication::translate("gestion_menu_ui", "Dialog", Q_NULLPTR));
        designation_menu->setPlaceholderText(QString());
        label_2->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:12pt; color:#ff5500;\">Designation Menu</span></p></body></html>", Q_NULLPTR));
        ajout_menu->setText(QApplication::translate("gestion_menu_ui", "Creer menu ", Q_NULLPTR));
        l_controle_saisie_2->setText(QString());
        label_3->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:12pt; color:#ff5500;\">JOUR</span></p></body></html>", Q_NULLPTR));
        label_6->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:12pt; color:#ff5500;\">Preparateur</span></p></body></html>", Q_NULLPTR));
        label_4->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:14pt; color:#aa0000;\">Veuillez composer votre menu </span></p></body></html>", Q_NULLPTR));
        label_14->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:12pt; color:#ff5500;\">Plat principal</span></p></body></html>", Q_NULLPTR));
        label_16->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:12pt; color:#ff5500;\">salade</span></p></body></html>", Q_NULLPTR));
        label_17->setText(QApplication::translate("gestion_menu_ui", "<html><head/><body><p><span style=\" font-size:12pt; color:#ff5500;\">dessert</span></p></body></html>", Q_NULLPTR));
        ma->setText(QString());
        jour->setTabText(jour->indexOf(ajout), QApplication::translate("gestion_menu_ui", "ajouter  menu", Q_NULLPTR));
        commandLinkButton->setText(QApplication::translate("gestion_menu_ui", "Recherche", Q_NULLPTR));
        excel->setText(QApplication::translate("gestion_menu_ui", "excel", Q_NULLPTR));
        jour->setTabText(jour->indexOf(afficher), QApplication::translate("gestion_menu_ui", "afficher la liste des menus", Q_NULLPTR));
        commandLinkButton_3->setText(QApplication::translate("gestion_menu_ui", "rechercher par nom", Q_NULLPTR));
        label_8->setText(QApplication::translate("gestion_menu_ui", "le menur \303\240 supprimer", Q_NULLPTR));
        supprimer_22->setText(QApplication::translate("gestion_menu_ui", "supprimer", Q_NULLPTR));
        nom_22->setPlaceholderText(QApplication::translate("gestion_menu_ui", "entrer le menu que vous voulez supprimer", Q_NULLPTR));
        jour->setTabText(jour->indexOf(tab_4), QApplication::translate("gestion_menu_ui", "suppression", Q_NULLPTR));
        label_32->setText(QApplication::translate("gestion_menu_ui", "id", Q_NULLPTR));
        label_33->setText(QApplication::translate("gestion_menu_ui", "entree", Q_NULLPTR));
        label_34->setText(QApplication::translate("gestion_menu_ui", "designation", Q_NULLPTR));
        designation->setPlaceholderText(QString());
        jour_2->setPlaceholderText(QString());
        p1->setText(QString());
        p1->setPlaceholderText(QString());
        commandLinkButton_6->setText(QApplication::translate("gestion_menu_ui", "rechercher par nom", Q_NULLPTR));
        label_35->setText(QApplication::translate("gestion_menu_ui", "jour", Q_NULLPTR));
        label_36->setText(QApplication::translate("gestion_menu_ui", "plat", Q_NULLPTR));
        p2->setText(QString());
        p2->setPlaceholderText(QString());
        preparateur->setPlaceholderText(QString());
        modifier_4->setText(QApplication::translate("gestion_menu_ui", "modifier", Q_NULLPTR));
        label_37->setText(QApplication::translate("gestion_menu_ui", "preparateur", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("gestion_menu_ui", "actualiser", Q_NULLPTR));
        p3->setText(QString());
        p3->setPlaceholderText(QString());
        label_38->setText(QApplication::translate("gestion_menu_ui", "dessert", Q_NULLPTR));
        jour->setTabText(jour->indexOf(tab_5), QApplication::translate("gestion_menu_ui", "modifier", Q_NULLPTR));
        jour->setTabText(jour->indexOf(tab), QApplication::translate("gestion_menu_ui", "statistique", Q_NULLPTR));
        pushButton->setText(QApplication::translate("gestion_menu_ui", "retour au menu", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("gestion_menu_ui", "gerer menu", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class gestion_menu_ui: public Ui_gestion_menu_ui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESTION_MENU_UI_H
