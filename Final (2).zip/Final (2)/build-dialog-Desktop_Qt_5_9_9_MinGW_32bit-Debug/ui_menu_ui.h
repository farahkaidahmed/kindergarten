/********************************************************************************
** Form generated from reading UI file 'menu_ui.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_UI_H
#define UI_MENU_UI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCommandLinkButton>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_menu_ui
{
public:
    QCommandLinkButton *Commande_link;
    QCommandLinkButton *commandLinkButton;
    QLabel *label;
    QCommandLinkButton *Commande_link_2;
    QWidget *widget;

    void setupUi(QDialog *menu_ui)
    {
        if (menu_ui->objectName().isEmpty())
            menu_ui->setObjectName(QStringLiteral("menu_ui"));
        menu_ui->setEnabled(true);
        menu_ui->resize(723, 400);
        menu_ui->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"background-image: url(:/photos/b.png);\n"
"\n"
""));
        Commande_link = new QCommandLinkButton(menu_ui);
        Commande_link->setObjectName(QStringLiteral("Commande_link"));
        Commande_link->setEnabled(true);
        Commande_link->setGeometry(QRect(430, 190, 221, 61));
        QFont font;
        font.setFamily(QStringLiteral("Comic Sans MS"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(9);
        Commande_link->setFont(font);
        Commande_link->setStyleSheet(QLatin1String("font: 75 12pt \"Comic Sans MS\";\n"
"\n"
"\n"
"\n"
"border-style: solid;\n"
"border-width: 6px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);"));
        Commande_link->setIconSize(QSize(0, 0));
        Commande_link->setCheckable(false);
        Commande_link->setAutoRepeat(false);
        Commande_link->setAutoExclusive(false);
        commandLinkButton = new QCommandLinkButton(menu_ui);
        commandLinkButton->setObjectName(QStringLiteral("commandLinkButton"));
        commandLinkButton->setEnabled(true);
        commandLinkButton->setGeometry(QRect(120, 190, 221, 61));
        commandLinkButton->setFont(font);
        commandLinkButton->setStyleSheet(QLatin1String("font: 75 12pt \"Comic Sans MS\";\n"
"\n"
"\n"
"border-style: solid;\n"
"border-width: 6px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        QIcon icon;
        icon.addFile(QStringLiteral(":/new/prefix1/images/slim(1).png.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        commandLinkButton->setIcon(icon);
        commandLinkButton->setIconSize(QSize(40, 40));
        label = new QLabel(menu_ui);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 0, 151, 181));
        QFont font1;
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        label->setFont(font1);
        label->setStyleSheet(QStringLiteral("color:rgb(0, 170, 0)"));
        Commande_link_2 = new QCommandLinkButton(menu_ui);
        Commande_link_2->setObjectName(QStringLiteral("Commande_link_2"));
        Commande_link_2->setEnabled(true);
        Commande_link_2->setGeometry(QRect(250, 300, 221, 61));
        Commande_link_2->setFont(font);
        Commande_link_2->setStyleSheet(QLatin1String("font: 75 12pt \"Comic Sans MS\";\n"
"\n"
"\n"
"border-style: solid;\n"
"border-width: 6px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);"));
        Commande_link_2->setIconSize(QSize(0, 0));
        Commande_link_2->setCheckable(false);
        Commande_link_2->setAutoRepeat(false);
        Commande_link_2->setAutoExclusive(false);
        widget = new QWidget(menu_ui);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(220, 30, 301, 151));
        widget->setStyleSheet(QStringLiteral("image: url(:/balloons.png);"));
        Commande_link->raise();
        label->raise();
        commandLinkButton->raise();
        Commande_link_2->raise();
        widget->raise();

        retranslateUi(menu_ui);

        QMetaObject::connectSlotsByName(menu_ui);
    } // setupUi

    void retranslateUi(QDialog *menu_ui)
    {
        menu_ui->setWindowTitle(QApplication::translate("menu_ui", "Dialog", Q_NULLPTR));
        Commande_link->setText(QApplication::translate("menu_ui", "gestion des produits", Q_NULLPTR));
        commandLinkButton->setText(QApplication::translate("menu_ui", "gestion des fournisseurs", Q_NULLPTR));
        label->setText(QApplication::translate("menu_ui", "gestionnaire des menus:\n"
"\n"
"Chaouali\n"
"\n"
" Safe\n"
"\n"
"connect\303\251e", Q_NULLPTR));
        Commande_link_2->setText(QApplication::translate("menu_ui", "gestion des menus", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class menu_ui: public Ui_menu_ui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_UI_H
