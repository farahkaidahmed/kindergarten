/********************************************************************************
** Form generated from reading UI file 'fournisseurs.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FOURNISSEURS_H
#define UI_FOURNISSEURS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QCommandLinkButton>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_fournisseurs
{
public:
    QTabWidget *tabWidget;
    QWidget *tab_2;
    QTabWidget *ajouter;
    QWidget *ajout;
    QLineEdit *adresse;
    QLabel *label_6;
    QLineEdit *nom;
    QLabel *label_5;
    QLineEdit *email;
    QLineEdit *numero_telephone;
    QLabel *label_2;
    QPushButton *ajout_fournisseur;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *l_controle_saisie;
    QComboBox *comboBox;
    QWidget *widget;
    QWidget *afficher;
    QTableView *affiche;
    QLineEdit *recherche_afficher;
    QCommandLinkButton *commandLinkButton;
    QWidget *tab;
    QLabel *label_8;
    QPushButton *supprimer_2;
    QLineEdit *nom_2;
    QLineEdit *recherche_afficher_3;
    QCommandLinkButton *commandLinkButton_3;
    QTableView *supprimer;
    QWidget *tab_3;
    QLineEdit *lineEdit_appreciation;
    QLineEdit *lineEdit_adresse;
    QLineEdit *lineEdit_email;
    QLineEdit *lineEdit_numero_telephone;
    QLineEdit *lineEdit_nom;
    QLabel *label_7;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QTableView *modifier_2;
    QPushButton *modifier;
    QLabel *label;
    QLineEdit *lid_fournisseur;
    QLineEdit *recherche_afficher_2;
    QCommandLinkButton *commandLinkButton_2;
    QPushButton *pushButton_2;
    QWidget *tab_4;
    QGroupBox *groupBox;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *moyen;
    QLabel *bon;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *excellent;
    QLabel *nouveau;
    QLabel *label_13;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_20;
    QLabel *label_23;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *aaa;
    QPushButton *pushButton;

    void setupUi(QDialog *fournisseurs)
    {
        if (fournisseurs->objectName().isEmpty())
            fournisseurs->setObjectName(QStringLiteral("fournisseurs"));
        fournisseurs->resize(843, 514);
        fournisseurs->setStyleSheet(QStringLiteral("background-image: url(:/photos/b.png);"));
        tabWidget = new QTabWidget(fournisseurs);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 791, 521));
        tabWidget->setStyleSheet(QStringLiteral("background-image: url(:/photos/b.png);"));
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        ajouter = new QTabWidget(tab_2);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setGeometry(QRect(0, 20, 791, 501));
        ajout = new QWidget();
        ajout->setObjectName(QStringLiteral("ajout"));
        adresse = new QLineEdit(ajout);
        adresse->setObjectName(QStringLiteral("adresse"));
        adresse->setGeometry(QRect(240, 210, 151, 20));
        adresse->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_6 = new QLabel(ajout);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(120, 270, 81, 20));
        label_6->setStyleSheet(QLatin1String("\n"
"font: 75 11pt \"MS Shell Dlg 2\";"));
        nom = new QLineEdit(ajout);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(240, 60, 151, 20));
        nom->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_5 = new QLabel(ajout);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(150, 210, 71, 16));
        label_5->setStyleSheet(QLatin1String("\n"
"font: 75 11pt \"MS Shell Dlg 2\";"));
        email = new QLineEdit(ajout);
        email->setObjectName(QStringLiteral("email"));
        email->setGeometry(QRect(240, 160, 151, 20));
        email->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        numero_telephone = new QLineEdit(ajout);
        numero_telephone->setObjectName(QStringLiteral("numero_telephone"));
        numero_telephone->setGeometry(QRect(240, 110, 151, 20));
        numero_telephone->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_2 = new QLabel(ajout);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(140, 60, 91, 21));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(9);
        label_2->setFont(font);
        label_2->setStyleSheet(QLatin1String("\n"
"font: 75 11pt \"MS Shell Dlg 2\";"));
        ajout_fournisseur = new QPushButton(ajout);
        ajout_fournisseur->setObjectName(QStringLiteral("ajout_fournisseur"));
        ajout_fournisseur->setGeometry(QRect(450, 140, 151, 51));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        ajout_fournisseur->setFont(font1);
        ajout_fournisseur->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        label_3 = new QLabel(ajout);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(80, 110, 131, 21));
        label_3->setStyleSheet(QLatin1String("font: 75 11pt \"MS Shell Dlg 2\";\n"
""));
        label_4 = new QLabel(ajout);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(160, 160, 61, 21));
        label_4->setStyleSheet(QLatin1String("\n"
"font: 75 11pt \"MS Shell Dlg 2\";\n"
""));
        l_controle_saisie = new QLabel(ajout);
        l_controle_saisie->setObjectName(QStringLiteral("l_controle_saisie"));
        l_controle_saisie->setGeometry(QRect(100, 320, 251, 41));
        QFont font2;
        font2.setFamily(QStringLiteral("Arial Black"));
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setWeight(75);
        l_controle_saisie->setFont(font2);
        comboBox = new QComboBox(ajout);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(240, 260, 151, 31));
        widget = new QWidget(ajout);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(450, 10, 331, 401));
        widget->setStyleSheet(QStringLiteral("image: url(:/balloon.gif);"));
        ajouter->addTab(ajout, QString());
        adresse->raise();
        label_6->raise();
        nom->raise();
        label_5->raise();
        email->raise();
        numero_telephone->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        l_controle_saisie->raise();
        comboBox->raise();
        widget->raise();
        ajout_fournisseur->raise();
        afficher = new QWidget();
        afficher->setObjectName(QStringLiteral("afficher"));
        affiche = new QTableView(afficher);
        affiche->setObjectName(QStringLiteral("affiche"));
        affiche->setGeometry(QRect(30, 80, 651, 231));
        recherche_afficher = new QLineEdit(afficher);
        recherche_afficher->setObjectName(QStringLiteral("recherche_afficher"));
        recherche_afficher->setGeometry(QRect(250, 20, 151, 41));
        recherche_afficher->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        commandLinkButton = new QCommandLinkButton(afficher);
        commandLinkButton->setObjectName(QStringLiteral("commandLinkButton"));
        commandLinkButton->setGeometry(QRect(90, 20, 161, 41));
        QFont font3;
        font3.setFamily(QStringLiteral("Segoe UI"));
        font3.setItalic(true);
        commandLinkButton->setFont(font3);
        commandLinkButton->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        QIcon icon;
        icon.addFile(QStringLiteral("../../../trouver-recherche-zoom-icone-4701-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        commandLinkButton->setIcon(icon);
        commandLinkButton->setIconSize(QSize(25, 25));
        ajouter->addTab(afficher, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        label_8 = new QLabel(tab);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(30, 300, 201, 71));
        supprimer_2 = new QPushButton(tab);
        supprimer_2->setObjectName(QStringLiteral("supprimer_2"));
        supprimer_2->setGeometry(QRect(530, 310, 151, 51));
        supprimer_2->setFont(font1);
        supprimer_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        nom_2 = new QLineEdit(tab);
        nom_2->setObjectName(QStringLiteral("nom_2"));
        nom_2->setGeometry(QRect(250, 320, 151, 31));
        nom_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        recherche_afficher_3 = new QLineEdit(tab);
        recherche_afficher_3->setObjectName(QStringLiteral("recherche_afficher_3"));
        recherche_afficher_3->setGeometry(QRect(190, 20, 181, 41));
        recherche_afficher_3->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        commandLinkButton_3 = new QCommandLinkButton(tab);
        commandLinkButton_3->setObjectName(QStringLiteral("commandLinkButton_3"));
        commandLinkButton_3->setGeometry(QRect(0, 20, 181, 61));
        commandLinkButton_3->setFont(font3);
        commandLinkButton_3->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        commandLinkButton_3->setIcon(icon);
        commandLinkButton_3->setIconSize(QSize(25, 25));
        supprimer = new QTableView(tab);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setGeometry(QRect(0, 70, 681, 211));
        ajouter->addTab(tab, QString());
        recherche_afficher_3->raise();
        commandLinkButton_3->raise();
        supprimer->raise();
        supprimer_2->raise();
        nom_2->raise();
        label_8->raise();
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        lineEdit_appreciation = new QLineEdit(tab_3);
        lineEdit_appreciation->setObjectName(QStringLiteral("lineEdit_appreciation"));
        lineEdit_appreciation->setGeometry(QRect(70, 280, 141, 31));
        lineEdit_appreciation->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        lineEdit_adresse = new QLineEdit(tab_3);
        lineEdit_adresse->setObjectName(QStringLiteral("lineEdit_adresse"));
        lineEdit_adresse->setGeometry(QRect(70, 220, 141, 31));
        lineEdit_adresse->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        lineEdit_email = new QLineEdit(tab_3);
        lineEdit_email->setObjectName(QStringLiteral("lineEdit_email"));
        lineEdit_email->setGeometry(QRect(70, 170, 141, 31));
        lineEdit_email->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
"\n"
""));
        lineEdit_numero_telephone = new QLineEdit(tab_3);
        lineEdit_numero_telephone->setObjectName(QStringLiteral("lineEdit_numero_telephone"));
        lineEdit_numero_telephone->setGeometry(QRect(70, 120, 141, 31));
        lineEdit_numero_telephone->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        lineEdit_nom = new QLineEdit(tab_3);
        lineEdit_nom->setObjectName(QStringLiteral("lineEdit_nom"));
        lineEdit_nom->setGeometry(QRect(70, 80, 141, 31));
        lineEdit_nom->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_7 = new QLabel(tab_3);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(20, 70, 41, 31));
        label_9 = new QLabel(tab_3);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 120, 41, 20));
        label_10 = new QLabel(tab_3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 180, 47, 13));
        label_11 = new QLabel(tab_3);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(10, 230, 47, 13));
        label_12 = new QLabel(tab_3);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(0, 280, 61, 20));
        modifier_2 = new QTableView(tab_3);
        modifier_2->setObjectName(QStringLiteral("modifier_2"));
        modifier_2->setGeometry(QRect(250, 60, 501, 281));
        modifier = new QPushButton(tab_3);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(80, 340, 131, 81));
        modifier->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;\n"
"\n"
""));
        label = new QLabel(tab_3);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 40, 47, 13));
        lid_fournisseur = new QLineEdit(tab_3);
        lid_fournisseur->setObjectName(QStringLiteral("lid_fournisseur"));
        lid_fournisseur->setGeometry(QRect(70, 30, 141, 31));
        lid_fournisseur->setStyleSheet(QLatin1String("\n"
"border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        recherche_afficher_2 = new QLineEdit(tab_3);
        recherche_afficher_2->setObjectName(QStringLiteral("recherche_afficher_2"));
        recherche_afficher_2->setGeometry(QRect(510, 20, 191, 31));
        commandLinkButton_2 = new QCommandLinkButton(tab_3);
        commandLinkButton_2->setObjectName(QStringLiteral("commandLinkButton_2"));
        commandLinkButton_2->setGeometry(QRect(310, 10, 181, 51));
        commandLinkButton_2->setFont(font3);
        commandLinkButton_2->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        commandLinkButton_2->setIcon(icon);
        commandLinkButton_2->setIconSize(QSize(25, 25));
        pushButton_2 = new QPushButton(tab_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(460, 360, 161, 61));
        pushButton_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        ajouter->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        groupBox = new QGroupBox(tab_4);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(430, 70, 261, 291));
        label_14 = new QLabel(groupBox);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(30, 90, 40, 40));
        label_14->setStyleSheet(QLatin1String("color: rgb(255, 0, 0);\n"
"background-color: rgb(255, 0, 0);"));
        label_15 = new QLabel(groupBox);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(100, 30, 61, 31));
        label_16 = new QLabel(groupBox);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(110, 80, 51, 20));
        moyen = new QLabel(groupBox);
        moyen->setObjectName(QStringLiteral("moyen"));
        moyen->setGeometry(QRect(190, 30, 40, 40));
        moyen->setStyleSheet(QLatin1String("font: 16pt \"MS PMincho\";\n"
"background-color:transparent;"));
        bon = new QLabel(groupBox);
        bon->setObjectName(QStringLiteral("bon"));
        bon->setGeometry(QRect(190, 70, 40, 40));
        bon->setStyleSheet(QLatin1String("font: 16pt \"MS PMincho\";\n"
"background-color:transparent;"));
        label_18 = new QLabel(groupBox);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(90, 130, 81, 20));
        label_19 = new QLabel(groupBox);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(90, 180, 91, 20));
        excellent = new QLabel(groupBox);
        excellent->setObjectName(QStringLiteral("excellent"));
        excellent->setGeometry(QRect(190, 120, 40, 40));
        excellent->setStyleSheet(QLatin1String("font: 16pt \"MS PMincho\";\n"
"background-color:transparent;"));
        nouveau = new QLabel(groupBox);
        nouveau->setObjectName(QStringLiteral("nouveau"));
        nouveau->setGeometry(QRect(190, 170, 40, 40));
        nouveau->setStyleSheet(QLatin1String("font: 16pt \"MS PMincho\";\n"
"background-color:transparent;"));
        label_13 = new QLabel(groupBox);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setEnabled(false);
        label_13->setGeometry(QRect(30, 180, 40, 40));
        label_13->setAutoFillBackground(false);
        label_13->setStyleSheet(QLatin1String("\n"
"background-color: Blue;"));
        label_21 = new QLabel(groupBox);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(20, 80, 61, 31));
        label_22 = new QLabel(groupBox);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(20, 180, 61, 31));
        label_20 = new QLabel(groupBox);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(20, 30, 61, 31));
        label_23 = new QLabel(groupBox);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(20, 130, 61, 31));
        verticalLayoutWidget_2 = new QWidget(tab_4);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(29, 9, 381, 371));
        aaa = new QVBoxLayout(verticalLayoutWidget_2);
        aaa->setObjectName(QStringLiteral("aaa"));
        aaa->setContentsMargins(0, 0, 0, 0);
        ajouter->addTab(tab_4, QString());
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(660, 10, 121, 31));
        pushButton->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 4px;\n"
"border-color: red;"));
        tabWidget->addTab(tab_2, QString());

        retranslateUi(fournisseurs);

        tabWidget->setCurrentIndex(0);
        ajouter->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(fournisseurs);
    } // setupUi

    void retranslateUi(QDialog *fournisseurs)
    {
        fournisseurs->setWindowTitle(QApplication::translate("fournisseurs", "Dialog", Q_NULLPTR));
        adresse->setPlaceholderText(QApplication::translate("fournisseurs", "entrer son adresse", Q_NULLPTR));
        label_6->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" color:#ffaa00;\">appr\303\251ciation</span></p></body></html>", Q_NULLPTR));
        nom->setPlaceholderText(QApplication::translate("fournisseurs", "entrer le nom", Q_NULLPTR));
        label_5->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" color:#ffaa00;\">adresse</span></p></body></html>", Q_NULLPTR));
        email->setPlaceholderText(QApplication::translate("fournisseurs", "entrer son email", Q_NULLPTR));
        numero_telephone->setPlaceholderText(QApplication::translate("fournisseurs", "entrer son numero", Q_NULLPTR));
        label_2->setText(QApplication::translate("fournisseurs", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; font-weight:600; font-style:italic; color:#ffaa00; vertical-align:super;\">nom</span></p></body></html>", Q_NULLPTR));
        ajout_fournisseur->setText(QApplication::translate("fournisseurs", "ajouter fournisseur", Q_NULLPTR));
        label_3->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" color:#ffaa00;\">num\303\251ro telephone</span></p></body></html>", Q_NULLPTR));
        label_4->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" color:#ffaa00;\">email</span></p></body></html>", Q_NULLPTR));
        l_controle_saisie->setText(QString());
        ajouter->setTabText(ajouter->indexOf(ajout), QApplication::translate("fournisseurs", "ajouter  un fournisseur", Q_NULLPTR));
        commandLinkButton->setText(QApplication::translate("fournisseurs", "rechercher par nom", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(afficher), QApplication::translate("fournisseurs", "afficher les fournisseurs", Q_NULLPTR));
        label_8->setText(QApplication::translate("fournisseurs", "le nom du fournisseur \303\240 supprimer", Q_NULLPTR));
        supprimer_2->setText(QApplication::translate("fournisseurs", "supprimer", Q_NULLPTR));
        nom_2->setPlaceholderText(QApplication::translate("fournisseurs", "entrer le nom du fournisseur que vous voulez supprimer", Q_NULLPTR));
        commandLinkButton_3->setText(QApplication::translate("fournisseurs", "rechercher par nom", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(tab), QApplication::translate("fournisseurs", "supprimer un fournisseur", Q_NULLPTR));
        lineEdit_appreciation->setText(QString());
        lineEdit_appreciation->setPlaceholderText(QString());
        lineEdit_adresse->setText(QString());
        lineEdit_adresse->setPlaceholderText(QString());
        lineEdit_email->setPlaceholderText(QString());
        lineEdit_numero_telephone->setPlaceholderText(QString());
        lineEdit_nom->setPlaceholderText(QString());
        label_7->setText(QApplication::translate("fournisseurs", "nom", Q_NULLPTR));
        label_9->setText(QApplication::translate("fournisseurs", "num tel", Q_NULLPTR));
        label_10->setText(QApplication::translate("fournisseurs", "email", Q_NULLPTR));
        label_11->setText(QApplication::translate("fournisseurs", "adresse", Q_NULLPTR));
        label_12->setText(QApplication::translate("fournisseurs", "appreciation", Q_NULLPTR));
        modifier->setText(QApplication::translate("fournisseurs", "modifier", Q_NULLPTR));
        label->setText(QApplication::translate("fournisseurs", "id", Q_NULLPTR));
        commandLinkButton_2->setText(QApplication::translate("fournisseurs", "rechercher par nom", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("fournisseurs", "actualiser", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(tab_3), QApplication::translate("fournisseurs", "modifier les donnees", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("fournisseurs", "fournisseur", Q_NULLPTR));
        label_14->setText(QString());
        label_15->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" font-size:14pt;\">Moyen</span></p></body></html>", Q_NULLPTR));
        label_16->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" font-size:14pt;\">Bon</span></p></body></html>", Q_NULLPTR));
        moyen->setText(QApplication::translate("fournisseurs", "00", Q_NULLPTR));
        bon->setText(QApplication::translate("fournisseurs", "00", Q_NULLPTR));
        label_18->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" font-size:14pt;\">Excellent</span></p></body></html>", Q_NULLPTR));
        label_19->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><span style=\" font-size:14pt;\">Nouveau</span></p></body></html>", Q_NULLPTR));
        excellent->setText(QApplication::translate("fournisseurs", "00", Q_NULLPTR));
        nouveau->setText(QApplication::translate("fournisseurs", "00", Q_NULLPTR));
        label_13->setText(QString());
        label_21->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><img src=\":/photos/red.png\"/></p></body></html>", Q_NULLPTR));
        label_22->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><img src=\":/photos/bleuc.jpg\"/></p></body></html>", Q_NULLPTR));
        label_20->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><img src=\":/photos/bleu.png\"/></p></body></html>", Q_NULLPTR));
        label_23->setText(QApplication::translate("fournisseurs", "<html><head/><body><p><img src=\":/photos/The-Color-Yellow.jpg\"/></p></body></html>", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(tab_4), QApplication::translate("fournisseurs", "statistique", Q_NULLPTR));
        pushButton->setText(QApplication::translate("fournisseurs", "retour au menu", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("fournisseurs", "gerer les fournisseurs", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class fournisseurs: public Ui_fournisseurs {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FOURNISSEURS_H
