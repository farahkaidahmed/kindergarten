/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_5;
    QLabel *label_3;
    QFrame *line_18;
    QLabel *label_4;
    QFrame *line_24;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_2;
    QLineEdit *connect2;
    QFrame *line_19;
    QFrame *line_25;
    QFrame *line_16;
    QFrame *line_27;
    QFrame *line_23;
    QFrame *line_22;
    QFrame *line_21;
    QLineEdit *connect1;
    QFrame *line_26;
    QLabel *label_6;
    QPushButton *connect;
    QFrame *line_17;
    QFrame *line_20;
    QFrame *line_28;
    QFrame *line_29;
    QFrame *line_30;
    QMenuBar *menubar;
    QMenu *menuSmart_Kindergarten;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(738, 469);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(-20, 0, 181, 491));
        label->setPixmap(QPixmap(QString::fromUtf8("../images/610mPg9IEEL._AC_SL1152_.jpg")));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(-110, 0, 1031, 901));
        label_5->setPixmap(QPixmap(QString::fromUtf8("../images/610mPg9IEEL._AC_SL1152_.jpg")));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(280, 20, 191, 51));
        label_3->setStyleSheet(QLatin1String("font: 12pt \"MV Boli\";\n"
"color: rgb(255, 85, 0);"));
        line_18 = new QFrame(centralwidget);
        line_18->setObjectName(QStringLiteral("line_18"));
        line_18->setGeometry(QRect(190, 140, 361, 20));
        line_18->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_18->setFrameShadow(QFrame::Plain);
        line_18->setFrameShape(QFrame::HLine);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(260, 90, 51, 41));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../images/logo (1) (1) (1).png")));
        line_24 = new QFrame(centralwidget);
        line_24->setObjectName(QStringLiteral("line_24"));
        line_24->setGeometry(QRect(230, 280, 281, 20));
        line_24->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"color: rgb(85, 170, 0);"));
        line_24->setFrameShadow(QFrame::Plain);
        line_24->setFrameShape(QFrame::HLine);
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(250, 200, 81, 31));
        label_7->setStyleSheet(QLatin1String("color: rgb(0, 170, 0);\n"
"font: 13pt \"MV Boli\";"));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(240, 250, 111, 31));
        label_8->setStyleSheet(QLatin1String("color: rgb(0, 170, 0);\n"
"font: 13pt \"MV Boli\";"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(380, 70, 111, 51));
        label_2->setStyleSheet(QLatin1String("color: rgb(0, 170, 0);\n"
"font: 18pt \"MV Boli\";"));
        connect2 = new QLineEdit(centralwidget);
        connect2->setObjectName(QStringLiteral("connect2"));
        connect2->setGeometry(QRect(360, 250, 141, 31));
        connect2->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        line_19 = new QFrame(centralwidget);
        line_19->setObjectName(QStringLiteral("line_19"));
        line_19->setGeometry(QRect(190, 150, 361, 20));
        line_19->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_19->setFrameShadow(QFrame::Plain);
        line_19->setFrameShape(QFrame::HLine);
        line_25 = new QFrame(centralwidget);
        line_25->setObjectName(QStringLiteral("line_25"));
        line_25->setGeometry(QRect(220, 190, 20, 101));
        line_25->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"color: rgb(85, 170, 0);"));
        line_25->setFrameShadow(QFrame::Plain);
        line_25->setFrameShape(QFrame::VLine);
        line_16 = new QFrame(centralwidget);
        line_16->setObjectName(QStringLiteral("line_16"));
        line_16->setGeometry(QRect(190, 60, 361, 20));
        line_16->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_16->setFrameShadow(QFrame::Plain);
        line_16->setFrameShape(QFrame::HLine);
        line_27 = new QFrame(centralwidget);
        line_27->setObjectName(QStringLiteral("line_27"));
        line_27->setGeometry(QRect(230, 230, 281, 20));
        line_27->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"color: rgb(85, 170, 0);"));
        line_27->setFrameShadow(QFrame::Plain);
        line_27->setFrameShape(QFrame::HLine);
        line_23 = new QFrame(centralwidget);
        line_23->setObjectName(QStringLiteral("line_23"));
        line_23->setGeometry(QRect(540, 70, 20, 291));
        line_23->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_23->setFrameShadow(QFrame::Plain);
        line_23->setFrameShape(QFrame::VLine);
        line_22 = new QFrame(centralwidget);
        line_22->setObjectName(QStringLiteral("line_22"));
        line_22->setGeometry(QRect(180, 70, 20, 291));
        line_22->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_22->setFrameShadow(QFrame::Plain);
        line_22->setFrameShape(QFrame::VLine);
        line_21 = new QFrame(centralwidget);
        line_21->setObjectName(QStringLiteral("line_21"));
        line_21->setGeometry(QRect(230, 180, 281, 20));
        line_21->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"color: rgb(85, 170, 0);"));
        line_21->setFrameShadow(QFrame::Plain);
        line_21->setFrameShape(QFrame::HLine);
        connect1 = new QLineEdit(centralwidget);
        connect1->setObjectName(QStringLiteral("connect1"));
        connect1->setGeometry(QRect(360, 200, 141, 31));
        connect1->setStyleSheet(QLatin1String(" border-style: inset;\n"
"  border-color: coral;\n"
"  border-width: 7px;\n"
"  border-color:  orange yellow green yellow;\n"
""));
        line_26 = new QFrame(centralwidget);
        line_26->setObjectName(QStringLiteral("line_26"));
        line_26->setGeometry(QRect(500, 190, 20, 101));
        line_26->setStyleSheet(QLatin1String("color: rgb(255, 85, 0);\n"
"color: rgb(85, 170, 0);"));
        line_26->setFrameShadow(QFrame::Plain);
        line_26->setFrameShape(QFrame::VLine);
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(330, 100, 191, 31));
        label_6->setStyleSheet(QLatin1String("color: rgb(0, 170, 0);\n"
"color: rgb(255, 85, 0);\n"
"font: 23pt \"MV Boli\";"));
        connect = new QPushButton(centralwidget);
        connect->setObjectName(QStringLiteral("connect"));
        connect->setGeometry(QRect(320, 310, 121, 41));
        QFont font;
        font.setFamily(QStringLiteral("MV Boli"));
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        connect->setFont(font);
        connect->setStyleSheet(QLatin1String("color:green;\n"
"font-size:15px;\n"
"font-style:bold;\n"
"  border: 4px solid #ff5500;\n"
"  padding: px; \n"
"  width: 100px;\n"
"  height: 50px;  \n"
"font: bold large \"MV Boli\"\n"
""));
        line_17 = new QFrame(centralwidget);
        line_17->setObjectName(QStringLiteral("line_17"));
        line_17->setGeometry(QRect(190, 350, 361, 20));
        line_17->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_17->setFrameShadow(QFrame::Plain);
        line_17->setFrameShape(QFrame::HLine);
        line_20 = new QFrame(centralwidget);
        line_20->setObjectName(QStringLiteral("line_20"));
        line_20->setGeometry(QRect(180, 50, 381, 20));
        line_20->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_20->setFrameShadow(QFrame::Plain);
        line_20->setFrameShape(QFrame::HLine);
        line_28 = new QFrame(centralwidget);
        line_28->setObjectName(QStringLiteral("line_28"));
        line_28->setGeometry(QRect(180, 360, 381, 20));
        line_28->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_28->setFrameShadow(QFrame::Plain);
        line_28->setFrameShape(QFrame::HLine);
        line_29 = new QFrame(centralwidget);
        line_29->setObjectName(QStringLiteral("line_29"));
        line_29->setGeometry(QRect(550, 60, 20, 311));
        line_29->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_29->setFrameShadow(QFrame::Plain);
        line_29->setFrameShape(QFrame::VLine);
        line_30 = new QFrame(centralwidget);
        line_30->setObjectName(QStringLiteral("line_30"));
        line_30->setGeometry(QRect(170, 60, 20, 311));
        line_30->setStyleSheet(QStringLiteral("color: rgb(255, 85, 0);"));
        line_30->setFrameShadow(QFrame::Plain);
        line_30->setFrameShape(QFrame::VLine);
        MainWindow->setCentralWidget(centralwidget);
        label_5->raise();
        label->raise();
        label_3->raise();
        line_18->raise();
        label_4->raise();
        line_24->raise();
        label_7->raise();
        label_8->raise();
        label_2->raise();
        connect2->raise();
        line_19->raise();
        line_25->raise();
        line_16->raise();
        line_27->raise();
        line_23->raise();
        line_22->raise();
        line_21->raise();
        connect1->raise();
        line_26->raise();
        label_6->raise();
        connect->raise();
        line_17->raise();
        line_20->raise();
        line_28->raise();
        line_29->raise();
        line_30->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 738, 21));
        menuSmart_Kindergarten = new QMenu(menubar);
        menuSmart_Kindergarten->setObjectName(QStringLiteral("menuSmart_Kindergarten"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuSmart_Kindergarten->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QString());
        label_5->setText(QString());
        label_3->setText(QApplication::translate("MainWindow", "Bienvenue \303\240 l'application", Q_NULLPTR));
        label_4->setText(QString());
        label_7->setText(QApplication::translate("MainWindow", "Identifiant", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Mot de passe", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Smart ", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Kindergarten", Q_NULLPTR));
        connect->setText(QApplication::translate("MainWindow", "Se connecter", Q_NULLPTR));
        menuSmart_Kindergarten->setTitle(QApplication::translate("MainWindow", "Smart Kindergarten", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
