/********************************************************************************
** Form generated from reading UI file 'produit_ui.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUIT_UI_H
#define UI_PRODUIT_UI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QCommandLinkButton>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_produit_ui
{
public:
    QTabWidget *tabWidget;
    QWidget *tab_2;
    QTabWidget *ajouter;
    QWidget *ajout;
    QLineEdit *designation;
    QLabel *label_2;
    QPushButton *ajout_produit;
    QLabel *label_4;
    QLabel *l_controle_saisie;
    QLabel *l_controle_saisie_2;
    QLabel *label_16;
    QLineEdit *ref;
    QLabel *label_3;
    QLineEdit *prix_achat;
    QLabel *label_6;
    QDateEdit *date_achat;
    QLabel *label_14;
    QLineEdit *quantite;
    QComboBox *comboBox;
    QWidget *widget;
    QWidget *afficher;
    QTableView *affiche;
    QLineEdit *recherche_afficher;
    QCommandLinkButton *commandLinkButton;
    QPushButton *excel;
    QLabel *label_5;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QLabel *label_17;
    QWidget *tab;
    QLabel *label_8;
    QPushButton *supprimer_2;
    QLineEdit *designation_produit;
    QLineEdit *recherche_afficher_3;
    QCommandLinkButton *commandLinkButton_3;
    QTableView *supprimer;
    QWidget *tab_3;
    QLineEdit *prix_achat2;
    QLineEdit *date_achat2;
    QLineEdit *designation2;
    QLabel *label_7;
    QLabel *label_10;
    QLabel *label_11;
    QTableView *modifier_2;
    QPushButton *modifier;
    QLabel *label;
    QLineEdit *ref2;
    QLineEdit *recherche_afficher_2;
    QCommandLinkButton *commandLinkButton_2;
    QPushButton *pushButton_2;
    QLabel *label_9;
    QLabel *label_12;
    QLineEdit *prix_unitaire2;
    QLineEdit *montantTVA_2;
    QLabel *label_13;
    QLineEdit *fournisseur_2;
    QLabel *label_15;
    QLineEdit *quantite_2;
    QPushButton *pushButton;

    void setupUi(QDialog *produit_ui)
    {
        if (produit_ui->objectName().isEmpty())
            produit_ui->setObjectName(QStringLiteral("produit_ui"));
        produit_ui->resize(779, 487);
        produit_ui->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        tabWidget = new QTabWidget(produit_ui);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 781, 521));
        tabWidget->setStyleSheet(QStringLiteral("background-image: url(:/photos/b.png);"));
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        ajouter = new QTabWidget(tab_2);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setGeometry(QRect(0, 10, 781, 541));
        ajout = new QWidget();
        ajout->setObjectName(QStringLiteral("ajout"));
        designation = new QLineEdit(ajout);
        designation->setObjectName(QStringLiteral("designation"));
        designation->setGeometry(QRect(180, 90, 261, 31));
        designation->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_2 = new QLabel(ajout);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(80, 90, 71, 20));
        ajout_produit = new QPushButton(ajout);
        ajout_produit->setObjectName(QStringLiteral("ajout_produit"));
        ajout_produit->setGeometry(QRect(530, 270, 161, 61));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        ajout_produit->setFont(font);
        ajout_produit->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-color: red;\n"
"\n"
""));
        label_4 = new QLabel(ajout);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(80, 160, 81, 21));
        l_controle_saisie = new QLabel(ajout);
        l_controle_saisie->setObjectName(QStringLiteral("l_controle_saisie"));
        l_controle_saisie->setGeometry(QRect(470, 340, 301, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("Arial Black"));
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        l_controle_saisie->setFont(font1);
        l_controle_saisie_2 = new QLabel(ajout);
        l_controle_saisie_2->setObjectName(QStringLiteral("l_controle_saisie_2"));
        l_controle_saisie_2->setGeometry(QRect(40, 370, 231, 41));
        l_controle_saisie_2->setFont(font1);
        label_16 = new QLabel(ajout);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(80, 40, 61, 16));
        ref = new QLineEdit(ajout);
        ref->setObjectName(QStringLiteral("ref"));
        ref->setGeometry(QRect(180, 30, 261, 31));
        ref->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_3 = new QLabel(ajout);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(80, 270, 81, 16));
        prix_achat = new QLineEdit(ajout);
        prix_achat->setObjectName(QStringLiteral("prix_achat"));
        prix_achat->setGeometry(QRect(180, 160, 261, 31));
        prix_achat->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_6 = new QLabel(ajout);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(80, 220, 81, 16));
        date_achat = new QDateEdit(ajout);
        date_achat->setObjectName(QStringLiteral("date_achat"));
        date_achat->setGeometry(QRect(180, 260, 261, 41));
        date_achat->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_14 = new QLabel(ajout);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(90, 320, 47, 20));
        quantite = new QLineEdit(ajout);
        quantite->setObjectName(QStringLiteral("quantite"));
        quantite->setGeometry(QRect(180, 330, 261, 31));
        quantite->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        comboBox = new QComboBox(ajout);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(180, 210, 261, 31));
        widget = new QWidget(ajout);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(380, 40, 301, 221));
        widget->setStyleSheet(QStringLiteral("image: url(:/balloon.gif);"));
        ajouter->addTab(ajout, QString());
        label_2->raise();
        ajout_produit->raise();
        label_4->raise();
        l_controle_saisie->raise();
        l_controle_saisie_2->raise();
        label_16->raise();
        label_3->raise();
        label_6->raise();
        date_achat->raise();
        label_14->raise();
        quantite->raise();
        widget->raise();
        ref->raise();
        designation->raise();
        prix_achat->raise();
        comboBox->raise();
        afficher = new QWidget();
        afficher->setObjectName(QStringLiteral("afficher"));
        affiche = new QTableView(afficher);
        affiche->setObjectName(QStringLiteral("affiche"));
        affiche->setGeometry(QRect(30, 110, 711, 241));
        recherche_afficher = new QLineEdit(afficher);
        recherche_afficher->setObjectName(QStringLiteral("recherche_afficher"));
        recherche_afficher->setGeometry(QRect(40, 60, 191, 31));
        commandLinkButton = new QCommandLinkButton(afficher);
        commandLinkButton->setObjectName(QStringLiteral("commandLinkButton"));
        commandLinkButton->setGeometry(QRect(30, 20, 211, 31));
        QFont font2;
        font2.setFamily(QStringLiteral("Segoe UI"));
        font2.setItalic(true);
        commandLinkButton->setFont(font2);
        commandLinkButton->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        QIcon icon;
        icon.addFile(QStringLiteral("../../../trouver-recherche-zoom-icone-4701-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        commandLinkButton->setIcon(icon);
        commandLinkButton->setIconSize(QSize(25, 25));
        excel = new QPushButton(afficher);
        excel->setObjectName(QStringLiteral("excel"));
        excel->setGeometry(QRect(1050, 10, 75, 23));
        label_5 = new QLabel(afficher);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(310, 40, 81, 21));
        comboBox_2 = new QComboBox(afficher);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(390, 30, 131, 41));
        comboBox_3 = new QComboBox(afficher);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(630, 30, 81, 41));
        label_17 = new QLabel(afficher);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(540, 40, 81, 21));
        ajouter->addTab(afficher, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        label_8 = new QLabel(tab);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(60, 350, 161, 41));
        supprimer_2 = new QPushButton(tab);
        supprimer_2->setObjectName(QStringLiteral("supprimer_2"));
        supprimer_2->setGeometry(QRect(500, 360, 131, 41));
        supprimer_2->setFont(font);
        supprimer_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-color: red;\n"
"\n"
""));
        designation_produit = new QLineEdit(tab);
        designation_produit->setObjectName(QStringLiteral("designation_produit"));
        designation_produit->setGeometry(QRect(250, 360, 161, 31));
        recherche_afficher_3 = new QLineEdit(tab);
        recherche_afficher_3->setObjectName(QStringLiteral("recherche_afficher_3"));
        recherche_afficher_3->setGeometry(QRect(210, 10, 271, 41));
        commandLinkButton_3 = new QCommandLinkButton(tab);
        commandLinkButton_3->setObjectName(QStringLiteral("commandLinkButton_3"));
        commandLinkButton_3->setGeometry(QRect(0, 10, 211, 51));
        commandLinkButton_3->setFont(font2);
        commandLinkButton_3->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        commandLinkButton_3->setIcon(icon);
        commandLinkButton_3->setIconSize(QSize(25, 25));
        supprimer = new QTableView(tab);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setGeometry(QRect(20, 80, 721, 251));
        ajouter->addTab(tab, QString());
        recherche_afficher_3->raise();
        commandLinkButton_3->raise();
        supprimer->raise();
        label_8->raise();
        designation_produit->raise();
        supprimer_2->raise();
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        prix_achat2 = new QLineEdit(tab_3);
        prix_achat2->setObjectName(QStringLiteral("prix_achat2"));
        prix_achat2->setGeometry(QRect(110, 200, 141, 31));
        prix_achat2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        date_achat2 = new QLineEdit(tab_3);
        date_achat2->setObjectName(QStringLiteral("date_achat2"));
        date_achat2->setGeometry(QRect(110, 240, 141, 31));
        date_achat2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        designation2 = new QLineEdit(tab_3);
        designation2->setObjectName(QStringLiteral("designation2"));
        designation2->setGeometry(QRect(110, 100, 141, 31));
        designation2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_7 = new QLabel(tab_3);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(30, 100, 81, 31));
        label_10 = new QLabel(tab_3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(30, 160, 71, 16));
        label_11 = new QLabel(tab_3);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(30, 200, 81, 21));
        modifier_2 = new QTableView(tab_3);
        modifier_2->setObjectName(QStringLiteral("modifier_2"));
        modifier_2->setGeometry(QRect(300, 70, 441, 221));
        modifier = new QPushButton(tab_3);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(130, 400, 111, 31));
        modifier->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-color: red;\n"
"\n"
""));
        label = new QLabel(tab_3);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 60, 61, 16));
        ref2 = new QLineEdit(tab_3);
        ref2->setObjectName(QStringLiteral("ref2"));
        ref2->setGeometry(QRect(110, 50, 141, 31));
        ref2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        recherche_afficher_2 = new QLineEdit(tab_3);
        recherche_afficher_2->setObjectName(QStringLiteral("recherche_afficher_2"));
        recherche_afficher_2->setGeometry(QRect(400, 10, 301, 41));
        commandLinkButton_2 = new QCommandLinkButton(tab_3);
        commandLinkButton_2->setObjectName(QStringLiteral("commandLinkButton_2"));
        commandLinkButton_2->setGeometry(QRect(160, 10, 261, 41));
        commandLinkButton_2->setFont(font2);
        commandLinkButton_2->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        commandLinkButton_2->setIcon(icon);
        commandLinkButton_2->setIconSize(QSize(25, 25));
        pushButton_2 = new QPushButton(tab_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(650, 320, 75, 23));
        pushButton_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-color: red;\n"
"\n"
""));
        label_9 = new QLabel(tab_3);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(30, 290, 71, 16));
        label_12 = new QLabel(tab_3);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(30, 330, 47, 13));
        prix_unitaire2 = new QLineEdit(tab_3);
        prix_unitaire2->setObjectName(QStringLiteral("prix_unitaire2"));
        prix_unitaire2->setGeometry(QRect(110, 280, 141, 31));
        prix_unitaire2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        montantTVA_2 = new QLineEdit(tab_3);
        montantTVA_2->setObjectName(QStringLiteral("montantTVA_2"));
        montantTVA_2->setGeometry(QRect(110, 360, 141, 31));
        montantTVA_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);"));
        label_13 = new QLabel(tab_3);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(30, 250, 71, 16));
        fournisseur_2 = new QLineEdit(tab_3);
        fournisseur_2->setObjectName(QStringLiteral("fournisseur_2"));
        fournisseur_2->setGeometry(QRect(110, 150, 141, 31));
        fournisseur_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);\n"
""));
        label_15 = new QLabel(tab_3);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(30, 370, 81, 16));
        quantite_2 = new QLineEdit(tab_3);
        quantite_2->setObjectName(QStringLiteral("quantite_2"));
        quantite_2->setGeometry(QRect(110, 320, 141, 31));
        quantite_2->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-top-color: rgb(255, 85, 0);\n"
"\n"
"border-bottom-color: rgb(0, 170, 0);\n"
"border-right-color: rgb(255, 255, 0);\n"
"border-left-color: rgb(255, 255, 0);"));
        ajouter->addTab(tab_3, QString());
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(610, 0, 141, 31));
        pushButton->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 3px;\n"
"border-color: red;\n"
"\n"
""));
        tabWidget->addTab(tab_2, QString());

        retranslateUi(produit_ui);

        tabWidget->setCurrentIndex(0);
        ajouter->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(produit_ui);
    } // setupUi

    void retranslateUi(QDialog *produit_ui)
    {
        produit_ui->setWindowTitle(QApplication::translate("produit_ui", "Dialog", Q_NULLPTR));
        designation->setPlaceholderText(QString());
        label_2->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" color:#ff5500;\">designation</span></p></body></html>", Q_NULLPTR));
        ajout_produit->setText(QApplication::translate("produit_ui", "ajouter produit", Q_NULLPTR));
        label_4->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" color:#ff5500;\">prix achat</span></p></body></html>", Q_NULLPTR));
        l_controle_saisie->setText(QString());
        l_controle_saisie_2->setText(QString());
        label_16->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" color:#ff5500;\">reference</span></p></body></html>", Q_NULLPTR));
        label_3->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" color:#ff5500;\">date_achat</span></p></body></html>", Q_NULLPTR));
        label_6->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" color:#ff5500;\">fournisseur</span></p></body></html>", Q_NULLPTR));
        label_14->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" color:#ff5500;\">quantite</span></p></body></html>", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(ajout), QApplication::translate("produit_ui", "ajouter  produit", Q_NULLPTR));
        commandLinkButton->setText(QApplication::translate("produit_ui", "rechercher par ref ou designation", Q_NULLPTR));
        excel->setText(QApplication::translate("produit_ui", "excel", Q_NULLPTR));
        label_5->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" font-size:16pt;\">tri par </span></p></body></html>", Q_NULLPTR));
        label_17->setText(QApplication::translate("produit_ui", "<html><head/><body><p><span style=\" font-size:16pt;\">ordre</span></p></body></html>", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(afficher), QApplication::translate("produit_ui", "afficher la liste de produit", Q_NULLPTR));
        label_8->setText(QApplication::translate("produit_ui", "le nom du fournisseur \303\240 supprimer", Q_NULLPTR));
        supprimer_2->setText(QApplication::translate("produit_ui", "supprimer", Q_NULLPTR));
        designation_produit->setPlaceholderText(QApplication::translate("produit_ui", "entrer le nom du fournisseur que vous voulez supprimer", Q_NULLPTR));
        recherche_afficher_3->setText(QString());
        commandLinkButton_3->setText(QApplication::translate("produit_ui", "rechercher par ref ou designaion", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(tab), QApplication::translate("produit_ui", "supprimer un produit", Q_NULLPTR));
        prix_achat2->setText(QString());
        prix_achat2->setPlaceholderText(QString());
        date_achat2->setPlaceholderText(QString());
        designation2->setPlaceholderText(QString());
        label_7->setText(QApplication::translate("produit_ui", "designation", Q_NULLPTR));
        label_10->setText(QApplication::translate("produit_ui", "fournisseur", Q_NULLPTR));
        label_11->setText(QApplication::translate("produit_ui", "prix achat", Q_NULLPTR));
        modifier->setText(QApplication::translate("produit_ui", "modifier", Q_NULLPTR));
        label->setText(QApplication::translate("produit_ui", "reference", Q_NULLPTR));
        commandLinkButton_2->setText(QApplication::translate("produit_ui", "rechercher par ref ou designation", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("produit_ui", "actualiser", Q_NULLPTR));
        label_9->setText(QApplication::translate("produit_ui", "prix unitaire", Q_NULLPTR));
        label_12->setText(QApplication::translate("produit_ui", "quantite", Q_NULLPTR));
        label_13->setText(QApplication::translate("produit_ui", "date achat", Q_NULLPTR));
        label_15->setText(QApplication::translate("produit_ui", "montant_TVA", Q_NULLPTR));
        ajouter->setTabText(ajouter->indexOf(tab_3), QApplication::translate("produit_ui", "modifier un produit", Q_NULLPTR));
        pushButton->setText(QApplication::translate("produit_ui", "retour au menu", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("produit_ui", "gerer produit", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class produit_ui: public Ui_produit_ui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUIT_UI_H
